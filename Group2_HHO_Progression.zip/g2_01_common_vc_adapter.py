#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Group 2 / Code 01
Common VC objective adapter.

This file deliberately reuses the frozen Group-1 VC problem definition:
- native RGB image;
- one optimized color-level count per R/G/B channel;
- NX in [2,255];
- fixed random fields within one stochastic run;
- frozen single-objective fitness:
      mean_j [ PSNR(secret, share_j) + |CC(secret, share_j)| ].

All Group-2 single-objective optimizers call this same adapter so that only
the optimizer/search representation changes.
"""

from __future__ import annotations
from dataclasses import dataclass
import numpy as np

from g1_03_vc_share_generation import generate_rgb_shares
from g1_04_vc_reconstruction import xor_reconstruct, verify_non_expansion
from g1_06_vc_baseline_fitness import channel_level_fitness
from g1_05_vc_solution_encoding import decode_channel_bits


@dataclass
class FrozenVCObjective:
    image: np.ndarray
    random_fields: tuple[np.ndarray, np.ndarray, np.ndarray]

    @classmethod
    def from_seed(cls, image: np.ndarray, seed: int):
        if image.ndim != 3 or image.shape[2] != 3:
            raise ValueError("Expected HxWx3 RGB image.")
        ss = np.random.SeedSequence(seed)
        children = ss.spawn(3)
        fields = tuple(
            np.random.default_rng(children[i]).random(image.shape[:2])
            for i in range(3)
        )
        return cls(image=image, random_fields=fields)

    @staticmethod
    def clip_level(x: float | int) -> int:
        return int(np.clip(np.rint(x), 2, 255))

    def evaluate_levels(self, levels_rgb) -> tuple[np.ndarray, dict]:
        levels = tuple(self.clip_level(v) for v in levels_rgb)
        scores = []
        detail = {}
        for ch, name in enumerate(("R", "G", "B")):
            score, d = channel_level_fitness(
                self.image[..., ch],
                levels[ch],
                self.random_fields[ch],
            )
            scores.append(score)
            detail[name] = d
        return np.asarray(scores, dtype=float), {
            "levels_rgb": levels,
            "per_channel": detail,
            "mean_fitness": float(np.mean(scores)),
        }

    def evaluate_bits24(self, bits24: np.ndarray) -> tuple[np.ndarray, dict]:
        bits24 = np.asarray(bits24, dtype=np.uint8).ravel()
        if len(bits24) != 24:
            raise ValueError("Expected 24 bits.")
        levels = (
            decode_channel_bits(bits24[:8]),
            decode_channel_bits(bits24[8:16]),
            decode_channel_bits(bits24[16:24]),
        )
        return self.evaluate_levels(levels)

    def build_outputs(self, levels_rgb):
        levels = tuple(self.clip_level(v) for v in levels_rgb)
        s1, s2, meta = generate_rgb_shares(
            self.image,
            levels,
            random_fields=self.random_fields,
        )
        rec = xor_reconstruct(s1, s2)
        return {
            "levels_rgb": levels,
            "share1": s1,
            "share2": s2,
            "recovered": rec,
            "share_metadata": meta,
            "non_expansible": verify_non_expansion(self.image, s1, s2),
        }
