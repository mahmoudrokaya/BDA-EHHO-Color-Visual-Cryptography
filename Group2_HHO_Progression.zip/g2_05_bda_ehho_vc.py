#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Group 2 / Code 05
BDA-EHHO-VC hybrid (single-objective).

Methodological role:
BEHHO/baselines -> BDA-EHHO measures the HYBRIDIZATION EFFECT.

Design:
- candidate representation is 24-bit binary;
- early search emphasizes BDA-style bit-flip exploration;
- later search increasingly uses BEHHO-guided proposals;
- both proposal types consume the SAME objective-evaluation budget;
- elitist replacement keeps the better candidate.

This is intentionally explicit so the hybrid mechanism is reproducible.
"""

from __future__ import annotations
from dataclasses import dataclass
import numpy as np

from g2_01_common_vc_adapter import FrozenVCObjective
from g2_04_behho_vc import sigmoid, binary_diversity


@dataclass
class HybridResult:
    best_bits: list[int]
    best_levels_rgb: list[int]
    best_score: float
    convergence: list[float]
    evaluations: int
    iterations_completed: int
    bda_proposals: int
    ehho_proposals: int
    seed: int


def v3(delta):
    return np.abs(delta / np.sqrt(1 + delta**2))


def optimize_bda_ehho_vc(
    objective: FrozenVCObjective,
    population_size=10,
    max_iterations=10,
    max_evaluations=None,
    seed=0,
):
    rng=np.random.default_rng(seed)
    n,dim=population_size,24
    B=rng.integers(0,2,size=(n,dim),dtype=np.uint8)
    D=rng.integers(0,2,size=(n,dim)).astype(float)
    latent=np.where(B==1,1.0,-1.0)

    fit=np.full(n,np.inf)
    best_b=B[0].copy(); best=float("inf")
    worst_b=B[0].copy(); worst=-float("inf")
    conv=[]; evaluations=0; completed=0
    bda_n=0; ehho_n=0

    def ev(bits):
        nonlocal evaluations
        s,_=objective.evaluate_bits24(bits)
        evaluations+=1
        return float(np.mean(s))

    for t in range(max_iterations):
        # evaluate current population if needed
        for i in range(n):
            if max_evaluations is not None and evaluations>=max_evaluations: break
            fit[i]=ev(B[i])
            if fit[i]<best: best=fit[i]; best_b=B[i].copy()
            if fit[i]>worst: worst=fit[i]; worst_b=B[i].copy()

        completed+=1; conv.append(float(best))
        if max_evaluations is not None and evaluations>=max_evaluations: break

        rho=1.0-(t/max(1,max_iterations-1))  # BDA probability decreases with time

        # BDA iteration parameters
        w=0.9-(t+1)*((0.9-0.4)/max_iterations)
        my_c=max(0.1-(t+1)*(0.1/(max_iterations/2.0)),0.0)
        s=2*rng.random()*my_c; a=2*rng.random()*my_c
        c=2*rng.random()*my_c; f=2*rng.random(); e=my_c
        if t+1>(3*max_iterations/4): e=0.0

        sumB=B.astype(float).sum(axis=0); sumD=D.sum(axis=0)

        for i in range(n):
            if max_evaluations is not None and evaluations>=max_evaluations: break

            current=B[i].copy()
            current_fit=fit[i] if np.isfinite(fit[i]) else ev(current)

            if rng.random()<rho:
                # BDA proposal
                nn=n-1; xi=current.astype(float)
                neighB=sumB-xi; neighD=sumD-D[i]
                S=-(neighB-nn*xi); A=neighD/nn
                C=(neighB/nn)-xi; F=best_b.astype(float)-xi
                E=worst_b.astype(float)+xi
                D[i]=np.clip(s*S+a*A+c*C+f*F+e*E+w*D[i],-6,6)
                prop=current.copy()
                flips=rng.random(dim)<v3(D[i])
                prop[flips]=1-prop[flips]
                bda_n+=1
            else:
                # BEHHO-style guided proposal in latent space
                E1=2*(1-(t+1)/max_iterations)
                Esc=E1*(2*rng.random()-1)
                rb=np.where(best_b==1,1.0,-1.0)
                xi=latent[i].copy()
                J=2*(1-rng.random())
                if abs(Esc)>=1:
                    xr=latent[int(rng.integers(0,n))]
                    newx=xr-rng.random()*np.abs(xr-2*rng.random()*xi)
                elif rng.random()>=0.5:
                    newx=rb-Esc*np.abs(J*rb-xi)
                else:
                    newx=rb-Esc*np.abs(J*rb-np.mean(latent,axis=0))
                latent[i]=np.clip(newx,-6,6)
                prop=(rng.random(dim)<sigmoid(latent[i])).astype(np.uint8)
                ehho_n+=1

            pf=ev(prop)
            if pf<=current_fit:
                B[i]=prop
                fit[i]=pf
                latent[i]=np.where(prop==1,1.0,-1.0)
                if pf<best:
                    best=pf; best_b=prop.copy()
            else:
                fit[i]=current_fit

        if max_evaluations is not None and evaluations>=max_evaluations: break

    _, detail=objective.evaluate_bits24(best_b)
    return HybridResult(
        best_bits=best_b.astype(int).tolist(),
        best_levels_rgb=list(detail["levels_rgb"]),
        best_score=float(best),
        convergence=conv,
        evaluations=evaluations,
        iterations_completed=completed,
        bda_proposals=bda_n,
        ehho_proposals=ehho_n,
        seed=seed,
    )
