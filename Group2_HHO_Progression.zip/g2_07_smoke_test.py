#!/usr/bin/env python3
import numpy as np
from g2_01_common_vc_adapter import FrozenVCObjective
from g2_02_hho_vc import optimize_hho_vc
from g2_03_ehho_vc import optimize_ehho_vc
from g2_04_behho_vc import optimize_behho_vc
from g2_05_bda_ehho_vc import optimize_bda_ehho_vc

h,w=24,32
y,x=np.mgrid[0:h,0:w]
img=np.stack([
    (255*x/(w-1)).astype(np.uint8),
    (255*y/(h-1)).astype(np.uint8),
    ((x+y)*255/(w+h-2)).astype(np.uint8)
],axis=-1)
obj=FrozenVCObjective.from_seed(img,123)

for name,fn in [
    ("HHO",optimize_hho_vc),
    ("EHHO",optimize_ehho_vc),
    ("BEHHO",optimize_behho_vc),
    ("HYBRID",optimize_bda_ehho_vc),
]:
    r=fn(obj,population_size=6,max_iterations=3,max_evaluations=18,seed=7)
    assert 2<=r.best_levels_rgb[0]<=255
    assert 2<=r.best_levels_rgb[1]<=255
    assert 2<=r.best_levels_rgb[2]<=255
    assert r.evaluations<=18
    print(name,r.best_levels_rgb,r.best_score,r.evaluations)
print("GROUP 2 SMOKE TEST: PASS")
