# Group 2 — Progressive HHO-Based Optimization

This package implements the single-objective methodological progression in Section 3.2 while keeping the Group-1 VC architecture frozen.

## Implemented

1. `g2_01_common_vc_adapter.py`
   - frozen Group-1 objective and probabilistic VC random fields.

2. `g2_02_hho_vc.py`
   - standard continuous HHO;
   - searches `(N_R,N_G,N_B)` directly;
   - strict BDA→HHO replacement baseline.

3. `g2_03_ehho_vc.py`
   - diversity-controlled EHHO;
   - logs diversity and injection events;
   - intended to measure enhancement/diversity-control effect.

4. `g2_04_behho_vc.py`
   - binary 24-bit EHHO representation;
   - S-shaped transfer;
   - intended to measure representation effect.

5. `g2_05_bda_ehho_vc.py`
   - explicit single-objective BDA–EHHO hybrid;
   - early BDA proposal probability decreases with time;
   - all proposals consume the common evaluation budget.

6. `g2_06_run_controlled_validation.py`
   - controlled six-image real-data check;
   - same images used in Group 1;
   - common objective-evaluation budget.

7. `g2_07_smoke_test.py`
   - synthetic sanity check.

## Deliberately NOT implemented yet

`MO-BDA-EHHO-VC` is not frozen in this package.

Reason: Section 3.4 has not yet finalized the exact reconstruction-quality,
share-security, robustness and computational objective definitions. Implementing
the multi-objective method before fixing those definitions would risk coding an
objective vector that later disagrees with the manuscript.

After Group 2 single-objective validation and Section 3.4 metric freezing, the
multi-objective implementation will be added as the next stage.

## Run order

Copy these files into a new folder, for example:

`D:\48\481\New Papers\BDA_To_HHO_paper\Codes\Group2_HHO_Progression`

Because they import Group-1 modules, either:
- keep Group1_Common_VC_Core on PYTHONPATH, or
- copy the Group-2 files into Group1_Common_VC_Core for the validation stage.

Recommended commands:

```powershell
python g2_07_smoke_test.py
python g2_06_run_controlled_validation.py --population 10 --iterations 10 --budget 100
```

## Fair-comparison rule

Nominal iterations are NOT the primary fairness control. The primary control is
the number of calls to the frozen VC objective. Every algorithm is stopped when
the common objective-evaluation budget is consumed.

## Sources

Standard HHO:
Heidari et al. (2019), Future Generation Computer Systems 97, 849–872.
DOI: 10.1016/j.future.2019.02.028

EHHO methodological bridge:
Turabieh et al. (2021), Computing 103, 1417–1438.
DOI: 10.1007/s00607-020-00894-7
