#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Group 2 / Code 02
HHO-VC strict optimizer-replacement baseline.

Methodological role:
BDA-VC -> HHO-VC measures the REPLACEMENT EFFECT only.

No VC component is changed. Standard continuous HHO searches three variables
(N_R, N_G, N_B), bounded to [2,255]. Candidate positions are rounded/clipped
only when passed to the frozen VC objective.

Reference HHO:
Heidari et al., Future Generation Computer Systems 97 (2019) 849-872.
DOI: 10.1016/j.future.2019.02.028
"""

from __future__ import annotations
from dataclasses import dataclass, asdict
import math
import numpy as np
from g2_01_common_vc_adapter import FrozenVCObjective


@dataclass
class HHOResult:
    best_position: list[float]
    best_levels_rgb: list[int]
    best_score: float
    best_channel_scores: list[float]
    convergence: list[float]
    evaluations: int
    iterations_completed: int
    seed: int


def levy_flight(dim: int, rng: np.random.Generator, beta: float = 1.5):
    sigma = (
        math.gamma(1 + beta)
        * np.sin(np.pi * beta / 2)
        / (
            math.gamma((1 + beta) / 2)
            * beta
            * 2 ** ((beta - 1) / 2)
        )
    ) ** (1 / beta)
    u = rng.normal(0, sigma, size=dim)
    v = rng.normal(0, 1, size=dim)
    return 0.01 * u / (np.abs(v) ** (1 / beta) + 1e-12)


def optimize_hho_vc(
    objective: FrozenVCObjective,
    population_size: int = 10,
    max_iterations: int = 10,
    max_evaluations: int | None = None,
    seed: int = 0,
    lower: float = 2.0,
    upper: float = 255.0,
) -> HHOResult:
    if population_size < 2:
        raise ValueError("population_size must be >=2.")
    rng = np.random.default_rng(seed)
    dim = 3
    X = rng.uniform(lower, upper, size=(population_size, dim))

    rabbit = np.zeros(dim, dtype=float)
    rabbit_score = float("inf")
    rabbit_channels = np.full(3, np.inf)
    convergence = []
    evaluations = 0
    completed = 0

    def eval_pos(pos):
        nonlocal evaluations
        scores, _ = objective.evaluate_levels(pos)
        evaluations += 1
        return float(np.mean(scores)), scores

    for t in range(max_iterations):
        # Evaluate current hawks.
        for i in range(population_size):
            if max_evaluations is not None and evaluations >= max_evaluations:
                break
            X[i] = np.clip(X[i], lower, upper)
            score, ch_scores = eval_pos(X[i])
            if score < rabbit_score:
                rabbit_score = score
                rabbit = X[i].copy()
                rabbit_channels = ch_scores.copy()

        if max_evaluations is not None and evaluations >= max_evaluations:
            convergence.append(float(rabbit_score))
            completed += 1
            break

        completed += 1
        convergence.append(float(rabbit_score))

        E1 = 2.0 * (1.0 - (t + 1) / max_iterations)

        for i in range(population_size):
            E0 = 2.0 * rng.random() - 1.0
            escaping_energy = E1 * E0

            if abs(escaping_energy) >= 1.0:
                # Exploration
                q = rng.random()
                rand_idx = int(rng.integers(0, population_size))
                X_rand = X[rand_idx].copy()
                r1, r2 = rng.random(), rng.random()
                if q < 0.5:
                    X[i] = X_rand - r1 * np.abs(X_rand - 2.0 * r2 * X[i])
                else:
                    mean_x = np.mean(X, axis=0)
                    X[i] = (rabbit - mean_x) - r1 * (
                        lower + r2 * (upper - lower)
                    )
            else:
                # Exploitation
                r = rng.random()
                J = 2.0 * (1.0 - rng.random())
                delta = rabbit - X[i]

                if r >= 0.5 and abs(escaping_energy) >= 0.5:
                    # Soft besiege
                    X[i] = delta - escaping_energy * np.abs(J * rabbit - X[i])

                elif r >= 0.5 and abs(escaping_energy) < 0.5:
                    # Hard besiege
                    X[i] = rabbit - escaping_energy * np.abs(delta)

                elif r < 0.5 and abs(escaping_energy) >= 0.5:
                    # Soft besiege with progressive rapid dives
                    Y = rabbit - escaping_energy * np.abs(J * rabbit - X[i])
                    Y = np.clip(Y, lower, upper)
                    if max_evaluations is not None and evaluations >= max_evaluations:
                        X[i] = Y
                        continue
                    fy, _ = eval_pos(Y)

                    Z = Y + rng.normal(size=dim) * levy_flight(dim, rng)
                    Z = np.clip(Z, lower, upper)
                    if max_evaluations is not None and evaluations >= max_evaluations:
                        X[i] = Y
                        continue
                    fz, _ = eval_pos(Z)

                    # Compare against current candidate under the frozen objective.
                    if max_evaluations is not None and evaluations >= max_evaluations:
                        X[i] = Y if fy <= fz else Z
                    else:
                        fx, _ = eval_pos(X[i])
                        if fy < fx:
                            X[i] = Y
                        elif fz < fx:
                            X[i] = Z

                else:
                    # Hard besiege with progressive rapid dives
                    mean_x = np.mean(X, axis=0)
                    Y = rabbit - escaping_energy * np.abs(J * rabbit - mean_x)
                    Y = np.clip(Y, lower, upper)
                    if max_evaluations is not None and evaluations >= max_evaluations:
                        X[i] = Y
                        continue
                    fy, _ = eval_pos(Y)

                    Z = Y + rng.normal(size=dim) * levy_flight(dim, rng)
                    Z = np.clip(Z, lower, upper)
                    if max_evaluations is not None and evaluations >= max_evaluations:
                        X[i] = Y
                        continue
                    fz, _ = eval_pos(Z)

                    if max_evaluations is not None and evaluations >= max_evaluations:
                        X[i] = Y if fy <= fz else Z
                    else:
                        fx, _ = eval_pos(X[i])
                        if fy < fx:
                            X[i] = Y
                        elif fz < fx:
                            X[i] = Z

            X[i] = np.clip(X[i], lower, upper)

        if max_evaluations is not None and evaluations >= max_evaluations:
            break

    levels = [objective.clip_level(x) for x in rabbit]
    return HHOResult(
        best_position=rabbit.tolist(),
        best_levels_rgb=levels,
        best_score=float(rabbit_score),
        best_channel_scores=rabbit_channels.astype(float).tolist(),
        convergence=convergence,
        evaluations=int(evaluations),
        iterations_completed=int(completed),
        seed=int(seed),
    )
