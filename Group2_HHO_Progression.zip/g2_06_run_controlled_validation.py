#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Group 2 / Code 06
Controlled six-image validation for:
- HHO-VC
- EHHO-VC
- BEHHO-VC
- BDA-EHHO-VC

Uses the exact six images previously used in Group 1.
The main fairness control is a common objective-evaluation budget.

This is NOT the final 214-image experiment.
"""

from __future__ import annotations
import argparse, json, time
from pathlib import Path
import numpy as np
import pandas as pd

from g1_02_rgb_decomposition import load_rgb
from g2_01_common_vc_adapter import FrozenVCObjective
from g2_02_hho_vc import optimize_hho_vc
from g2_03_ehho_vc import optimize_ehho_vc
from g2_04_behho_vc import optimize_behho_vc
from g2_05_bda_ehho_vc import optimize_bda_ehho_vc

BASE=Path(r"D:\48\481\New Papers\BDA_To_HHO_paper")
DATA=BASE/"Data"
SELECTED=BASE/"Outputs"/"Group1_BDA_Validation"/"selected_images.csv"
OUT=BASE/"Outputs"/"Group2_Controlled_Validation"

ALGOS={
    "HHO-VC": optimize_hho_vc,
    "EHHO-VC": optimize_ehho_vc,
    "BEHHO-VC": optimize_behho_vc,
    "BDA-EHHO-VC": optimize_bda_ehho_vc,
}

def result_to_dict(r):
    return r.__dict__.copy()

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--population",type=int,default=10)
    ap.add_argument("--iterations",type=int,default=10)
    ap.add_argument("--budget",type=int,default=100,
                    help="Total objective evaluations per algorithm/image run.")
    ap.add_argument("--seed",type=int,default=20260911)
    args=ap.parse_args()

    OUT.mkdir(parents=True,exist_ok=True)
    per=OUT/"per_run"; per.mkdir(exist_ok=True)
    sel=pd.read_csv(SELECTED)
    rows=[]

    for _,row in sel.iterrows():
        image=load_rgb(DATA/row["relative_to_data"],True)
        img_no=int(str(row["experiment_id"]).split("_")[-1])
        master=args.seed+img_no

        # The objective random field is common across algorithms for this image/run.
        objective=FrozenVCObjective.from_seed(image, master)

        for ai,(name,fn) in enumerate(ALGOS.items()):
            # Separate deterministic optimizer stream, same master base.
            alg_seed=master+10000*(ai+1)
            t0=time.perf_counter()
            res=fn(
                objective,
                population_size=args.population,
                max_iterations=args.iterations,
                max_evaluations=args.budget,
                seed=alg_seed,
            )
            runtime=time.perf_counter()-t0
            d=result_to_dict(res)

            algo_dir=per/f"{row['experiment_id']}_{name.replace('/','_')}"
            algo_dir.mkdir(exist_ok=True)
            (algo_dir/"result.json").write_text(
                json.dumps(d,indent=2),encoding="utf-8"
            )
            pd.DataFrame({
                "step":np.arange(1,len(d["convergence"])+1),
                "best_so_far":d["convergence"]
            }).to_csv(algo_dir/"convergence.csv",index=False)

            rows.append({
                "experiment_id":row["experiment_id"],
                "dataset":row["dataset"],
                "split":row["split"],
                "filename":row["filename"],
                "algorithm":name,
                "population":args.population,
                "nominal_iterations":args.iterations,
                "budget":args.budget,
                "evaluations":d["evaluations"],
                "runtime_s":runtime,
                "best_score":d["best_score"],
                "level_R":d["best_levels_rgb"][0],
                "level_G":d["best_levels_rgb"][1],
                "level_B":d["best_levels_rgb"][2],
                "seed":alg_seed,
            })
            print(row["experiment_id"],name,
                  "score=",round(d["best_score"],6),
                  "evals=",d["evaluations"],
                  "runtime=",round(runtime,3))

    df=pd.DataFrame(rows)
    df.to_csv(OUT/"group2_validation_summary.csv",index=False,encoding="utf-8-sig")

    # Fairness audit.
    fair=(df["evaluations"]<=df["budget"]).all()
    agg=df.groupby("algorithm").agg(
        cases=("best_score","size"),
        mean_best_score=("best_score","mean"),
        median_best_score=("best_score","median"),
        mean_evaluations=("evaluations","mean"),
        mean_runtime_s=("runtime_s","mean"),
    ).reset_index()
    agg.to_csv(OUT/"group2_algorithm_summary.csv",index=False,encoding="utf-8-sig")

    report=[
        "# Group 2 Controlled Validation",
        "",
        f"- Images: **{len(sel)}**",
        f"- Population: **{args.population}**",
        f"- Common evaluation budget: **{args.budget}**",
        f"- Budget compliance: **{'PASS' if fair else 'REVIEW'}**",
        "",
        "## Algorithm summary",
        "",
        agg.to_markdown(index=False),
        "",
        "This is a six-image implementation validation, not the final inferential experiment. "
        "The same frozen VC objective and the same image-specific random fields are used across "
        "algorithms. Final parameter settings will be selected using BSDS500 validation data only.",
    ]
    (OUT/"group2_validation_report.md").write_text("\n".join(report),encoding="utf-8")

    try:
        with pd.ExcelWriter(OUT/"group2_validation.xlsx",engine="openpyxl") as w:
            df.to_excel(w,sheet_name="Runs",index=False)
            agg.to_excel(w,sheet_name="Summary",index=False)
    except Exception as exc:
        print("Excel export skipped:",exc)

    print("\nDone:",OUT)

if __name__=="__main__":
    main()
