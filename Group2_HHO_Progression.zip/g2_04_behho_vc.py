#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Group 2 / Code 04
BEHHO-VC: binary/discrete enhanced HHO.

Methodological role:
EHHO-VC -> BEHHO-VC measures the REPRESENTATION EFFECT.

Each candidate is 24 bits:
  [8 R bits | 8 G bits | 8 B bits].

A continuous HHO latent position/velocity-like update is mapped to binary
decisions using an S-shaped sigmoid transfer:
    p = 1/(1+exp(-x))
    bit = 1 if U<p else 0

EHHO-style diversity monitoring is applied in Hamming space.
"""

from __future__ import annotations
from dataclasses import dataclass
import numpy as np

from g2_01_common_vc_adapter import FrozenVCObjective
from g2_02_hho_vc import levy_flight


@dataclass
class BEHHOResult:
    best_bits: list[int]
    best_levels_rgb: list[int]
    best_score: float
    best_channel_scores: list[float]
    convergence: list[float]
    diversity_history: list[float]
    injection_iterations: list[int]
    evaluations: int
    iterations_completed: int
    seed: int


def sigmoid(x):
    return 1.0 / (1.0 + np.exp(-np.clip(x, -30, 30)))


def binary_diversity(B):
    """Mean per-bit Bernoulli diversity, scaled to [0,1]."""
    p = np.mean(B, axis=0)
    return float(np.mean(4.0 * p * (1.0 - p)))


def optimize_behho_vc(
    objective: FrozenVCObjective,
    population_size=10,
    max_iterations=10,
    max_evaluations=None,
    seed=0,
    diversity_threshold=0.08,
    injection_fraction=0.30,
    min_iteration_before_injection=2,
):
    rng = np.random.default_rng(seed)
    n, dim = population_size, 24

    # Latent continuous state + binary realized state.
    X = rng.normal(0, 1, size=(n, dim))
    B = (rng.random((n, dim)) < sigmoid(X)).astype(np.uint8)

    rabbit_x = np.zeros(dim)
    rabbit_b = np.zeros(dim, dtype=np.uint8)
    rabbit_score = float("inf")
    rabbit_channels = np.full(3, np.inf)

    conv, div_hist, injections = [], [], []
    evaluations = 0
    completed = 0

    def eval_bits(bits):
        nonlocal evaluations
        sc, _ = objective.evaluate_bits24(bits)
        evaluations += 1
        return float(np.mean(sc)), sc

    for t in range(max_iterations):
        for i in range(n):
            if max_evaluations is not None and evaluations >= max_evaluations:
                break
            f, cs = eval_bits(B[i])
            if f < rabbit_score:
                rabbit_score = f
                rabbit_b = B[i].copy()
                rabbit_x = X[i].copy()
                rabbit_channels = cs.copy()

        completed += 1
        conv.append(float(rabbit_score))
        div = binary_diversity(B)
        div_hist.append(div)

        if (
            t + 1 >= min_iteration_before_injection
            and div < diversity_threshold
            and (max_evaluations is None or evaluations < max_evaluations)
        ):
            k = max(1, int(np.ceil(n * injection_fraction)))
            idx = rng.choice(np.arange(n), size=min(k, n-1), replace=False)
            X[idx] = rng.normal(0, 1, size=(len(idx), dim))
            B[idx] = (rng.random((len(idx), dim)) < sigmoid(X[idx])).astype(np.uint8)
            injections.append(t + 1)

        if max_evaluations is not None and evaluations >= max_evaluations:
            break

        E1 = 2*(1-(t+1)/max_iterations)

        for i in range(n):
            E0 = 2*rng.random()-1
            E = E1*E0
            if abs(E) >= 1:
                xr = X[int(rng.integers(0,n))].copy()
                q = rng.random(); r1=rng.random(); r2=rng.random()
                if q < 0.5:
                    newx = xr - r1*np.abs(xr-2*r2*X[i])
                else:
                    newx = rabbit_x - np.mean(X,axis=0) - r1*(-6 + r2*12)
            else:
                r=rng.random(); J=2*(1-rng.random()); delta=rabbit_x-X[i]
                if r>=0.5 and abs(E)>=0.5:
                    newx=delta-E*np.abs(J*rabbit_x-X[i])
                elif r>=0.5 and abs(E)<0.5:
                    newx=rabbit_x-E*np.abs(delta)
                else:
                    base=(
                        rabbit_x-E*np.abs(J*rabbit_x-X[i])
                        if abs(E)>=0.5
                        else rabbit_x-E*np.abs(J*rabbit_x-np.mean(X,axis=0))
                    )
                    newx=base+rng.normal(size=dim)*levy_flight(dim,rng)

            X[i]=np.clip(newx,-6,6)
            B[i]=(rng.random(dim)<sigmoid(X[i])).astype(np.uint8)

        if max_evaluations is not None and evaluations >= max_evaluations:
            break

    _, detail = objective.evaluate_bits24(rabbit_b)
    # Last diagnostic evaluation should not count against optimization budget.
    levels = list(detail["levels_rgb"])

    return BEHHOResult(
        best_bits=rabbit_b.astype(int).tolist(),
        best_levels_rgb=levels,
        best_score=float(rabbit_score),
        best_channel_scores=rabbit_channels.tolist(),
        convergence=conv,
        diversity_history=div_hist,
        injection_iterations=injections,
        evaluations=evaluations,
        iterations_completed=completed,
        seed=seed,
    )
