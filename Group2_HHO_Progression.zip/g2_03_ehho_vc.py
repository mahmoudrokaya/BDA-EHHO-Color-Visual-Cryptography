#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Group 2 / Code 03
EHHO-VC: diversity-controlled Enhanced Harris Hawks Optimization.

Methodological role:
HHO-VC -> EHHO-VC measures the DIVERSITY-ENHANCEMENT EFFECT.

The enhancement follows the principle reported in:
Turabieh et al. (2021), Computing 103, 1417-1438,
DOI: 10.1007/s00607-020-00894-7:
control population diversity to reduce early convergence/local-optimum trapping.

Because the published EHHO paper is a feature-selection application and its
problem representation differs from the present 3-variable VC problem, this
module exposes the diversity trigger/injection policy as configuration and logs
every injection. It does not claim an undocumented one-to-one code reproduction.
"""

from __future__ import annotations
from dataclasses import dataclass
import numpy as np

from g2_01_common_vc_adapter import FrozenVCObjective
from g2_02_hho_vc import levy_flight


@dataclass
class EHHOResult:
    best_position: list[float]
    best_levels_rgb: list[int]
    best_score: float
    best_channel_scores: list[float]
    convergence: list[float]
    diversity_history: list[float]
    injection_iterations: list[int]
    evaluations: int
    iterations_completed: int
    seed: int


def normalized_population_diversity(X, lower=2.0, upper=255.0):
    """Mean normalized distance from population centroid."""
    if len(X) == 0:
        return 0.0
    center = np.mean(X, axis=0)
    scale = max(float(upper - lower), 1e-12)
    d = np.linalg.norm((X - center) / scale, axis=1)
    return float(np.mean(d))


def inject_diversity(X, rabbit, rng, lower, upper, fraction=0.30):
    """
    Reinitialize the farthest-needed fraction while preserving the best solution.
    The elite/rabbit itself is not overwritten.
    """
    n = len(X)
    k = max(1, int(np.ceil(n * fraction)))
    # choose random population positions for reinjection; preserve one position
    idx = rng.choice(np.arange(n), size=min(k, n - 1), replace=False)
    for i in idx:
        X[i] = rng.uniform(lower, upper, size=X.shape[1])
    return X


def optimize_ehho_vc(
    objective: FrozenVCObjective,
    population_size=10,
    max_iterations=10,
    max_evaluations=None,
    seed=0,
    lower=2.0,
    upper=255.0,
    diversity_threshold=0.025,
    injection_fraction=0.30,
    min_iteration_before_injection=2,
):
    rng = np.random.default_rng(seed)
    dim = 3
    X = rng.uniform(lower, upper, size=(population_size, dim))
    rabbit = np.zeros(dim)
    rabbit_score = float("inf")
    rabbit_channels = np.full(3, np.inf)
    conv, div_hist, injections = [], [], []
    evaluations = 0
    completed = 0

    def eval_pos(pos):
        nonlocal evaluations
        sc, _ = objective.evaluate_levels(pos)
        evaluations += 1
        return float(np.mean(sc)), sc

    for t in range(max_iterations):
        for i in range(population_size):
            if max_evaluations is not None and evaluations >= max_evaluations:
                break
            X[i] = np.clip(X[i], lower, upper)
            f, cs = eval_pos(X[i])
            if f < rabbit_score:
                rabbit_score = f
                rabbit = X[i].copy()
                rabbit_channels = cs.copy()

        completed += 1
        conv.append(float(rabbit_score))
        div = normalized_population_diversity(X, lower, upper)
        div_hist.append(div)

        if (
            t + 1 >= min_iteration_before_injection
            and div < diversity_threshold
            and (max_evaluations is None or evaluations < max_evaluations)
        ):
            X = inject_diversity(
                X, rabbit, rng, lower, upper, injection_fraction
            )
            injections.append(t + 1)

        if max_evaluations is not None and evaluations >= max_evaluations:
            break

        E1 = 2.0 * (1.0 - (t + 1) / max_iterations)

        for i in range(population_size):
            E0 = 2.0 * rng.random() - 1.0
            E = E1 * E0
            if abs(E) >= 1:
                q = rng.random()
                xr = X[int(rng.integers(0, population_size))].copy()
                r1, r2 = rng.random(), rng.random()
                if q < 0.5:
                    X[i] = xr - r1 * np.abs(xr - 2*r2*X[i])
                else:
                    X[i] = (
                        rabbit - np.mean(X, axis=0)
                        - r1 * (lower + r2*(upper-lower))
                    )
            else:
                r = rng.random()
                J = 2*(1-rng.random())
                delta = rabbit - X[i]
                if r >= 0.5 and abs(E) >= 0.5:
                    X[i] = delta - E*np.abs(J*rabbit-X[i])
                elif r >= 0.5 and abs(E) < 0.5:
                    X[i] = rabbit - E*np.abs(delta)
                else:
                    base = (
                        rabbit - E*np.abs(J*rabbit-X[i])
                        if abs(E) >= 0.5
                        else rabbit - E*np.abs(J*rabbit-np.mean(X,axis=0))
                    )
                    Y = np.clip(base, lower, upper)
                    Z = np.clip(
                        Y + rng.normal(size=dim)*levy_flight(dim,rng),
                        lower, upper
                    )
                    # budget-aware two-way selection
                    if max_evaluations is not None and evaluations >= max_evaluations:
                        X[i] = Y
                    else:
                        fy, _ = eval_pos(Y)
                        if max_evaluations is not None and evaluations >= max_evaluations:
                            X[i] = Y
                        else:
                            fz, _ = eval_pos(Z)
                            X[i] = Y if fy <= fz else Z
            X[i] = np.clip(X[i], lower, upper)

        if max_evaluations is not None and evaluations >= max_evaluations:
            break

    return EHHOResult(
        best_position=rabbit.tolist(),
        best_levels_rgb=[objective.clip_level(v) for v in rabbit],
        best_score=float(rabbit_score),
        best_channel_scores=rabbit_channels.tolist(),
        convergence=conv,
        diversity_history=div_hist,
        injection_iterations=injections,
        evaluations=evaluations,
        iterations_completed=completed,
        seed=seed,
    )
