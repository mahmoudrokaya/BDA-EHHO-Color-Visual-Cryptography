#!/usr/bin/env python3
import numpy as np
from g2_01_common_vc_adapter import FrozenVCObjective
from g1_06_vc_baseline_fitness import channel_level_fitness
rng=np.random.default_rng(1234)
img=rng.integers(0,256,size=(64,80,3),dtype=np.uint8)
obj=FrozenVCObjective.from_seed(img,20260912)
for levels in [(2,2,2),(10,20,30),(100,150,200),(255,255,255),(10,20,30)]:
    cached,_=obj.evaluate_levels(levels)
    direct=[]
    for ch in range(3):
        s,_=channel_level_fitness(img[...,ch],levels[ch],obj.random_fields[ch])
        direct.append(s)
    if not np.allclose(cached,np.asarray(direct),rtol=0.0,atol=1e-12):
        raise AssertionError((levels,cached,direct))
print('CACHE EQUIVALENCE TEST: PASS')
print(obj.cache_stats())
