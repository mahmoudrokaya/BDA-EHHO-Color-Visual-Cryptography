#!/usr/bin/env python3
from __future__ import annotations
from dataclasses import dataclass, field
import numpy as np
from g1_03_vc_share_generation import generate_rgb_shares
from g1_04_vc_reconstruction import xor_reconstruct, verify_non_expansion
from g1_06_vc_baseline_fitness import channel_level_fitness
from g1_05_vc_solution_encoding import decode_channel_bits

@dataclass
class FrozenVCObjective:
    image: np.ndarray
    random_fields: tuple[np.ndarray, np.ndarray, np.ndarray]
    _fitness_cache: dict = field(default_factory=dict, init=False, repr=False)
    _cache_hits: int = field(default=0, init=False, repr=False)
    _cache_misses: int = field(default=0, init=False, repr=False)

    @classmethod
    def from_seed(cls, image: np.ndarray, seed: int):
        if image.ndim != 3 or image.shape[2] != 3:
            raise ValueError('Expected HxWx3 RGB image.')
        ss = np.random.SeedSequence(seed)
        children = ss.spawn(3)
        fields = tuple(np.random.default_rng(children[i]).random(image.shape[:2]) for i in range(3))
        return cls(image=image, random_fields=fields)

    @staticmethod
    def clip_level(x: float | int) -> int:
        return int(np.clip(np.rint(x), 2, 255))

    def _evaluate_channel_cached(self, ch: int, level: int):
        level = self.clip_level(level)
        key = (int(ch), int(level))
        if key in self._fitness_cache:
            self._cache_hits += 1
            return self._fitness_cache[key]
        score, detail = channel_level_fitness(self.image[..., ch], level, self.random_fields[ch])
        value = (float(score), detail)
        self._fitness_cache[key] = value
        self._cache_misses += 1
        return value

    def evaluate_levels(self, levels_rgb):
        levels = tuple(self.clip_level(v) for v in levels_rgb)
        scores, detail = [], {}
        for ch, name in enumerate(('R','G','B')):
            score, d = self._evaluate_channel_cached(ch, levels[ch])
            scores.append(score); detail[name] = d
        return np.asarray(scores, dtype=float), {
            'levels_rgb': levels,
            'per_channel': detail,
            'mean_fitness': float(np.mean(scores)),
        }

    def evaluate_bits24(self, bits24: np.ndarray):
        bits24 = np.asarray(bits24, dtype=np.uint8).ravel()
        if len(bits24) != 24:
            raise ValueError('Expected 24 bits.')
        levels = (
            decode_channel_bits(bits24[:8]),
            decode_channel_bits(bits24[8:16]),
            decode_channel_bits(bits24[16:24]),
        )
        return self.evaluate_levels(levels)

    def build_outputs(self, levels_rgb):
        levels = tuple(self.clip_level(v) for v in levels_rgb)
        s1, s2, meta = generate_rgb_shares(self.image, levels, random_fields=self.random_fields)
        rec = xor_reconstruct(s1, s2)
        return {
            'levels_rgb': levels,
            'share1': s1,
            'share2': s2,
            'recovered': rec,
            'share_metadata': meta,
            'non_expansible': verify_non_expansion(self.image, s1, s2),
        }

    def cache_stats(self):
        total = self._cache_hits + self._cache_misses
        return {
            'cache_entries': len(self._fitness_cache),
            'cache_hits': self._cache_hits,
            'cache_misses': self._cache_misses,
            'hit_rate': self._cache_hits / total if total else 0.0,
        }
