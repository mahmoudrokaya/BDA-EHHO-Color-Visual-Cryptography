# Group 2 VC Fitness Cache Acceleration

The frozen VC objective is deterministic within each image/run because fixed random fields are reused. Therefore repeated evaluation of the same `(channel, NX)` pair can be memoized exactly.

This does **not** change the objective, seeds, random fields, search trajectory, logical evaluation budget, or returned fitness values. It only avoids recomputing full-image share generation for a `(channel, NX)` value that has already been evaluated.

## Install

In `D:\48\481\New Papers\BDA_To_HHO_paper\Codes\Group2_HHO_Progression`:

```powershell
Ctrl+C
Copy-Item g2_01_common_vc_adapter.py g2_01_common_vc_adapter_original.py
```

Replace `g2_01_common_vc_adapter.py` with the accelerated version from this package, then copy `g2_23_test_cache_equivalence.py` into the same folder and run:

```powershell
python g2_23_test_cache_equivalence.py
```

It must print `CACHE EQUIVALENCE TEST: PASS`.

Then resume:

```powershell
python g2_20_run_calibrated_screen.py
```

The screen runner is resumable and will skip already completed run keys.
