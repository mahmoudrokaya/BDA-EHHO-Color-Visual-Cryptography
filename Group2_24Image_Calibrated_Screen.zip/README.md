# Group 2 — 24-Image Calibrated Screen

Design: 24 BSDS500 validation images × 3 runs × populations {10,20,30} × budgets {300,600} × 4 algorithms = 1728 runs.

Calibrated mechanisms:
- BEHHO threshold 0.70, injection fraction 0.30
- BDA-EHHO budget-based rho 0.70 -> 0.30

Copy the files into:
`D:\48\481\New Papers\BDA_To_HHO_paper\Codes\Group2_HHO_Progression`

Run:
```powershell
python g2_22_estimate_screen_runtime.py
python g2_20_run_calibrated_screen.py
python g2_21_analyze_calibrated_screen.py
```

The runner is resumable. Do not run the 100-image confirmation until this screen has been reviewed.
