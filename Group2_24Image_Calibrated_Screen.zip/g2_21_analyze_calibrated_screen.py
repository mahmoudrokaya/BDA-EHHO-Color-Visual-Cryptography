#!/usr/bin/env python3
from pathlib import Path
import json, numpy as np, pandas as pd
BASE=Path(r"D:\48\481\New Papers\BDA_To_HHO_paper")
OUT=BASE/"Outputs"/"Group2_24Image_Screen"

def pareto(df):
    keep=[]
    for i,r in df.iterrows():
        dom=False
        for j,q in df.iterrows():
            if i==j: continue
            if q.mean_best_score<=r.mean_best_score and q.median_runtime_s<=r.median_runtime_s and (q.mean_best_score<r.mean_best_score or q.median_runtime_s<r.median_runtime_s):
                dom=True; break
        if not dom: keep.append(i)
    return df.loc[keep].copy()

def main():
    raw=pd.read_csv(OUT/"screen_raw_results.csv"); expected=1728
    completion_ok=len(raw)==expected; budget_ok=bool(raw.budget_compliant.astype(bool).all())
    block=["experiment_id","run_index","population_size","evaluation_budget"]
    raw["paired_rank"]=raw.groupby(block).best_score.rank(method="average",ascending=True)
    raw.to_csv(OUT/"paired_ranked_results.csv",index=False,encoding="utf-8-sig")
    alg=(raw.groupby(["population_size","evaluation_budget","algorithm"]).agg(
        runs=("best_score","size"),mean_best_score=("best_score","mean"),median_best_score=("best_score","median"),
        sd_best_score=("best_score","std"),mean_paired_rank=("paired_rank","mean"),
        median_runtime_s=("runtime_s","median"),mean_runtime_s=("runtime_s","mean")).reset_index())
    alg.to_csv(OUT/"algorithm_by_configuration_summary.csv",index=False,encoding="utf-8-sig")

    b=raw[raw.algorithm=="BEHHO-VC-Calibrated"]
    bm=(b.groupby(["population_size","evaluation_budget"]).agg(
        runs=("best_score","size"),mean_injections=("injection_count","mean"),
        pct_runs_with_injection=("injection_count",lambda s:100*np.mean(s>0)),
        mean_diversity=("diversity_mean","mean"),mean_final_diversity=("diversity_final","mean")).reset_index())
    bm.insert(0,"algorithm","BEHHO-VC-Calibrated")
    h=raw[raw.algorithm=="BDA-EHHO-VC-Calibrated"]
    hm=(h.groupby(["population_size","evaluation_budget"]).agg(
        runs=("best_score","size"),mean_bda_fraction=("bda_fraction","mean"),
        mean_bda_proposals=("bda_proposals","mean"),mean_ehho_proposals=("ehho_proposals","mean")).reset_index())
    hm["mean_ehho_fraction"]=1-hm.mean_bda_fraction; hm.insert(0,"algorithm","BDA-EHHO-VC-Calibrated")
    mech=pd.concat([bm,hm],ignore_index=True,sort=False)
    mech.to_csv(OUT/"mechanism_diagnostics.csv",index=False,encoding="utf-8-sig")

    cfg=(raw.groupby(["population_size","evaluation_budget"]).agg(
        mean_best_score=("best_score","mean"),median_best_score=("best_score","median"),
        median_runtime_s=("runtime_s","median"),mean_runtime_s=("runtime_s","mean"),runs=("best_score","size")).reset_index())
    sp=(raw.groupby(block).best_score.agg(lambda x:float(np.max(x)-np.min(x))).reset_index(name="block_spread"))
    sc=(sp.groupby(["population_size","evaluation_budget"]).agg(median_block_spread=("block_spread","median"),max_block_spread=("block_spread","max")).reset_index())
    cfg=cfg.merge(sc,on=["population_size","evaluation_budget"])
    cfg=cfg.merge(bm[["population_size","evaluation_budget","pct_runs_with_injection"]],on=["population_size","evaluation_budget"])
    cfg=cfg.merge(hm[["population_size","evaluation_budget","mean_bda_fraction"]],on=["population_size","evaluation_budget"])
    cfg["mechanism_health_pass"]=cfg.pct_runs_with_injection.between(10,75)&cfg.mean_bda_fraction.between(.35,.65)
    healthy=cfg[cfg.mechanism_health_pass].copy()
    if healthy.empty: raise RuntimeError("No healthy configuration.")
    smin,smax=healthy.mean_best_score.min(),healthy.mean_best_score.max()
    rmin,rmax=healthy.median_runtime_s.min(),healthy.median_runtime_s.max()
    healthy["normalized_score_loss"]=(healthy.mean_best_score-smin)/max(smax-smin,1e-12)
    healthy["normalized_runtime_cost"]=(healthy.median_runtime_s-rmin)/max(rmax-rmin,1e-12)
    healthy["balanced_screening_index"]=.7*healthy.normalized_score_loss+.3*healthy.normalized_runtime_cost
    healthy=healthy.sort_values(["balanced_screening_index","mean_best_score","median_runtime_s"])
    healthy.to_csv(OUT/"healthy_common_configuration_summary.csv",index=False,encoding="utf-8-sig")
    pf=pareto(healthy).sort_values(["mean_best_score","median_runtime_s"])
    pf.to_csv(OUT/"common_configuration_pareto_shortlist.csv",index=False,encoding="utf-8-sig")
    best=healthy.iloc[0]
    decision={"completion_pass":completion_ok,"budget_compliance_pass":budget_ok,
              "recommended_population_size":int(best.population_size),
              "recommended_evaluation_budget":int(best.evaluation_budget),
              "status":"PROVISIONAL_CONFIGURATION_SELECTED" if completion_ok and budget_ok else "REVIEW_REQUIRED",
              "next_stage":"100-image BSDS500 validation confirmation"}
    (OUT/"screen_decision.json").write_text(json.dumps(decision,indent=2),encoding="utf-8")
    report=["# Group 2 — 24-Image Calibrated Screen","",
            f"- Completed runs: **{len(raw)}/{expected}**",f"- Completion: **{'PASS' if completion_ok else 'REVIEW'}**",
            f"- Budget compliance: **{'PASS' if budget_ok else 'REVIEW'}**","","## Algorithms","",alg.to_markdown(index=False),
            "","## Mechanisms","",mech.to_markdown(index=False),"","## Healthy common configurations","",healthy.to_markdown(index=False),
            "","## Pareto shortlist","",pf.to_markdown(index=False),"","## Provisional common configuration","",
            f"**Population size = {int(best.population_size)}**",f"**Evaluation budget = {int(best.evaluation_budget)}**","",
            "Use this same configuration for all single-objective methods in the 100-image confirmation."]
    (OUT/"screen_analysis_report.md").write_text("\n".join(report),encoding="utf-8")
    try:
        with pd.ExcelWriter(OUT/"screen_analysis.xlsx",engine="openpyxl") as w:
            alg.to_excel(w,sheet_name="Algorithms",index=False); mech.to_excel(w,sheet_name="Mechanisms",index=False)
            healthy.to_excel(w,sheet_name="Healthy Configs",index=False); pf.to_excel(w,sheet_name="Pareto",index=False)
    except Exception as e: print("Excel export skipped:",e)
    print("Recommended:",int(best.population_size),int(best.evaluation_budget))

if __name__=="__main__": main()
