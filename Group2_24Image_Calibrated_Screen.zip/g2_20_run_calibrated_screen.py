#!/usr/bin/env python3
from __future__ import annotations
import csv, hashlib, json, math, time
from pathlib import Path
import numpy as np, pandas as pd
from g1_02_rgb_decomposition import load_rgb
from g2_01_common_vc_adapter import FrozenVCObjective
from g2_02_hho_vc import optimize_hho_vc
from g2_03_ehho_vc import optimize_ehho_vc
from g2_13_calibrated_behho_vc import optimize_calibrated_behho_vc
from g2_14_calibrated_bda_ehho_vc import optimize_calibrated_bda_ehho_vc

BASE=Path(r"D:\48\481\New Papers\BDA_To_HHO_paper")
DATA=BASE/"Data"; MANIFEST=BASE/"Outputs"/"Manifests"/"dataset_manifest.csv"
OUT=BASE/"Outputs"/"Group2_24Image_Screen"; TR=OUT/"traces"
N_IMAGES=24; RUNS=3; POPS=[10,20,30]; BUDGETS=[300,600]; SEL_SEED=481; BASE_SEED=20260912
ALGOS=["HHO-VC","EHHO-VC","BEHHO-VC-Calibrated","BDA-EHHO-VC-Calibrated"]
FIELDS=["run_key","experiment_id","filename","run_index","algorithm","population_size","evaluation_budget",
"master_seed","best_score","level_R","level_G","level_B","evaluations","budget_compliant","runtime_s",
"iterations_completed","convergence_points","final_convergence_value","diversity_mean","diversity_final",
"injection_count","bda_proposals","ehho_proposals","bda_fraction"]

def seed_from(*parts):
    d=hashlib.sha256("|".join(map(str,parts)).encode()).digest()
    return int.from_bytes(d[:4],"little") & 0x7fffffff

def select_images():
    m=pd.read_csv(MANIFEST); v=m[(m.dataset=="BSDS500")&(m.split=="validation")].copy()
    return v.sample(n=N_IMAGES,random_state=SEL_SEED).sort_values("experiment_id").reset_index(drop=True)

def append(path,row):
    new=not path.exists()
    with path.open("a",newline="",encoding="utf-8-sig") as f:
        w=csv.DictWriter(f,fieldnames=FIELDS)
        if new: w.writeheader()
        w.writerow(row); f.flush()

def existing(path):
    return set() if not path.exists() else set(pd.read_csv(path,usecols=["run_key"]).run_key.astype(str))

def mech(d):
    div=d.get("diversity_history"); inj=d.get("injection_iterations")
    b=int(d.get("bda_proposals",0) or 0); e=int(d.get("ehho_proposals",0) or 0); tot=b+e
    return {"diversity_mean":float(np.mean(div)) if div is not None and len(div) else np.nan,
    "diversity_final":float(div[-1]) if div is not None and len(div) else np.nan,
    "injection_count":len(inj) if inj is not None else 0,"bda_proposals":b,"ehho_proposals":e,
    "bda_fraction":b/tot if tot else np.nan}

def run_algo(name,obj,pop,budget,seed):
    it=max(30,int(math.ceil(budget/pop)*3))
    if name=="HHO-VC": return optimize_hho_vc(obj,population_size=pop,max_iterations=it,max_evaluations=budget,seed=seed)
    if name=="EHHO-VC": return optimize_ehho_vc(obj,population_size=pop,max_iterations=it,max_evaluations=budget,seed=seed)
    if name=="BEHHO-VC-Calibrated": return optimize_calibrated_behho_vc(obj,population_size=pop,max_iterations=it,max_evaluations=budget,seed=seed,diversity_threshold=0.70,injection_fraction=0.30)
    if name=="BDA-EHHO-VC-Calibrated": return optimize_calibrated_bda_ehho_vc(obj,population_size=pop,max_iterations=it,max_evaluations=budget,seed=seed,rho_max=0.70,rho_min=0.30)
    raise ValueError(name)

def main():
    OUT.mkdir(parents=True,exist_ok=True); TR.mkdir(exist_ok=True)
    sel=select_images(); sel.to_csv(OUT/"selected_validation_images.csv",index=False)
    config={"images":24,"runs_per_image":3,"population_sizes":POPS,"evaluation_budgets":BUDGETS,
    "algorithms":ALGOS,"behho":{"diversity_threshold":0.70,"injection_fraction":0.30},
    "hybrid":{"rho_max":0.70,"rho_min":0.30,"schedule":"evaluation-budget based"},
    "total_planned_runs":24*3*3*2*4}
    (OUT/"screen_configuration.json").write_text(json.dumps(config,indent=2),encoding="utf-8")
    raw=OUT/"screen_raw_results.csv"; done=existing(raw); total=config["total_planned_runs"]
    for _,row in sel.iterrows():
        image=load_rgb(DATA/row.relative_to_data,True)
        for run_idx in range(1,RUNS+1):
            seed=seed_from(BASE_SEED,row.experiment_id,run_idx); obj=FrozenVCObjective.from_seed(image,seed)
            for pop in POPS:
                for budget in BUDGETS:
                    for algo in ALGOS:
                        key=f"{row.experiment_id}|r{run_idx}|n{pop}|b{budget}|{algo}"
                        if key in done: continue
                        t0=time.perf_counter(); r=run_algo(algo,obj,pop,budget,seed); dt=time.perf_counter()-t0
                        d=r.__dict__.copy(); lv=d["best_levels_rgb"]; conv=list(d.get("convergence",[]))
                        rec={"run_key":key,"experiment_id":row.experiment_id,"filename":row.filename,"run_index":run_idx,
                        "algorithm":algo,"population_size":pop,"evaluation_budget":budget,"master_seed":seed,
                        "best_score":float(d["best_score"]),"level_R":int(lv[0]),"level_G":int(lv[1]),"level_B":int(lv[2]),
                        "evaluations":int(d["evaluations"]),"budget_compliant":int(d["evaluations"])<=budget,"runtime_s":dt,
                        "iterations_completed":int(d.get("iterations_completed",len(conv))),"convergence_points":len(conv),
                        "final_convergence_value":float(conv[-1]) if conv else np.nan,**mech(d)}
                        append(raw,rec)
                        pd.DataFrame({"step":np.arange(1,len(conv)+1),"best_so_far":conv}).to_csv(
                        TR/f"{row.experiment_id}_r{run_idx}_n{pop}_b{budget}_{algo.replace('-','_')}.csv",index=False)
                        done.add(key)
                        print(f"[{len(done)}/{total}] {row.experiment_id} r{run_idx} n={pop} b={budget} {algo}: {rec['best_score']:.6f}, {dt:.2f}s")
    print("Done:",raw)

if __name__=="__main__": main()
