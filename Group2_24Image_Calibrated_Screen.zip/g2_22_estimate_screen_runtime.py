from pathlib import Path
import pandas as pd
BASE=Path(r"D:\48\481\New Papers\BDA_To_HHO_paper")
p=BASE/"Outputs"/"Group2_Calibrated_Pilot_Rerun"/"calibrated_pilot_raw.csv"
sec=float(pd.read_csv(p).runtime_s.median()) if p.exists() else 58.0
runs=24*3*3*4
t300=runs*sec*.75; t600=runs*sec*1.5
print(f"Anchor median at B=400: {sec:.2f} s/run")
print(f"Planned runs: {runs*2}")
print(f"Approx serial hours B=300: {t300/3600:.2f}")
print(f"Approx serial hours B=600: {t600/3600:.2f}")
print(f"Approx serial total: {(t300+t600)/3600:.2f}")
