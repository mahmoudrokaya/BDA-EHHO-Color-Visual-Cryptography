# Group 2 — 100-Image Validation Confirmation

Frozen configuration: **N=30, B=600**.

Design: 100 BSDS500 validation images × 5 runs/image × 4 algorithms = **2000 runs**.

This is a confirmation stage, not another tuning stage.

## Statistical analysis
Primary inferential unit = image. Each algorithm is summarized by its median over five runs for each of 100 images. Analysis includes Friedman, paired Wilcoxon, Holm correction, rank-biserial effect sizes, win/loss/tie counts, and bootstrap 95% CIs.

## Runtime fairness
Each algorithm gets a separate objective/cache object with the same objective seed, and execution order is deterministically randomized within each image/run.

## Run
```powershell
pip install scipy
python g2_27_estimate_confirmation_runtime.py
python g2_25_run_100image_confirmation.py
python g2_26_analyze_100image_confirmation.py
```

Outputs go to:
`D:\48\481\New Papers\BDA_To_HHO_paper\Outputs\Group2_100Image_Confirmation`
