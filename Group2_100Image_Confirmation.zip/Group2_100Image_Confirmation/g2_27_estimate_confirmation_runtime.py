from pathlib import Path
import pandas as pd
BASE=Path(r"D:\48\481\New Papers\BDA_To_HHO_paper")
p=BASE/"Outputs"/"Group2_24Image_Screen"/"screen_raw_results.csv"
if p.exists():
    x=pd.read_csv(p); x=x[(x.population_size==30)&(x.evaluation_budget==600)]; sec=float(x.runtime_s.mean()) if len(x) else 15.0
else: sec=15.0
runs=2000
print(f"Anchor mean seconds/run: {sec:.2f}")
print(f"Planned runs: {runs}")
print(f"Approx serial runtime: {runs*sec/3600:.2f} hours")
print("Confirmation uses separate per-algorithm caches for runtime fairness and is resumable.")
