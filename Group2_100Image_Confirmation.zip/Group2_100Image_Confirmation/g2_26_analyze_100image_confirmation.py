#!/usr/bin/env python3
from pathlib import Path
import itertools, json, numpy as np, pandas as pd
from scipy.stats import friedmanchisquare, wilcoxon
BASE=Path(r"D:\48\481\New Papers\BDA_To_HHO_paper"); OUT=BASE/"Outputs"/"Group2_100Image_Confirmation"
ALGOS=["HHO-VC","EHHO-VC","BEHHO-VC-Calibrated","BDA-EHHO-VC-Calibrated"]

def holm(p):
    p=np.asarray(p,float); m=len(p); order=np.argsort(p); out=np.empty(m); run=0
    for rank,idx in enumerate(order):
        run=max(run,(m-rank)*p[idx]); out[idx]=min(run,1.0)
    return out

def rb(x,y):
    d=np.asarray(x)-np.asarray(y); d=d[d!=0]
    if len(d)==0:return 0.0
    order=np.argsort(np.abs(d)); ranks=np.empty(len(d),float); a=np.abs(d)[order]; s=0; rank=1
    while s<len(d):
        e=s+1
        while e<len(d) and a[e]==a[s]: e+=1
        av=np.mean(np.arange(rank,rank+e-s)); ranks[order[s:e]]=av; rank+=e-s; s=e
    wp=ranks[d>0].sum(); wn=ranks[d<0].sum(); den=wp+wn
    return float((wp-wn)/den) if den else 0.0

def boot(x,y,seed,B=5000):
    rng=np.random.default_rng(seed); d=np.asarray(x)-np.asarray(y); n=len(d); v=np.empty(B)
    for i in range(B): v[i]=np.median(d[rng.integers(0,n,size=n)])
    lo,hi=np.percentile(v,[2.5,97.5]); return float(np.median(d)),float(lo),float(hi)

def main():
    raw=pd.read_csv(OUT/"confirmation_raw_results.csv"); expected=2000
    completion=len(raw)==expected; budget=bool(raw.budget_compliant.astype(bool).all())
    runs=(raw.groupby("algorithm").agg(runs=("best_score","size"),mean_best_score=("best_score","mean"),median_best_score=("best_score","median"),sd_best_score=("best_score","std"),median_runtime_s=("runtime_s","median"),mean_runtime_s=("runtime_s","mean"),median_cache_hit_rate=("cache_hit_rate","median")).reset_index())
    runs.to_csv(OUT/"run_level_summary.csv",index=False,encoding="utf-8-sig")
    img=(raw.groupby(["experiment_id","algorithm"]).agg(median_score=("best_score","median"),mean_score=("best_score","mean"),sd_across_runs=("best_score","std"),median_runtime_s=("runtime_s","median")).reset_index())
    img.to_csv(OUT/"image_level_summary.csv",index=False,encoding="utf-8-sig")
    piv=img.pivot(index="experiment_id",columns="algorithm",values="median_score")
    if len(piv)!=100: raise RuntimeError(f"Expected 100 paired images, found {len(piv)}")
    fr=friedmanchisquare(*[piv[a].to_numpy() for a in ALGOS])
    rows=[]; ps=[]
    for k,(a,b) in enumerate(itertools.combinations(ALGOS,2)):
        x=piv[a].to_numpy(); y=piv[b].to_numpy(); d=x-y
        try: w=wilcoxon(x,y,alternative="two-sided",zero_method="pratt",method="auto"); stat=float(w.statistic); p=float(w.pvalue)
        except ValueError: stat=0.0; p=1.0
        med,lo,hi=boot(x,y,20260913+k)
        rows.append({"algorithm_A":a,"algorithm_B":b,"median_difference_A_minus_B":med,"bootstrap95_lo":lo,"bootstrap95_hi":hi,"wilcoxon_statistic":stat,"p_raw":p,"rank_biserial_A_minus_B":rb(x,y),"wins_A":int(np.sum(d<-1e-12)),"wins_B":int(np.sum(d>1e-12)),"ties":int(np.sum(np.abs(d)<=1e-12))}); ps.append(p)
    adj=holm(ps)
    for r,p in zip(rows,adj): r["p_holm"]=float(p); r["significant_holm_0_05"]=bool(p<.05)
    pair=pd.DataFrame(rows); pair.to_csv(OUT/"pairwise_statistics.csv",index=False,encoding="utf-8-sig")
    ranks=piv.rank(axis=1,method="average",ascending=True).mean(axis=0).sort_values().rename("mean_image_rank").reset_index()
    ranks.to_csv(OUT/"image_level_average_ranks.csv",index=False,encoding="utf-8-sig")
    b=raw[raw.algorithm=="BEHHO-VC-Calibrated"]; h=raw[raw.algorithm=="BDA-EHHO-VC-Calibrated"]
    inj=100*np.mean(b.injection_count>0); bf=float(h.bda_fraction.mean()); mech_ok=10<=inj<=75 and .35<=bf<=.65
    mech=pd.DataFrame([{"algorithm":"BEHHO-VC-Calibrated","runs":len(b),"mean_injections":b.injection_count.mean(),"pct_runs_with_injection":inj,"mean_diversity":b.diversity_mean.mean(),"mean_final_diversity":b.diversity_final.mean(),"mean_bda_fraction":np.nan,"mean_ehho_fraction":np.nan},{"algorithm":"BDA-EHHO-VC-Calibrated","runs":len(h),"mean_injections":np.nan,"pct_runs_with_injection":np.nan,"mean_diversity":np.nan,"mean_final_diversity":np.nan,"mean_bda_fraction":bf,"mean_ehho_fraction":1-bf}])
    mech.to_csv(OUT/"mechanism_confirmation.csv",index=False,encoding="utf-8-sig")
    decision={"completion_pass":completion,"budget_compliance_pass":budget,"mechanism_health_pass":mech_ok,"friedman_statistic":float(fr.statistic),"friedman_p":float(fr.pvalue),"frozen_population_size":30,"frozen_evaluation_budget":600,"status":"GROUP2_CONFIRMATION_COMPLETE" if completion and budget and mech_ok else "REVIEW_REQUIRED","note":"No additional Group-2 parameter tuning permitted."}
    (OUT/"confirmation_decision.json").write_text(json.dumps(decision,indent=2),encoding="utf-8")
    report=["# Group 2 — 100-Image Validation Confirmation","",f"- Completed runs: **{len(raw)}/{expected}**",f"- Completion: **{'PASS' if completion else 'REVIEW'}**",f"- Budget compliance: **{'PASS' if budget else 'REVIEW'}**","- Frozen configuration: **N=30, B=600**","- Primary inferential unit: **100 paired images**; each algorithm is summarized by its median across five runs/image.","","## Run-level descriptive summary","",runs.to_markdown(index=False),"","## Image-level average ranks","",ranks.to_markdown(index=False),"","## Friedman omnibus test","",f"Statistic: **{fr.statistic:.6f}**",f"p-value: **{fr.pvalue:.6g}**","","## Pairwise Wilcoxon + Holm","",pair.to_markdown(index=False),"","## Mechanism confirmation","",mech.to_markdown(index=False),"",f"Mechanism health: **{'PASS' if mech_ok else 'REVIEW'}**","","No further parameter tuning should be performed after this confirmation."]
    (OUT/"confirmation_analysis_report.md").write_text("\n".join(report),encoding="utf-8")
    try:
        with pd.ExcelWriter(OUT/"confirmation_analysis.xlsx",engine="openpyxl") as w:
            runs.to_excel(w,sheet_name="Run Summary",index=False); img.to_excel(w,sheet_name="Image Level",index=False); ranks.to_excel(w,sheet_name="Average Ranks",index=False); pair.to_excel(w,sheet_name="Pairwise Stats",index=False); mech.to_excel(w,sheet_name="Mechanisms",index=False)
    except Exception as e: print("Excel export skipped:",e)
    print("Friedman p =",fr.pvalue); print("Report:",OUT/"confirmation_analysis_report.md")
if __name__=="__main__": main()
