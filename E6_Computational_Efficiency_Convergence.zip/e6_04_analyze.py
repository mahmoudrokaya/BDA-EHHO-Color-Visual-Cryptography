#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
E6 analysis.

Primary paired efficiency analysis:
- same 12 images x 2 runs x 5 methods from e6_03;
- image median across two runs is the inferential unit;
- Friedman runtime test across five methods;
- paired Wilcoxon each scalar method vs MO, Holm corrected;
- runtime per 100 logical evaluations and evaluations/second.

Convergence analysis:
A) Scalar methods:
   Normalize each native best-so-far scalar trace from 0 to 1 terminal progress.
   Report fraction of trace required to reach 90%, 95%, 99% of terminal
   improvement. Compare ONLY the four scalar methods because they share the
   scalar convergence concept.
B) MO-BDA-EHHO:
   Report archive-growth fractions to 90%, 95%, 99% final archive size plus
   terminal hypervolume/archive cardinality. This is reported separately; it
   is not falsely treated as the same convergence indicator as scalar fitness.

Large-stage operational timing:
- Group2 100-image confirmation runtimes for the four scalar methods;
- E4 100-image MO runtimes for MO.
These provide 500-run descriptive context only, not paired inferential timing.
"""

from __future__ import annotations
import json
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.stats import friedmanchisquare,wilcoxon

from e6_01_common import (
    ALGORITHMS,SO_ALGORITHMS,MO_ALGORITHM,
    normalized_progress_min,first_fraction_at
)

BASE=Path(r"D:\48\481\New Papers\BDA_To_HHO_paper")
OUT=BASE/"Outputs"/"E6_Computational_Efficiency_Convergence"
TRACE=OUT/"traces"

G2=BASE/"Outputs"/"Group2_100Image_Confirmation"/"confirmation_raw_results.csv"
E4=BASE/"Outputs"/"E4_Multiobjective_Comparison"/"e4_mo_run_summary.csv"

def holm(pvals):
    p=np.asarray(pvals,float);m=len(p);order=np.argsort(p);adj=np.empty(m);run=0.
    for k,i in enumerate(order):
        run=max(run,(m-k)*p[i]);adj[i]=min(run,1.)
    return adj

def rank_biserial(x,y):
    d=np.asarray(x,float)-np.asarray(y,float)
    d=d[np.abs(d)>1e-15]
    if not len(d):return 0.0
    from scipy.stats import rankdata
    r=rankdata(np.abs(d))
    return float((r[d>0].sum()-r[d<0].sum())/r.sum())

def image_median(df,col):
    x=df.groupby(["experiment_id","algorithm"])[col].median().reset_index()
    return x.pivot(index="experiment_id",columns="algorithm",values=col)

def main():
    raw=pd.read_csv(OUT/"e6_paired_benchmark_raw.csv")
    expected=12*2*5
    if len(raw)!=expected:
        raise RuntimeError(f"Expected {expected} E6 paired runs, found {len(raw)}.")

    raw["seconds_per_100_evals"]=100.0*raw["runtime_s"]/raw["evaluations"].replace(0,np.nan)
    raw["evals_per_second"]=raw["evaluations"]/raw["runtime_s"]

    paired_summary=(
        raw.groupby("algorithm")
        .agg(
            runs=("runtime_s","size"),
            median_runtime_s=("runtime_s","median"),
            mean_runtime_s=("runtime_s","mean"),
            sd_runtime_s=("runtime_s","std"),
            median_seconds_per_100_evals=("seconds_per_100_evals","median"),
            median_evals_per_second=("evals_per_second","median"),
            median_iterations=("iterations_completed","median"),
            median_cache_hit_rate=("cache_hit_rate","median"),
        )
        .reset_index()
    )
    paired_summary.to_csv(
        OUT/"e6_paired_runtime_summary.csv",index=False,encoding="utf-8-sig"
    )

    # Paired image-level runtime inference.
    piv=image_median(raw,"runtime_s")
    fr=friedmanchisquare(*[piv[a].to_numpy() for a in ALGORITHMS])

    mo=piv[MO_ALGORITHM].to_numpy()
    pair=[];ps=[]
    for alg in SO_ALGORITHMS:
        x=piv[alg].to_numpy()
        w=wilcoxon(x,mo,zero_method="pratt",alternative="two-sided",method="auto")
        d=x-mo
        pair.append({
            "algorithm_A":alg,
            "algorithm_B":MO_ALGORITHM,
            "median_runtime_difference_A_minus_MO_s":float(np.median(d)),
            "wilcoxon_statistic":float(w.statistic),
            "p_raw":float(w.pvalue),
            "rank_biserial_A_minus_MO":rank_biserial(x,mo),
            "wins_faster_MO":int(np.sum(mo<x)),
            "wins_faster_A":int(np.sum(x<mo)),
            "ties":int(np.sum(np.abs(d)<=1e-12)),
        })
        ps.append(float(w.pvalue))
    adj=holm(ps)
    for r,p in zip(pair,adj):
        r["p_holm"]=float(p);r["significant_holm_0_05"]=bool(p<.05)
    pairdf=pd.DataFrame(pair)
    pairdf.to_csv(
        OUT/"e6_runtime_pairwise_vs_mo.csv",index=False,encoding="utf-8-sig"
    )

    # Scalar convergence thresholds.
    conv_rows=[]
    for _,r in raw[raw["algorithm"].isin(SO_ALGORITHMS)].iterrows():
        p=TRACE/f"{r['experiment_id']}_r{int(r['run_index'])}_{r['algorithm'].replace('-','_')}.csv"
        t=pd.read_csv(p)["native_trace"].to_numpy(float)
        prog=normalized_progress_min(t)
        conv_rows.append({
            "experiment_id":r["experiment_id"],
            "run_index":int(r["run_index"]),
            "algorithm":r["algorithm"],
            "trace_points":len(t),
            "fraction_to_90pct_terminal":first_fraction_at(prog,.90),
            "fraction_to_95pct_terminal":first_fraction_at(prog,.95),
            "fraction_to_99pct_terminal":first_fraction_at(prog,.99),
        })
    conv=pd.DataFrame(conv_rows)
    conv.to_csv(
        OUT/"e6_scalar_convergence_runs.csv",index=False,encoding="utf-8-sig"
    )
    conv_summary=(
        conv.groupby("algorithm")
        .agg(
            median_fraction_to_90=("fraction_to_90pct_terminal","median"),
            median_fraction_to_95=("fraction_to_95pct_terminal","median"),
            median_fraction_to_99=("fraction_to_99pct_terminal","median"),
            median_trace_points=("trace_points","median"),
        )
        .reset_index()
    )
    conv_summary.to_csv(
        OUT/"e6_scalar_convergence_summary.csv",index=False,encoding="utf-8-sig"
    )

    # Friedman among scalar methods for fraction-to-95 only.
    c95=conv.groupby(["experiment_id","algorithm"])["fraction_to_95pct_terminal"].median().unstack()
    scalar_conv_test={}
    if all(a in c95.columns for a in SO_ALGORITHMS):
        cf=friedmanchisquare(*[c95[a].to_numpy() for a in SO_ALGORITHMS])
        scalar_conv_test={
            "metric":"fraction_to_95pct_terminal_scalar_improvement",
            "friedman_statistic":float(cf.statistic),
            "friedman_p":float(cf.pvalue),
        }

    # MO archive growth.
    mo_rows=[]
    for _,r in raw[raw["algorithm"]==MO_ALGORITHM].iterrows():
        p=TRACE/f"{r['experiment_id']}_r{int(r['run_index'])}_{MO_ALGORITHM.replace('-','_')}.csv"
        g=pd.read_csv(p)["native_trace"].to_numpy(float)
        mo_rows.append({
            "experiment_id":r["experiment_id"],
            "run_index":int(r["run_index"]),
            "fraction_to_90pct_final_archive":first_fraction_at(g,.90),
            "fraction_to_95pct_final_archive":first_fraction_at(g,.95),
            "fraction_to_99pct_final_archive":first_fraction_at(g,.99),
            "final_hypervolume":r["final_hypervolume"],
            "archive_size":r["archive_size"],
        })
    mog=pd.DataFrame(mo_rows)
    mog.to_csv(
        OUT/"e6_mo_convergence_runs.csv",index=False,encoding="utf-8-sig"
    )
    mo_summary=pd.DataFrame([{
        "runs":len(mog),
        "median_fraction_to_90pct_final_archive":mog["fraction_to_90pct_final_archive"].median(),
        "median_fraction_to_95pct_final_archive":mog["fraction_to_95pct_final_archive"].median(),
        "median_fraction_to_99pct_final_archive":mog["fraction_to_99pct_final_archive"].median(),
        "median_final_hypervolume":mog["final_hypervolume"].median(),
        "median_archive_size":mog["archive_size"].median(),
    }])
    mo_summary.to_csv(
        OUT/"e6_mo_convergence_summary.csv",index=False,encoding="utf-8-sig"
    )

    # Existing large-stage operational timing context.
    op=[]
    if G2.exists():
        g2=pd.read_csv(G2)
        for alg,g in g2.groupby("algorithm"):
            if alg in SO_ALGORITHMS:
                op.append({
                    "stage":"Group2_100Image_Confirmation",
                    "algorithm":alg,
                    "runs":len(g),
                    "median_runtime_s":float(g["runtime_s"].median()),
                    "mean_runtime_s":float(g["runtime_s"].mean()),
                    "paired_for_inference":False,
                })
    if E4.exists():
        e4=pd.read_csv(E4)
        op.append({
            "stage":"E4_MO_100Image",
            "algorithm":MO_ALGORITHM,
            "runs":len(e4),
            "median_runtime_s":float(e4["runtime_s"].median()),
            "mean_runtime_s":float(e4["runtime_s"].mean()),
            "paired_for_inference":False,
        })
    operational=pd.DataFrame(op)
    operational.to_csv(
        OUT/"e6_large_stage_runtime_context.csv",index=False,encoding="utf-8-sig"
    )

    decision={
        "experiment":"E6 computational efficiency and convergence",
        "paired_benchmark_runs":int(len(raw)),
        "paired_images":12,
        "runs_per_image":2,
        "population":30,
        "budget":600,
        "runtime_friedman_statistic":float(fr.statistic),
        "runtime_friedman_p":float(fr.pvalue),
        "scalar_convergence_test":scalar_conv_test,
        "interpretation_note":(
            "Runtime is directly compared in the paired E6 benchmark. "
            "Scalar convergence and MO archive-growth convergence are reported separately "
            "because they are different native quality indicators. Large-stage Group2/E4 "
            "timings are descriptive context only."
        )
    }
    (OUT/"e6_decision.json").write_text(
        json.dumps(decision,indent=2),encoding="utf-8"
    )

    report=[
        "# E6 — Computational Efficiency and Convergence Analysis","",
        "## Paired benchmark design","",
        "- 12 common BSDS500 validation images.",
        "- 2 independent runs/image.",
        "- Five frozen methods.",
        "- Frozen N=30, B=600.",
        "- Deterministically randomized execution order within image/run.",
        "- Separate objective/cache instance per method.",
        "- Image median is the inferential unit for runtime.","",
        "## Paired runtime summary","",paired_summary.to_markdown(index=False),"",
        "## Runtime omnibus test","",
        f"- Friedman statistic: **{fr.statistic:.6f}**",
        f"- p-value: **{fr.pvalue:.6g}**","",
        "## Runtime pairwise comparisons against MO","",pairdf.to_markdown(index=False),"",
        "## Scalar-method convergence","",
        "Fractions indicate the proportion of the native convergence trace required to achieve 90%, 95%, or 99% of terminal scalar improvement.",
        "",conv_summary.to_markdown(index=False),"",
        "## MO convergence","",
        "MO convergence is described separately using archive growth and final fixed-reference hypervolume; it is not treated as numerically equivalent to scalar best-fitness convergence.",
        "",mo_summary.to_markdown(index=False),"",
        "## Large-stage operational timing context","",
        operational.to_markdown(index=False) if len(operational) else "No large-stage timing files found.","",
        "## Interpretation discipline","",
        "A slower MO runtime is expected because each candidate is evaluated on four objectives and an external Pareto archive is maintained. "
        "E6 should therefore report the computational premium explicitly rather than hide it. The benefit/cost interpretation should be linked to the much stronger E4 Pareto-set quality."
    ]
    (OUT/"e6_analysis_report.md").write_text(
        "\n".join(report),encoding="utf-8"
    )

    try:
        with pd.ExcelWriter(OUT/"e6_analysis.xlsx",engine="openpyxl") as w:
            paired_summary.to_excel(w,sheet_name="Runtime Summary",index=False)
            pairdf.to_excel(w,sheet_name="Runtime Pairwise",index=False)
            conv_summary.to_excel(w,sheet_name="Scalar Convergence",index=False)
            mo_summary.to_excel(w,sheet_name="MO Convergence",index=False)
            operational.to_excel(w,sheet_name="Large Stage Context",index=False)
            raw.to_excel(w,sheet_name="Raw Benchmark",index=False)
    except Exception as exc:
        print("Excel export skipped:",exc)

    print("E6 analysis complete.")
    print("Report:",OUT/"e6_analysis_report.md")

if __name__=="__main__":
    main()
