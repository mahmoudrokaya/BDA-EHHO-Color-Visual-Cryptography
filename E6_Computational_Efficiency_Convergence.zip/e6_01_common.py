#!/usr/bin/env python3
from __future__ import annotations
import hashlib, numpy as np

ALGORITHMS=[
    "HHO-VC",
    "EHHO-VC",
    "BEHHO-VC-Calibrated",
    "BDA-EHHO-VC-Calibrated",
    "MO-BDA-EHHO-VC",
]
SO_ALGORITHMS=ALGORITHMS[:-1]
MO_ALGORITHM=ALGORITHMS[-1]

POPULATION=30
BUDGET=600
SUBSET_IMAGES=12
RUNS_PER_IMAGE=2
BASE_SEED=20260914

def stable_seed(*parts):
    d=hashlib.sha256("|".join(map(str,parts)).encode()).digest()
    return int.from_bytes(d[:4],"little") & 0x7fffffff

def run_seed(experiment_id,run_index):
    return stable_seed(BASE_SEED,experiment_id,run_index,"E6")

def normalized_progress_min(trace):
    x=np.asarray(trace,float)
    if len(x)==0:return np.asarray([],float)
    start=x[0]; end=x[-1]
    denom=start-end
    if abs(denom)<=1e-15:
        return np.ones(len(x),float)
    p=(start-x)/denom
    return np.clip(p,0,1)

def normalized_progress_max(trace):
    x=np.asarray(trace,float)
    if len(x)==0:return np.asarray([],float)
    start=x[0]; end=x[-1]
    denom=end-start
    if abs(denom)<=1e-15:
        return np.ones(len(x),float)
    p=(x-start)/denom
    return np.clip(p,0,1)

def first_fraction_at(progress,threshold):
    p=np.asarray(progress,float)
    idx=np.where(p>=threshold)[0]
    if len(idx)==0:return np.nan
    # 1-based fraction of trace length.
    return float((idx[0]+1)/len(p))
