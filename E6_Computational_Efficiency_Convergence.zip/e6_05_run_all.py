#!/usr/bin/env python3
import subprocess,sys
for s in ["e6_03_run_paired_benchmark.py","e6_04_analyze.py"]:
    print("="*78);print("RUNNING",s);print("="*78)
    r=subprocess.run([sys.executable,s])
    if r.returncode!=0:
        raise SystemExit(f"{s} failed with return code {r.returncode}")
print("="*78)
print("E6 COMPUTATIONAL EFFICIENCY + CONVERGENCE: COMPLETE")
print("="*78)
