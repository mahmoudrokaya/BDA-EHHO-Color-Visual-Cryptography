# E6 — Computational Efficiency and Convergence Analysis

E6 is the final experiment in the E1–E6 chain.

## Why a dedicated E6 benchmark is needed

The large Group-2 and E4 experiments were run in different stages and with
different objective functions. Their runtimes are useful descriptive context,
but they should not be treated as a perfectly paired runtime comparison.

E6 therefore adds a compact, same-session paired benchmark.

## Paired benchmark

- 12 common BSDS500 validation images
- 2 independent runs/image
- 5 frozen methods
- N = 30
- B = 600
- 120 total runs
- deterministic randomized method order within image/run
- separate objective/cache object per method

No parameter tuning is allowed.

## Runtime measures

For every run:
- wall-clock runtime
- logical evaluation count
- seconds per 100 evaluations
- evaluations per second
- iteration count
- cache hit rate

Runtime inference uses the image median across the two runs.

## Convergence

### Scalar methods
HHO, EHHO, BEHHO and BDA-EHHO use their native best-so-far scalar convergence traces.

For each run, the trace is normalized to terminal progress and E6 reports the
fraction of the trace required to reach:
- 90%
- 95%
- 99%

of the final scalar improvement.

These four scalar methods can be compared with each other using this indicator.

### MO-BDA-EHHO
MO optimization does not have a single scalar best-fitness trajectory.

Therefore E6 does NOT manufacture one.

It reports:
- normalized Pareto-archive growth trajectory
- fraction of the trace required to reach 90/95/99% of final archive size
- terminal fixed-reference hypervolume
- final archive cardinality

MO convergence is reported separately from scalar convergence.

## Large-stage timing context

The analysis also reads:
- Group2_100Image_Confirmation runtimes
- E4 MO 100-image runtimes

These 500-run-per-method values are reported as descriptive operational context
only, not as paired inferential timing.

## Run order

Copy these files into:

`D:\48\481\New Papers\BDA_To_HHO_paper\Codes\Group3_MO_BDA_EHHO`

Then:

```powershell
pip install -r requirements_e6.txt
python e6_05_run_all.py
```

Or individually:

```powershell
python e6_03_run_paired_benchmark.py
python e6_04_analyze.py
```

The benchmark runner is resumable.

## Outputs

`D:\48\481\New Papers\BDA_To_HHO_paper\Outputs\E6_Computational_Efficiency_Convergence`

Important files:
- e6_analysis_report.md
- e6_decision.json
- e6_paired_runtime_summary.csv
- e6_runtime_pairwise_vs_mo.csv
- e6_scalar_convergence_summary.csv
- e6_mo_convergence_summary.csv
- e6_large_stage_runtime_context.csv
- e6_analysis.xlsx

## Interpretation

A larger MO runtime should not automatically be interpreted as failure.
MO-BDA-EHHO evaluates four objectives and maintains a Pareto archive, so it is
expected to have a computational premium.

The paper should report that premium explicitly and interpret it against the
substantially better Pareto-set quality established in E4.
