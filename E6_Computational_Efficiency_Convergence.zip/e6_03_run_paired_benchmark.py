#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
E6 paired runtime/convergence benchmark.

Purpose
-------
Provide a fair, same-session paired benchmark for all five frozen methods.

Design
------
- same 12 BSDS500 validation images used in earlier pilot validation;
- 2 independent runs/image;
- 5 frozen methods;
- N=30, B=600;
- deterministic randomized algorithm order within image/run;
- separate objective/cache instance per algorithm;
- same image/run seed within each optimization family;
- no parameter tuning.

Runtime interpretation
----------------------
The SO methods evaluate the original frozen scalar VC objective.
MO-BDA-EHHO evaluates four frozen objectives and maintains a Pareto archive.
Thus runtime measures actual end-to-end computational cost of each frozen
method, not identical cost per objective evaluation.

Convergence
-----------
SO: native best-so-far scalar convergence trace.
MO: archive-growth trace returned by the frozen optimizer, plus final fixed-
reference hypervolume. No intermediate MO hypervolume is fabricated.
"""

from __future__ import annotations
import csv,time,hashlib
from pathlib import Path
import numpy as np,pandas as pd

from g1_02_rgb_decomposition import load_rgb
from g2_01_common_vc_adapter import FrozenVCObjective
from g2_02_hho_vc import optimize_hho_vc
from g2_03_ehho_vc import optimize_ehho_vc
from g2_13_calibrated_behho_vc import optimize_calibrated_behho_vc
from g2_14_calibrated_bda_ehho_vc import optimize_calibrated_bda_ehho_vc
from g3_17_multiobjective_vc_final import MultiObjectiveVCProblemFinal

from e6_01_common import (
    ALGORITHMS,SO_ALGORITHMS,MO_ALGORITHM,
    POPULATION,BUDGET,RUNS_PER_IMAGE,run_seed
)
from e6_02_mo_trace_optimizer import run_mo_with_trace

BASE=Path(r"D:\48\481\New Papers\BDA_To_HHO_paper")
DATA=BASE/"Data"
SEL=BASE/"Outputs"/"Group2_Validation_Tuning"/"pilot"/"selected_validation_images.csv"
OUT=BASE/"Outputs"/"E6_Computational_Efficiency_Convergence"
TRACE=OUT/"traces"

FIELDS=[
    "run_key","experiment_id","filename","run_index","algorithm","algorithm_order",
    "runtime_s","evaluations","budget_compliant","iterations_completed",
    "trace_points","terminal_native_value","final_hypervolume",
    "archive_size","bda_fraction","cache_hit_rate"
]

def append(path,row):
    new=not path.exists()
    with path.open("a",newline="",encoding="utf-8-sig") as f:
        w=csv.DictWriter(f,fieldnames=FIELDS)
        if new:w.writeheader()
        w.writerow(row);f.flush()

def existing(path):
    if not path.exists():return set()
    return set(pd.read_csv(path,usecols=["run_key"])["run_key"].astype(str))

def nominal_iterations():
    return max(30,int(np.ceil(BUDGET/POPULATION))*3)

def run_so(name,objective,seed):
    kw=dict(
        population_size=POPULATION,
        max_iterations=nominal_iterations(),
        max_evaluations=BUDGET,
        seed=seed,
    )
    if name=="HHO-VC":
        return optimize_hho_vc(objective,**kw)
    if name=="EHHO-VC":
        return optimize_ehho_vc(objective,**kw)
    if name=="BEHHO-VC-Calibrated":
        return optimize_calibrated_behho_vc(
            objective,**kw,
            diversity_threshold=.70,
            injection_fraction=.30,
        )
    if name=="BDA-EHHO-VC-Calibrated":
        return optimize_calibrated_bda_ehho_vc(
            objective,**kw,
            rho_max=.70,rho_min=.30,
        )
    raise ValueError(name)

def main():
    OUT.mkdir(parents=True,exist_ok=True);TRACE.mkdir(exist_ok=True)
    sel=pd.read_csv(SEL)
    if len(sel)!=12:raise RuntimeError(f"Expected 12 pilot images, found {len(sel)}.")

    raw=OUT/"e6_paired_benchmark_raw.csv"
    done=existing(raw);total=12*RUNS_PER_IMAGE*len(ALGORITHMS)

    for _,row in sel.iterrows():
        image=load_rgb(DATA/row["relative_to_data"],True)

        for run_idx in range(1,RUNS_PER_IMAGE+1):
            seed=run_seed(row["experiment_id"],run_idx)
            rng=np.random.default_rng(
                int(hashlib.sha256(f"{seed}|order".encode()).hexdigest()[:8],16)
            )
            order=list(ALGORITHMS);rng.shuffle(order)

            for pos,name in enumerate(order,start=1):
                key=f"{row['experiment_id']}|r{run_idx}|{name}"
                if key in done:continue

                t0=time.perf_counter()

                if name in SO_ALGORITHMS:
                    objective=FrozenVCObjective.from_seed(image,seed)
                    result=run_so(name,objective,seed)
                    dt=time.perf_counter()-t0
                    d=result.__dict__.copy()
                    trace=list(d.get("convergence",[]))
                    final_hv=np.nan
                    archive_size=np.nan
                    bda=d.get("bda_fraction",np.nan)
                    if not np.isfinite(bda):
                        bp=float(d.get("bda_proposals",0) or 0)
                        ep=float(d.get("ehho_proposals",0) or 0)
                        bda=bp/(bp+ep) if bp+ep else np.nan
                    cs=objective.cache_stats() if hasattr(objective,"cache_stats") else {}
                    hit=cs.get("hit_rate",np.nan)
                else:
                    objective=MultiObjectiveVCProblemFinal.from_seed(image,seed)
                    result,final_hv,growth=run_mo_with_trace(
                        objective,
                        population_size=POPULATION,
                        max_iterations=100,
                        max_evaluations=BUDGET,
                        seed=seed,
                        archive_size=100,
                        rho_max=.70,rho_min=.30,
                        diversity_threshold=.70,
                        injection_fraction=.30,
                    )
                    dt=time.perf_counter()-t0
                    d=result.__dict__.copy()
                    trace=growth
                    archive_size=len(result.archive_objectives)
                    bp=float(result.bda_proposals);ep=float(result.ehho_proposals)
                    bda=bp/(bp+ep) if bp+ep else np.nan
                    cs=objective.cache_stats();hit=cs.get("tuple_cache_hit_rate",np.nan)

                evals=int(d.get("evaluations",0))
                iterations=int(d.get("iterations_completed",len(trace)))

                pd.DataFrame({
                    "step":np.arange(1,len(trace)+1),
                    "native_trace":trace,
                }).to_csv(
                    TRACE/f"{row['experiment_id']}_r{run_idx}_{name.replace('-','_')}.csv",
                    index=False
                )

                rec={
                    "run_key":key,
                    "experiment_id":row["experiment_id"],
                    "filename":row["filename"],
                    "run_index":run_idx,
                    "algorithm":name,
                    "algorithm_order":pos,
                    "runtime_s":dt,
                    "evaluations":evals,
                    "budget_compliant":evals<=BUDGET,
                    "iterations_completed":iterations,
                    "trace_points":len(trace),
                    "terminal_native_value":float(trace[-1]) if trace else np.nan,
                    "final_hypervolume":final_hv,
                    "archive_size":archive_size,
                    "bda_fraction":bda,
                    "cache_hit_rate":hit,
                }
                append(raw,rec);done.add(key)
                print(
                    f"[{len(done)}/{total}] {row['experiment_id']} r{run_idx} "
                    f"{name}: {dt:.2f}s evals={evals} trace={len(trace)}"
                )

    print("E6 paired benchmark complete:",raw)

if __name__=="__main__":
    main()
