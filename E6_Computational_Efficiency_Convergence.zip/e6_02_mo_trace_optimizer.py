#!/usr/bin/env python3
"""
Trace-enabled wrapper around the frozen MO-BDA-EHHO implementation.

Rather than alter the optimizer, this wrapper records a reproducible proxy
trajectory from the archive-size/diversity histories already returned by the
frozen implementation, and computes the final hypervolume.

Important:
The primary E6 convergence comparison for MO uses archive hypervolume only at
the final state plus archive-growth trajectory as a secondary convergence
indicator. We do NOT fabricate intermediate hypervolume values that were not
recorded by the frozen optimizer.
"""
from __future__ import annotations
import numpy as np
from g3_03_mo_bda_ehho_vc import optimize_mo_bda_ehho_vc
from e4_04_pareto_metrics import hv_recursive

def run_mo_with_trace(problem,**kwargs):
    r=optimize_mo_bda_ehho_vc(problem,**kwargs)
    F=np.asarray(r.archive_objectives,float)
    # All final objectives are normalized to [0,1] by construction.
    final_hv=hv_recursive(F,np.full(4,1.05))
    archive_growth=np.asarray(r.archive_size_history,float)
    if len(archive_growth):
        archive_growth_norm=archive_growth/max(float(archive_growth[-1]),1.0)
    else:
        archive_growth_norm=np.asarray([],float)
    return r,float(final_hv),archive_growth_norm.tolist()
