#!/usr/bin/env python3
from __future__ import annotations
import numpy as np

def dominates(a,b,atol=1e-12):
    a=np.asarray(a,float); b=np.asarray(b,float)
    return bool(np.all(a<=b+atol) and np.any(a<b-atol))

def nondominated_mask(F):
    F=np.asarray(F,float); n=len(F); keep=np.ones(n,dtype=bool)
    for i in range(n):
        for j in range(n):
            if i!=j and dominates(F[j],F[i]): keep[i]=False; break
    return keep

def crowding_distance(F):
    F=np.asarray(F,float); n,m=F.shape
    if n==0: return np.asarray([],float)
    if n<=2: return np.full(n,np.inf)
    d=np.zeros(n)
    for k in range(m):
        order=np.argsort(F[:,k],kind="mergesort"); d[order[0]]=np.inf; d[order[-1]]=np.inf
        span=F[order[-1],k]-F[order[0],k]
        if span<=1e-15: continue
        for p in range(1,n-1):
            i=order[p]; d[i]+=(F[order[p+1],k]-F[order[p-1],k])/span
    return d

class ParetoArchive:
    def __init__(self,max_size=100):
        self.max_size=int(max_size); self.bits=[]; self.objectives=[]
    def __len__(self): return len(self.bits)
    def add(self,bits,objectives):
        b=np.asarray(bits,dtype=np.uint8).copy(); f=np.asarray(objectives,float).copy()
        for eb,ef in zip(self.bits,self.objectives):
            if np.array_equal(eb,b) and np.allclose(ef,f,rtol=0,atol=1e-15): return
        self.bits.append(b); self.objectives.append(f); self._filter()
    def _filter(self):
        F=np.vstack(self.objectives); mask=nondominated_mask(F)
        self.bits=[b for b,k in zip(self.bits,mask) if k]; self.objectives=[f for f,k in zip(self.objectives,mask) if k]
        while len(self.bits)>self.max_size:
            F=np.vstack(self.objectives); cd=crowding_distance(F); finite=np.where(np.isfinite(cd))[0]
            rem=finite[np.argmin(cd[finite])] if len(finite) else len(self.bits)//2
            self.bits.pop(int(rem)); self.objectives.pop(int(rem))
    def arrays(self):
        if not self.bits: return np.empty((0,24),np.uint8),np.empty((0,4),float)
        return np.vstack(self.bits),np.vstack(self.objectives)
    def select_leader(self,rng):
        B,F=self.arrays()
        if len(B)==1:return B[0].copy(),F[0].copy()
        cd=crowding_distance(F); finite=cd[np.isfinite(cd)]
        bw=2*np.max(finite) if len(finite) and np.max(finite)>0 else 2.0
        w=np.where(np.isfinite(cd),cd+1e-6,bw); w=np.maximum(w,1e-12); w/=w.sum()
        i=int(rng.choice(np.arange(len(B)),p=w)); return B[i].copy(),F[i].copy()
    def compromise_index(self,weights=None):
        _,F=self.arrays()
        if weights is None: weights=np.ones(F.shape[1])/F.shape[1]
        weights=np.asarray(weights,float); weights/=weights.sum()
        ideal=F.min(0); nadir=F.max(0); Z=(F-ideal)/np.maximum(nadir-ideal,1e-12)
        return int(np.argmin(np.sqrt(np.sum(weights*(Z**2),axis=1))))
