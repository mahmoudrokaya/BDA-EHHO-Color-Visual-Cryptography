#!/usr/bin/env python3
from __future__ import annotations
import csv,hashlib,time
from pathlib import Path
import numpy as np,pandas as pd
from g1_02_rgb_decomposition import load_rgb
from g3_01_multiobjective_vc import MultiObjectiveVCProblem
from g3_02_pareto_archive import nondominated_mask
from g3_03_mo_bda_ehho_vc import optimize_mo_bda_ehho_vc

BASE=Path(r"D:\48\481\New Papers\BDA_To_HHO_paper")
DATA=BASE/"Data"
SEL=BASE/"Outputs"/"Group2_Validation_Tuning"/"pilot"/"selected_validation_images.csv"
OUT=BASE/"Outputs"/"Group3_MO_Validation"
POP=30; BUDGET=600; RUNS=2; ARCHIVE=100; BASE_SEED=20260913
FIELDS=["run_key","experiment_id","filename","run_index","population_size","evaluation_budget","seed","runtime_s","evaluations",
"budget_compliant","archive_size","archive_all_nondominated","compromise_R","compromise_G","compromise_B",
"compromise_f_reconstruction","compromise_f_security","compromise_f_robustness","compromise_f_complexity",
"f1_min","f1_max","f2_min","f2_max","f3_min","f3_max","f4_min","f4_max","mean_diversity","final_diversity",
"injection_count","bda_proposals","ehho_proposals","bda_fraction","cache_hit_rate"]

def seed_from(*parts):
    d=hashlib.sha256("|".join(map(str,parts)).encode()).digest(); return int.from_bytes(d[:4],"little")&0x7fffffff

def append(path,row):
    new=not path.exists()
    with path.open("a",newline="",encoding="utf-8-sig") as f:
        w=csv.DictWriter(f,fieldnames=FIELDS)
        if new:w.writeheader()
        w.writerow(row);f.flush()

def existing(path):
    return set() if not path.exists() else set(pd.read_csv(path,usecols=["run_key"]).run_key.astype(str))

def run_once(image,seed):
    p=MultiObjectiveVCProblem.from_seed(image,seed,corruption_rates=(0.01,0.05),max_channel_cache_entries=48)
    t0=time.perf_counter()
    r=optimize_mo_bda_ehho_vc(p,population_size=POP,max_iterations=100,max_evaluations=BUDGET,seed=seed,
                              archive_size=ARCHIVE,rho_max=.70,rho_min=.30,diversity_threshold=.70,injection_fraction=.30)
    return p,r,time.perf_counter()-t0

def main():
    OUT.mkdir(parents=True,exist_ok=True); ad=OUT/"archives";ad.mkdir(exist_ok=True)
    sel=pd.read_csv(SEL)
    if len(sel)!=12:raise RuntimeError(f"Expected 12 images, found {len(sel)}")
    raw=OUT/"mo_validation_raw.csv";done=existing(raw);total=24;repro=False
    for _,row in sel.iterrows():
        image=load_rgb(DATA/row.relative_to_data,True)
        for run_idx in range(1,RUNS+1):
            seed=seed_from(BASE_SEED,row.experiment_id,run_idx,"MO");key=f"{row.experiment_id}|r{run_idx}"
            if key in done:continue
            p,r,dt=run_once(image,seed);B=np.asarray(r.archive_bits,np.uint8);F=np.asarray(r.archive_objectives,float)
            nd=bool(np.all(nondominated_mask(F)))
            if not repro:
                p2,r2,_=run_once(image,seed)
                if r.archive_bits!=r2.archive_bits or not np.allclose(F,np.asarray(r2.archive_objectives),rtol=0,atol=1e-12):
                    raise AssertionError("Same-seed reproducibility failed.")
                repro=True
            arc=pd.DataFrame(F,columns=["f_reconstruction","f_security","f_robustness","f_complexity"])
            arc["bits"]=["".join(map(str,x.tolist())) for x in B]
            arc.to_csv(ad/f"{row.experiment_id}_r{run_idx}_archive.csv",index=False,encoding="utf-8-sig")
            div=r.diversity_history;tot=r.bda_proposals+r.ehho_proposals;cs=p.cache_stats();co=r.compromise_objectives;lv=r.compromise_levels_rgb
            rec={"run_key":key,"experiment_id":row.experiment_id,"filename":row.filename,"run_index":run_idx,
                 "population_size":POP,"evaluation_budget":BUDGET,"seed":seed,"runtime_s":dt,"evaluations":r.evaluations,
                 "budget_compliant":r.evaluations<=BUDGET,"archive_size":len(F),"archive_all_nondominated":nd,
                 "compromise_R":lv[0],"compromise_G":lv[1],"compromise_B":lv[2],
                 "compromise_f_reconstruction":co[0],"compromise_f_security":co[1],"compromise_f_robustness":co[2],"compromise_f_complexity":co[3],
                 "f1_min":F[:,0].min(),"f1_max":F[:,0].max(),"f2_min":F[:,1].min(),"f2_max":F[:,1].max(),
                 "f3_min":F[:,2].min(),"f3_max":F[:,2].max(),"f4_min":F[:,3].min(),"f4_max":F[:,3].max(),
                 "mean_diversity":float(np.mean(div)) if div else np.nan,"final_diversity":float(div[-1]) if div else np.nan,
                 "injection_count":len(r.injection_iterations),"bda_proposals":r.bda_proposals,"ehho_proposals":r.ehho_proposals,
                 "bda_fraction":r.bda_proposals/tot if tot else np.nan,"cache_hit_rate":cs["tuple_cache_hit_rate"]}
            append(raw,rec);done.add(key)
            print(f"[{len(done)}/{total}] {row.experiment_id} r{run_idx}: archive={len(F)}, BDA={rec['bda_fraction']:.3f}, {dt:.2f}s")
    print("Validation complete:",raw)

if __name__=="__main__":main()
