# Group 3 — MO-BDA–EHHO Visual Cryptography

This package starts the multi-objective stage after Group 2 was frozen.

## Four minimization objectives

1. **Reconstruction quality** — normalized clean reconstruction MSE.
2. **Individual-share security** — bounded combination of inverse normalized secret-share MSE and absolute secret-share Pearson correlation.
3. **Robustness** — additional reconstruction MSE caused by deterministic 1% and 5% binary share corruption.
4. **Computational/representation complexity** — mean RGB group count divided by 255.

Wall-clock runtime remains an external evaluation metric, not an optimization objective.

## Algorithm
- 24-bit binary representation.
- External nondominated Pareto archive.
- Crowding-distance pruning and leader selection.
- Frozen BDA/EHHO budget schedule 0.70 -> 0.30.
- Frozen binary diversity trigger 0.70.
- Injection fraction 0.30.
- Dominance-based replacement.
- Equal-weight normalized compromise solution is for reporting only; the full archive is the primary MO result.

## Files
- `g3_01_multiobjective_vc.py`
- `g3_02_pareto_archive.py`
- `g3_03_mo_bda_ehho_vc.py`
- `g3_04_smoke_test.py`
- `g3_05_run_real_image_validation.py`
- `g3_06_analyze_real_image_validation.py`

## Setup

Create:
`D:\48\481\New Papers\BDA_To_HHO_paper\Codes\Group3_MO_BDA_EHHO`

Make Group 1 and Group 2 importable:

```powershell
$env:PYTHONPATH="D:\48\481\New Papers\BDA_To_HHO_paper\Codes\Group1_Common_VC_Core;D:\48\481\New Papers\BDA_To_HHO_paper\Codes\Group2_HHO_Progression"
```

## Run

```powershell
python g3_04_smoke_test.py
python g3_05_run_real_image_validation.py
python g3_06_analyze_real_image_validation.py
```

Outputs:
`D:\48\481\New Papers\BDA_To_HHO_paper\Outputs\Group3_MO_Validation`

This is an initial implementation/validation stage, not the final E4 comparative experiment.
