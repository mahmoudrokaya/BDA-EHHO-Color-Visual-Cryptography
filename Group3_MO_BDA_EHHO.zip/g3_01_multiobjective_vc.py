#!/usr/bin/env python3
from __future__ import annotations
from collections import OrderedDict
from dataclasses import dataclass, field
import numpy as np
from g1_03_vc_share_generation import generate_channel_shares
from g1_04_vc_reconstruction import xor_reconstruct
from g1_05_vc_solution_encoding import decode_channel_bits
from g1_06_vc_baseline_fitness import mse, pearson_cc

MAX_PIXEL_MSE=255.0**2

@dataclass
class MultiObjectiveVCProblem:
    image: np.ndarray
    random_fields: tuple
    corruption_masks: dict
    corruption_rates: tuple=(0.01,0.05)
    tuple_cache: dict=field(default_factory=dict,init=False,repr=False)
    channel_share_cache: OrderedDict=field(default_factory=OrderedDict,init=False,repr=False)
    max_channel_cache_entries: int=48
    cache_hits: int=0
    cache_misses: int=0

    @classmethod
    def from_seed(cls,image,seed,corruption_rates=(0.01,0.05),max_channel_cache_entries=48):
        if image.ndim!=3 or image.shape[2]!=3: raise ValueError("Expected HxWx3 RGB image.")
        ss=np.random.SeedSequence(seed); children=ss.spawn(3+2*len(corruption_rates))
        rf=tuple(np.random.default_rng(children[i]).random(image.shape[:2]) for i in range(3))
        masks={}; base=3
        for ri,rate in enumerate(corruption_rates):
            for si in (0,1):
                rng=np.random.default_rng(children[base+2*ri+si])
                masks[(float(rate),si)]=rng.random(image.shape)<float(rate)
        return cls(image,rf,masks,tuple(map(float,corruption_rates)),max_channel_cache_entries=max_channel_cache_entries)

    @staticmethod
    def clip_level(x): return int(np.clip(np.rint(x),2,255))

    def decode_bits24(self,bits24):
        x=np.asarray(bits24,dtype=np.uint8).ravel()
        if len(x)!=24: raise ValueError("Expected 24 bits.")
        return (decode_channel_bits(x[:8]),decode_channel_bits(x[8:16]),decode_channel_bits(x[16:24]))

    def _channel_shares(self,ch,level):
        level=self.clip_level(level); key=(int(ch),int(level))
        if key in self.channel_share_cache:
            val=self.channel_share_cache.pop(key); self.channel_share_cache[key]=val; return val
        s1,s2,meta=generate_channel_shares(self.image[...,ch],level,random_field=self.random_fields[ch])
        val=(s1,s2,meta); self.channel_share_cache[key]=val
        while len(self.channel_share_cache)>self.max_channel_cache_entries:
            self.channel_share_cache.popitem(last=False)
        return val

    def _build_shares(self,levels):
        a=[]; b=[]; meta={}
        for ch,name in enumerate(("R","G","B")):
            s1,s2,m=self._channel_shares(ch,levels[ch]); a.append(s1); b.append(s2); meta[name]=m
        return np.stack(a,-1),np.stack(b,-1),meta

    def _security(self,s1,s2):
        vals=[]
        for sh in (s1,s2):
            for ch in range(3):
                sec=self.image[...,ch]
                nmse=min(max(mse(sec,sh[...,ch])/MAX_PIXEL_MSE,0.0),1.0)
                cc=min(max(abs(pearson_cc(sec,sh[...,ch])),0.0),1.0)
                vals.append(0.5*(1.0-nmse)+0.5*cc)
        return float(np.mean(vals))

    def _robustness(self,s1,s2,clean_mse):
        vals=[]
        for rate in self.corruption_rates:
            a=s1.copy(); b=s2.copy()
            ma=self.corruption_masks[(float(rate),0)]; mb=self.corruption_masks[(float(rate),1)]
            a[ma]=255-a[ma]; b[mb]=255-b[mb]
            noisy=xor_reconstruct(a,b)
            vals.append(max(0.0,mse(self.image,noisy)-clean_mse)/MAX_PIXEL_MSE)
        return float(np.mean(vals))

    def evaluate_levels(self,levels_rgb):
        levels=tuple(self.clip_level(v) for v in levels_rgb)
        if levels in self.tuple_cache:
            self.cache_hits+=1; obj,det=self.tuple_cache[levels]; return obj.copy(),dict(det)
        self.cache_misses+=1
        s1,s2,meta=self._build_shares(levels); rec=xor_reconstruct(s1,s2)
        clean=mse(self.image,rec)
        obj=np.asarray([clean/MAX_PIXEL_MSE,self._security(s1,s2),self._robustness(s1,s2,clean),np.mean(levels)/255.0],float)
        det={"levels_rgb":levels,"clean_reconstruction_mse":float(clean),"objectives":obj.tolist(),"share_metadata":meta}
        self.tuple_cache[levels]=(obj.copy(),dict(det)); return obj,det

    def evaluate_bits24(self,bits24): return self.evaluate_levels(self.decode_bits24(bits24))

    def cache_stats(self):
        t=self.cache_hits+self.cache_misses
        return {"tuple_cache_entries":len(self.tuple_cache),"tuple_cache_hits":self.cache_hits,"tuple_cache_misses":self.cache_misses,
                "tuple_cache_hit_rate":self.cache_hits/t if t else 0.0,"channel_share_cache_entries":len(self.channel_share_cache)}
