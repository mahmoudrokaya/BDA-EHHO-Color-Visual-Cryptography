#!/usr/bin/env python3
from pathlib import Path
import json,numpy as np,pandas as pd
BASE=Path(r"D:\48\481\New Papers\BDA_To_HHO_paper")
OUT=BASE/"Outputs"/"Group3_MO_Validation"

def main():
    df=pd.read_csv(OUT/"mo_validation_raw.csv");expected=24
    completion=len(df)==expected;budget=bool(df.budget_compliant.astype(bool).all())
    nondom=bool(df.archive_all_nondominated.astype(bool).all());nonempty=bool((df.archive_size>0).all())
    inj=100*np.mean(df.injection_count>0);bda=float(df.bda_fraction.mean())
    mechanism=(10<=inj<=75 and .35<=bda<=.65)
    summary=pd.DataFrame([{"runs":len(df),"mean_archive_size":df.archive_size.mean(),"median_archive_size":df.archive_size.median(),
                           "min_archive_size":df.archive_size.min(),"max_archive_size":df.archive_size.max(),
                           "median_runtime_s":df.runtime_s.median(),"mean_runtime_s":df.runtime_s.mean(),
                           "pct_runs_with_injection":inj,"mean_bda_fraction":bda,"mean_ehho_fraction":1-bda,
                           "mean_tuple_cache_hit_rate":df.cache_hit_rate.mean()}])
    summary.to_csv(OUT/"mo_validation_summary.csv",index=False,encoding="utf-8-sig")
    ranges=pd.DataFrame([
        {"objective":"reconstruction","mean_min":df.f1_min.mean(),"mean_max":df.f1_max.mean()},
        {"objective":"security","mean_min":df.f2_min.mean(),"mean_max":df.f2_max.mean()},
        {"objective":"robustness","mean_min":df.f3_min.mean(),"mean_max":df.f3_max.mean()},
        {"objective":"complexity","mean_min":df.f4_min.mean(),"mean_max":df.f4_max.mean()}])
    ranges.to_csv(OUT/"objective_range_summary.csv",index=False,encoding="utf-8-sig")
    decision={"completion_pass":completion,"budget_compliance_pass":budget,"archive_nonempty_pass":nonempty,
              "archive_nondominance_pass":nondom,"mechanism_health_pass":mechanism,
              "status":"GROUP3_INITIAL_VALIDATION_PASS" if all([completion,budget,nonempty,nondom,mechanism]) else "REVIEW_REQUIRED",
              "next_stage":"Freeze Section 3.4 objective/evaluation definitions, then design E4 multi-objective comparison."}
    (OUT/"mo_validation_decision.json").write_text(json.dumps(decision,indent=2),encoding="utf-8")
    report=["# Group 3 — Initial MO-BDA–EHHO Validation","",
            f"- Completed runs: **{len(df)}/{expected}**",f"- Budget compliance: **{'PASS' if budget else 'REVIEW'}**",
            f"- Nonempty Pareto archives: **{'PASS' if nonempty else 'REVIEW'}**",
            f"- Every archive point nondominated: **{'PASS' if nondom else 'REVIEW'}**","",
            "## Archive/runtime summary","",summary.to_markdown(index=False),"",
            "## Objective ranges","",ranges.to_markdown(index=False),"",
            "## Mechanism health","",f"- Injection-active runs: **{inj:.2f}%**",
            f"- Mean BDA fraction: **{bda:.3f}**",f"- Mean EHHO fraction: **{1-bda:.3f}**",
            f"- Mechanism health: **{'PASS' if mechanism else 'REVIEW'}**","",
            "This stage validates implementation and Pareto behavior only; it does not yet claim superiority over the frozen single-objective methods."]
    (OUT/"mo_validation_report.md").write_text("\n".join(report),encoding="utf-8")
    try:
        with pd.ExcelWriter(OUT/"mo_validation.xlsx",engine="openpyxl") as w:
            df.to_excel(w,sheet_name="Runs",index=False);summary.to_excel(w,sheet_name="Summary",index=False);ranges.to_excel(w,sheet_name="Objective Ranges",index=False)
    except Exception as e:print("Excel export skipped:",e)
    print("Report:",OUT/"mo_validation_report.md")

if __name__=="__main__":main()
