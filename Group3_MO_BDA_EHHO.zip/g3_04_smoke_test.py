#!/usr/bin/env python3
import numpy as np
from g3_01_multiobjective_vc import MultiObjectiveVCProblem
from g3_02_pareto_archive import nondominated_mask
from g3_03_mo_bda_ehho_vc import optimize_mo_bda_ehho_vc

rng=np.random.default_rng(42)
img=rng.integers(0,256,size=(32,40,3),dtype=np.uint8)
p=MultiObjectiveVCProblem.from_seed(img,123)
r=optimize_mo_bda_ehho_vc(p,population_size=8,max_iterations=20,max_evaluations=40,seed=123,archive_size=30)
F=np.asarray(r.archive_objectives,float)
assert r.evaluations<=40 and len(F)>=1 and F.shape[1]==4 and np.all(np.isfinite(F)) and np.all(F>=0)
assert np.all(nondominated_mask(F))
p2=MultiObjectiveVCProblem.from_seed(img,123)
r2=optimize_mo_bda_ehho_vc(p2,population_size=8,max_iterations=20,max_evaluations=40,seed=123,archive_size=30)
assert r.archive_bits==r2.archive_bits
assert np.allclose(np.asarray(r.archive_objectives),np.asarray(r2.archive_objectives),rtol=0,atol=1e-12)
print("GROUP 3 SMOKE TEST: PASS")
print("Archive size:",len(r.archive_bits))
print("Compromise levels:",r.compromise_levels_rgb)
print("Compromise objectives:",r.compromise_objectives)
print("BDA proposals:",r.bda_proposals,"EHHO proposals:",r.ehho_proposals)
print("Cache:",p.cache_stats())
