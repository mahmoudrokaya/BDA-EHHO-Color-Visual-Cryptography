#!/usr/bin/env python3
from __future__ import annotations
from dataclasses import dataclass
import numpy as np
from g2_04_behho_vc import sigmoid
from g3_02_pareto_archive import ParetoArchive,dominates

@dataclass
class MOBDAEHHOResult:
    archive_bits:list
    archive_objectives:list
    compromise_bits:list
    compromise_levels_rgb:list
    compromise_objectives:list
    archive_size_history:list
    diversity_history:list
    injection_iterations:list
    evaluations:int
    iterations_completed:int
    bda_proposals:int
    ehho_proposals:int
    seed:int

def binary_diversity(B):
    p=np.mean(B,0); return float(np.mean(4*p*(1-p)))
def v3(d): return np.abs(d/np.sqrt(1+d**2))
def enemy_scores(F):
    lo=F.min(0); hi=F.max(0); return ((F-lo)/np.maximum(hi-lo,1e-12)).sum(1)

def optimize_mo_bda_ehho_vc(problem,population_size=30,max_iterations=100,max_evaluations=600,seed=0,
                            archive_size=100,rho_max=.70,rho_min=.30,diversity_threshold=.70,
                            injection_fraction=.30,min_iteration_before_injection=2):
    rng=np.random.default_rng(seed); n,dim=population_size,24
    B=rng.integers(0,2,size=(n,dim),dtype=np.uint8); D=rng.integers(0,2,size=(n,dim)).astype(float)
    latent=np.where(B==1,1.0,-1.0); Fpop=np.full((n,4),np.nan)
    archive=ParetoArchive(archive_size); evals=0; completed=0; bda_n=0; ehho_n=0
    ah=[]; dh=[]; injections=[]
    def ev(bits):
        nonlocal evals
        f,_=problem.evaluate_bits24(bits); evals+=1; return np.asarray(f,float)
    for t in range(max_iterations):
        for i in range(n):
            if evals>=max_evaluations: break
            if np.any(~np.isfinite(Fpop[i])):
                Fpop[i]=ev(B[i]); archive.add(B[i],Fpop[i])
        if len(archive)==0: break
        completed+=1; div=binary_diversity(B); dh.append(div); ah.append(len(archive))
        if completed>=min_iteration_before_injection and div<diversity_threshold and evals<max_evaluations:
            k=min(max(1,int(np.ceil(n*injection_fraction))),n-1)
            idx=rng.choice(np.arange(n),size=k,replace=False)
            B[idx]=rng.integers(0,2,size=(k,dim),dtype=np.uint8); latent[idx]=np.where(B[idx]==1,1.0,-1.0)
            D[idx]=rng.integers(0,2,size=(k,dim)).astype(float); Fpop[idx]=np.nan; injections.append(completed)
        for i in range(n):
            if evals>=max_evaluations: break
            if np.any(~np.isfinite(Fpop[i])):
                Fpop[i]=ev(B[i]); archive.add(B[i],Fpop[i])
        if evals>=max_evaluations: break
        leader,_=archive.select_leader(rng); enemy=B[int(np.argmax(enemy_scores(Fpop)))].copy()
        w=.9-(t+1)*((.9-.4)/max_iterations); my_c=max(.1-(t+1)*(.1/(max_iterations/2)),0.0)
        s=2*rng.random()*my_c; a=2*rng.random()*my_c; c=2*rng.random()*my_c; ff=2*rng.random(); e=my_c
        if t+1>3*max_iterations/4:e=0.0
        sumB=B.astype(float).sum(0); sumD=D.sum(0)
        for i in range(n):
            if evals>=max_evaluations: break
            q=min(max(evals/max_evaluations,0.0),1.0); rho=rho_min+(rho_max-rho_min)*(1-q)
            cb=B[i].copy(); cf=Fpop[i].copy()
            if rng.random()<rho:
                nn=n-1; xi=cb.astype(float); neighB=sumB-xi; neighD=sumD-D[i]
                S=-(neighB-nn*xi); A=neighD/nn; C=neighB/nn-xi; Food=leader.astype(float)-xi; Enemy=enemy.astype(float)+xi
                D[i]=np.clip(s*S+a*A+c*C+ff*Food+e*Enemy+w*D[i],-6,6)
                prop=cb.copy(); flips=rng.random(dim)<v3(D[i]); prop[flips]=1-prop[flips]; bda_n+=1
            else:
                lx=np.where(leader==1,1.0,-1.0); E1=2*(1-q); Esc=E1*(2*rng.random()-1); xi=latent[i].copy(); J=2*(1-rng.random())
                if abs(Esc)>=1:
                    xr=latent[int(rng.integers(0,n))]; nx=xr-rng.random()*np.abs(xr-2*rng.random()*xi)
                elif rng.random()>=.5: nx=lx-Esc*np.abs(J*lx-xi)
                else: nx=lx-Esc*np.abs(J*lx-np.mean(latent,0))
                latent[i]=np.clip(nx,-6,6); prop=(rng.random(dim)<sigmoid(latent[i])).astype(np.uint8); ehho_n+=1
            pf=ev(prop); archive.add(prop,pf)
            if dominates(pf,cf): accept=True
            elif dominates(cf,pf): accept=False
            else: accept=bool(rng.random()<.5)
            if accept:
                B[i]=prop; Fpop[i]=pf; latent[i]=np.where(prop==1,1.0,-1.0)
    AB,AF=archive.arrays()
    if len(AB)==0: raise RuntimeError("Empty Pareto archive.")
    ci=archive.compromise_index(); cb=AB[ci]; cf=AF[ci]
    return MOBDAEHHOResult(AB.astype(int).tolist(),AF.tolist(),cb.astype(int).tolist(),
        list(problem.decode_bits24(cb)),cf.tolist(),ah,dh,injections,evals,completed,bda_n,ehho_n,int(seed))
