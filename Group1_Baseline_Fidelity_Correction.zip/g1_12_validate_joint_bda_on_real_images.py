#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
g1_12_validate_joint_bda_on_real_images.py

Re-run the six real-image baseline cases using the corrected JOINT-RGB BDA.
The output is intentionally parallel to the earlier validation so the old
sequential baseline and corrected joint baseline can be compared directly.
"""

from __future__ import annotations

import argparse
import json
import time
from pathlib import Path

import numpy as np
import pandas as pd
from PIL import Image

from g1_02_rgb_decomposition import load_rgb
from g1_04_vc_reconstruction import xor_reconstruct
from g1_06_vc_baseline_fitness import mse, psnr, pearson_cc
from g1_10_joint_rgb_bda_reference import optimize_rgb_levels_joint_bda

BASE_DIR = Path(r"D:\48\481\New Papers\BDA_To_HHO_paper")
DATA_DIR = BASE_DIR / "Data"
SELECTED = BASE_DIR / "Outputs" / "Group1_BDA_Validation" / "selected_images.csv"
OLD_SUMMARY = BASE_DIR / "Outputs" / "Group1_BDA_Validation" / "validation_summary.csv"
OUT = BASE_DIR / "Outputs" / "Group1_Joint_BDA_Validation"


def binary_ok(x):
    return bool(np.all(np.isin(np.unique(x), [0, 255])))


def monotonic(x):
    x = np.asarray(x, dtype=float)
    return len(x) <= 1 or bool(np.all(np.diff(x) <= 1e-12))


def rgb_psnr(a, b):
    return float(psnr(a, b))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--population", type=int, default=10)
    ap.add_argument("--iterations", type=int, default=10)
    ap.add_argument("--seed", type=int, default=20260911)
    args = ap.parse_args()

    OUT.mkdir(parents=True, exist_ok=True)
    per = OUT / "per_image"
    per.mkdir(exist_ok=True)

    selected = pd.read_csv(SELECTED)
    rows = []

    for _, row in selected.iterrows():
        image = load_rgb(DATA_DIR / row["relative_to_data"], True)
        image_number = int(str(row["experiment_id"]).split("_")[-1])
        seed = args.seed + image_number
        budget = args.population * args.iterations

        t0 = time.perf_counter()
        res = optimize_rgb_levels_joint_bda(
            image,
            population_size=args.population,
            max_iterations=args.iterations,
            seed=seed,
            max_evaluations_per_channel=budget,
        )
        runtime = time.perf_counter() - t0

        # Exact same-seed reproduction check.
        res2 = optimize_rgb_levels_joint_bda(
            image,
            population_size=args.population,
            max_iterations=args.iterations,
            seed=seed,
            max_evaluations_per_channel=budget,
        )
        same = (
            res["levels_rgb"] == res2["levels_rgb"]
            and np.array_equal(res["share1"], res2["share1"])
            and np.array_equal(res["share2"], res2["share2"])
            and np.array_equal(res["recovered"], res2["recovered"])
        )

        d = per / f"{row['experiment_id']}_{Path(row['filename']).stem}"
        d.mkdir(exist_ok=True)
        Image.fromarray(image).save(d / "original.png")
        Image.fromarray(res["share1"]).save(d / "share1.png")
        Image.fromarray(res["share2"]).save(d / "share2.png")
        Image.fromarray(res["recovered"]).save(d / "reconstructed.png")

        for ch in ("R", "G", "B"):
            pd.DataFrame({
                "iteration": np.arange(
                    1, len(res["channel_results"][ch]["convergence"]) + 1
                ),
                "best_so_far_fitness": res["channel_results"][ch]["convergence"],
            }).to_csv(d / f"convergence_{ch}.csv", index=False)

        serial = {
            k: v for k, v in res.items()
            if k not in {"share1", "share2", "recovered"}
        }
        (d / "joint_bda_result.json").write_text(
            json.dumps(serial, indent=2), encoding="utf-8"
        )

        levels = res["levels_rgb"]
        crit = {
            "same_dimensions": (
                res["share1"].shape == image.shape
                and res["share2"].shape == image.shape
                and res["recovered"].shape == image.shape
            ),
            "share1_binary": binary_ok(res["share1"]),
            "share2_binary": binary_ok(res["share2"]),
            "xor_exact": np.array_equal(
                xor_reconstruct(res["share1"], res["share2"]),
                res["recovered"],
            ),
            "levels_valid": all(2 <= int(v) <= 255 for v in levels),
            "finite_fitness": all(
                np.isfinite(res["channel_results"][c]["best_fitness"])
                for c in ("R", "G", "B")
            ),
            "monotonic_convergence": all(
                monotonic(res["channel_results"][c]["convergence"])
                for c in ("R", "G", "B")
            ),
            "same_seed_exact": same,
        }

        rows.append({
            "experiment_id": row["experiment_id"],
            "dataset": row["dataset"],
            "split": row["split"],
            "filename": row["filename"],
            "seed": seed,
            "population": args.population,
            "iterations": args.iterations,
            "budget_per_channel": budget,
            "best_level_R": levels[0],
            "best_level_G": levels[1],
            "best_level_B": levels[2],
            "best_fitness_R": res["channel_results"]["R"]["best_fitness"],
            "best_fitness_G": res["channel_results"]["G"]["best_fitness"],
            "best_fitness_B": res["channel_results"]["B"]["best_fitness"],
            "runtime_s": runtime,
            "reconstruction_psnr": rgb_psnr(image, res["recovered"]),
            "reconstruction_cc": pearson_cc(image, res["recovered"]),
            **crit,
            "all_critical_pass": all(crit.values()),
        })

        print(
            row["experiment_id"],
            row["filename"],
            "levels=", levels,
            "runtime=", round(runtime, 3),
            "PASS" if all(crit.values()) else "REVIEW",
        )

    new = pd.DataFrame(rows)
    new.to_csv(OUT / "joint_validation_summary.csv", index=False, encoding="utf-8-sig")

    if OLD_SUMMARY.exists():
        old = pd.read_csv(OLD_SUMMARY)
        keep = [
            "experiment_id", "best_level_R", "best_level_G", "best_level_B",
            "runtime_primary_s", "reconstruction_psnr"
        ]
        old = old[[c for c in keep if c in old.columns]].copy()
        old = old.rename(columns={
            "best_level_R": "old_level_R",
            "best_level_G": "old_level_G",
            "best_level_B": "old_level_B",
            "runtime_primary_s": "old_runtime_s",
            "reconstruction_psnr": "old_reconstruction_psnr",
        })
        comp = new.merge(old, on="experiment_id", how="left")
        comp["levels_changed"] = (
            (comp["best_level_R"] != comp["old_level_R"])
            | (comp["best_level_G"] != comp["old_level_G"])
            | (comp["best_level_B"] != comp["old_level_B"])
        )
        if "old_reconstruction_psnr" in comp:
            comp["reconstruction_psnr_change"] = (
                comp["reconstruction_psnr"] - comp["old_reconstruction_psnr"]
            )
        comp.to_csv(
            OUT / "joint_vs_sequential_comparison.csv",
            index=False,
            encoding="utf-8-sig",
        )

    report = [
        "# Corrected Joint-RGB BDA Real-Image Validation",
        "",
        f"- Images: **{len(new)}**",
        f"- Population: **{args.population}**",
        f"- Iterations: **{args.iterations}**",
        f"- Budget/channel: **{args.population*args.iterations}**",
        f"- Critical passes: **{int(new['all_critical_pass'].sum())}/{len(new)}**",
        f"- Same-seed exact reproducibility: **{int(new['same_seed_exact'].sum())}/{len(new)}**",
        f"- Mean runtime/image: **{new['runtime_s'].mean():.3f} s**",
        f"- Mean reconstruction PSNR: **{new['reconstruction_psnr'].mean():.4f} dB**",
        "",
        "The corrected implementation now follows the reference/supplied MATLAB "
        "structure by updating XR, XG and XB in one common BDA iteration loop.",
    ]
    (OUT / "joint_validation_report.md").write_text(
        "\n".join(report), encoding="utf-8"
    )

    try:
        with pd.ExcelWriter(
            OUT / "joint_validation.xlsx", engine="openpyxl"
        ) as writer:
            new.to_excel(writer, sheet_name="Joint Validation", index=False)
            if (OUT / "joint_vs_sequential_comparison.csv").exists():
                pd.read_csv(
                    OUT / "joint_vs_sequential_comparison.csv"
                ).to_excel(writer, sheet_name="Joint vs Sequential", index=False)
    except Exception as exc:
        print("Excel export skipped:", exc)

    print("Done:", OUT)


if __name__ == "__main__":
    main()
