#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
g1_11_fitness_sensitivity_audit.py

Sensitivity audit for the ambiguous BDA-VC fitness definition.

The reference paper says to minimize PSNR + CC between original and share
images, but does not uniquely define:
  1) signed CC versus |CC|;
  2) how Share 1 and Share 2 are aggregated.

This audit DOES NOT choose a definition by assumption. It evaluates several
defensible alternatives on the six real-image validation cases:

Correlation:
  - signed_cc
  - abs_cc

Share aggregation:
  - share1
  - share2
  - mean
  - max   (conservative: penalize the more revealing share)

For each image/channel, all level counts NX=2..255 are scanned exhaustively
using one fixed random field. The audit reports whether alternative objective
definitions produce materially different optima.

Outputs:
D:\48\481\New Papers\BDA_To_HHO_paper\Outputs\Fitness_Sensitivity_Audit\
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd

from g1_02_rgb_decomposition import load_rgb
from g1_03_vc_share_generation import generate_channel_shares
from g1_06_vc_baseline_fitness import psnr, pearson_cc

BASE_DIR = Path(r"D:\48\481\New Papers\BDA_To_HHO_paper")
DATA_DIR = BASE_DIR / "Data"
SELECTED = BASE_DIR / "Outputs" / "Group1_BDA_Validation" / "selected_images.csv"
OUTPUT_DIR = BASE_DIR / "Outputs" / "Fitness_Sensitivity_Audit"

CORR_MODES = ("signed_cc", "abs_cc")
AGG_MODES = ("share1", "share2", "mean", "max")


def objective_values(secret, s1, s2):
    p1, p2 = psnr(secret, s1), psnr(secret, s2)
    c1, c2 = pearson_cc(secret, s1), pearson_cc(secret, s2)
    rows = {}
    for corr_mode in CORR_MODES:
        q1 = c1 if corr_mode == "signed_cc" else abs(c1)
        q2 = c2 if corr_mode == "signed_cc" else abs(c2)
        z1, z2 = p1 + q1, p2 + q2
        rows[(corr_mode, "share1")] = z1
        rows[(corr_mode, "share2")] = z2
        rows[(corr_mode, "mean")] = 0.5 * (z1 + z2)
        rows[(corr_mode, "max")] = max(z1, z2)
    return rows, (p1, p2, c1, c2)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--seed", type=int, default=20260911)
    ap.add_argument("--step", type=int, default=1,
                    help="Level-count scan step; default 1 gives exhaustive 2..255.")
    args = ap.parse_args()

    if not SELECTED.exists():
        raise FileNotFoundError(
            f"{SELECTED}\nRun g1_08_validate_bda_on_real_images.py first."
        )

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    selected = pd.read_csv(SELECTED)

    detail_rows = []
    optimum_rows = []

    for _, row in selected.iterrows():
        image = load_rgb(DATA_DIR / row["relative_to_data"], True)
        exp_id = row["experiment_id"]

        # Stable fixed random fields per image/channel.
        image_number = int(str(exp_id).split("_")[-1])
        ss = np.random.SeedSequence(args.seed + image_number)
        children = ss.spawn(3)

        for ch_idx, ch_name in enumerate(("R", "G", "B")):
            rng = np.random.default_rng(children[ch_idx])
            random_field = rng.random(image.shape[:2])
            secret = image[..., ch_idx]

            all_obj = {
                (cm, am): [] for cm in CORR_MODES for am in AGG_MODES
            }

            for nx in range(2, 256, args.step):
                s1, s2, _ = generate_channel_shares(
                    secret, nx, random_field=random_field
                )
                vals, raw = objective_values(secret, s1, s2)
                p1, p2, c1, c2 = raw

                detail_rows.append({
                    "experiment_id": exp_id,
                    "dataset": row["dataset"],
                    "split": row["split"],
                    "filename": row["filename"],
                    "channel": ch_name,
                    "NX": nx,
                    "share1_psnr": p1,
                    "share2_psnr": p2,
                    "share1_cc": c1,
                    "share2_cc": c2,
                })

                for key, val in vals.items():
                    all_obj[key].append((nx, float(val)))

            for (corr_mode, agg_mode), seq in all_obj.items():
                best_nx, best_value = min(seq, key=lambda x: x[1])
                optimum_rows.append({
                    "experiment_id": exp_id,
                    "dataset": row["dataset"],
                    "split": row["split"],
                    "filename": row["filename"],
                    "channel": ch_name,
                    "correlation_mode": corr_mode,
                    "share_aggregation": agg_mode,
                    "best_NX": best_nx,
                    "best_objective": best_value,
                })

        print(f"Completed {exp_id} | {row['filename']}")

    detail = pd.DataFrame(detail_rows)
    optimum = pd.DataFrame(optimum_rows)

    detail.to_csv(
        OUTPUT_DIR / "fitness_scan_raw_metrics.csv",
        index=False,
        encoding="utf-8-sig",
    )
    optimum.to_csv(
        OUTPUT_DIR / "fitness_definition_optima.csv",
        index=False,
        encoding="utf-8-sig",
    )

    # Compare every definition with our current default: abs_cc + mean.
    default = optimum[
        (optimum["correlation_mode"] == "abs_cc")
        & (optimum["share_aggregation"] == "mean")
    ][["experiment_id", "channel", "best_NX"]].rename(
        columns={"best_NX": "default_best_NX"}
    )

    compare = optimum.merge(default, on=["experiment_id", "channel"])
    compare["same_optimum_as_default"] = (
        compare["best_NX"] == compare["default_best_NX"]
    )
    compare["abs_NX_difference"] = (
        compare["best_NX"] - compare["default_best_NX"]
    ).abs()

    compare.to_csv(
        OUTPUT_DIR / "fitness_definition_comparison.csv",
        index=False,
        encoding="utf-8-sig",
    )

    summary = (
        compare.groupby(["correlation_mode", "share_aggregation"])
        .agg(
            cases=("same_optimum_as_default", "size"),
            same_optimum_rate=("same_optimum_as_default", "mean"),
            median_abs_NX_difference=("abs_NX_difference", "median"),
            max_abs_NX_difference=("abs_NX_difference", "max"),
        )
        .reset_index()
    )
    summary["same_optimum_rate"] *= 100.0
    summary.to_csv(
        OUTPUT_DIR / "fitness_sensitivity_summary.csv",
        index=False,
        encoding="utf-8-sig",
    )

    report = [
        "# Fitness-Definition Sensitivity Audit",
        "",
        "The BDA-VC source paper leaves two fitness details ambiguous: whether "
        "correlation is signed or absolute, and how the two shares are aggregated. "
        "This audit exhaustively scans color-level counts and quantifies whether "
        "those choices change the selected optimum.",
        "",
        "## Definitions compared",
        "",
        "- Correlation: signed Pearson CC vs |CC|.",
        "- Share aggregation: Share 1 only, Share 2 only, mean of both, or conservative maximum.",
        "- Current default: **mean[PSNR + |CC|] across the two shares**.",
        "",
        "## Summary",
        "",
        summary.to_markdown(index=False),
        "",
        "## Decision rule",
        "",
        "If signed-vs-absolute CC or share aggregation materially changes the optimum, "
        "the paper should explicitly disclose the adopted interpretation and include "
        "the sensitivity result as a reproducibility note. If differences are small, "
        "the current default can be retained as a stable operationalization of the "
        "paper's stated goal of low secret-share similarity.",
    ]
    (OUTPUT_DIR / "fitness_sensitivity_report.md").write_text(
        "\n".join(report), encoding="utf-8"
    )

    try:
        with pd.ExcelWriter(
            OUTPUT_DIR / "fitness_sensitivity_audit.xlsx",
            engine="openpyxl",
        ) as writer:
            optimum.to_excel(writer, sheet_name="Optima", index=False)
            compare.to_excel(writer, sheet_name="Comparison", index=False)
            summary.to_excel(writer, sheet_name="Summary", index=False)
    except Exception as exc:
        print("Excel export skipped:", exc)

    print("Audit complete:", OUTPUT_DIR)


if __name__ == "__main__":
    main()
