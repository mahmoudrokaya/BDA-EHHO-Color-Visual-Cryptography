#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
g1_10_joint_rgb_bda_reference.py

Corrected joint-RGB Binary Dragonfly Algorithm (BDA) baseline.

Why this file exists
--------------------
The baseline-fidelity audit showed that the previous Python baseline optimized
R, G and B in separate BDA runs, whereas the supplied/reference MATLAB BDA
maintains XR, XG and XB inside ONE optimization loop. This implementation
corrects that deviation.

The implementation mirrors the supplied MATLAB structure:
- XR, XG, XB binary populations are initialized together.
- DeltaXR, DeltaXG, DeltaXB are maintained together.
- R/G/B fitness values are evaluated in the same iteration.
- The same iteration-level s, a, c, f, e, w coefficients are used across RGB.
- Food/enemy solutions are tracked separately for R/G/B.
- V3 transfer function is used independently for each channel.
- RGB shares are finally generated from the three optimized color-level counts.

This remains a single-objective reference baseline. The paper ambiguities
identified by the fidelity audit are handled exactly as in Group 1:
  * decoded group count NX is clamped to [2,255];
  * objective defaults to mean[PSNR + |CC|] across Share 1 and Share 2;
  * fixed per-channel random fields are reused during one run.
"""

from __future__ import annotations

from dataclasses import dataclass, asdict
from pathlib import Path
import json
import numpy as np

from g1_02_rgb_decomposition import load_rgb
from g1_03_vc_share_generation import generate_rgb_shares
from g1_04_vc_reconstruction import xor_reconstruct, verify_non_expansion
from g1_05_vc_solution_encoding import decode_channel_bits
from g1_06_vc_baseline_fitness import make_bda_cost


@dataclass
class JointBDAChannelResult:
    best_bits: list[int]
    best_level_count: int
    best_fitness: float
    convergence: list[float]
    evaluations: int


def _v3(delta: np.ndarray) -> np.ndarray:
    return np.abs(delta / np.sqrt(1.0 + delta**2))


def optimize_rgb_levels_joint_bda(
    image: np.ndarray,
    population_size: int = 60,
    max_iterations: int = 1000,
    seed: int = 20260911,
    max_evaluations_per_channel: int | None = None,
) -> dict:
    if image.ndim != 3 or image.shape[2] != 3:
        raise ValueError("Expected HxWx3 RGB image.")
    if population_size < 2:
        raise ValueError("population_size must be >= 2.")

    rng = np.random.default_rng(seed)
    dim = 8

    # Fixed random fields make candidate evaluation deterministic within a run.
    random_fields = tuple(rng.random(image.shape[:2]) for _ in range(3))
    costs = tuple(
        make_bda_cost(image[..., ch], random_fields[ch]) for ch in range(3)
    )

    # Joint initialization: population x dim for each RGB channel.
    X = [
        rng.integers(0, 2, size=(population_size, dim), dtype=np.uint8)
        for _ in range(3)
    ]
    Delta = [
        rng.integers(0, 2, size=(population_size, dim)).astype(float)
        for _ in range(3)
    ]

    food_fit = [float("inf")] * 3
    food_pos = [np.zeros(dim, dtype=np.uint8) for _ in range(3)]
    enemy_fit = [-float("inf")] * 3
    enemy_pos = [np.zeros(dim, dtype=np.uint8) for _ in range(3)]

    convergence = [[], [], []]
    evaluations = [0, 0, 0]
    iterations_completed = 0

    for iteration in range(1, max_iterations + 1):
        exhausted = False

        # Evaluate R, G, B populations within the same iteration.
        for i in range(population_size):
            for ch in range(3):
                if (
                    max_evaluations_per_channel is not None
                    and evaluations[ch] >= max_evaluations_per_channel
                ):
                    exhausted = True
                    continue

                fv = float(costs[ch](X[ch][i].copy()))
                evaluations[ch] += 1

                if fv < food_fit[ch]:
                    food_fit[ch] = fv
                    food_pos[ch] = X[ch][i].copy()

                if fv > enemy_fit[ch]:
                    enemy_fit[ch] = fv
                    enemy_pos[ch] = X[ch][i].copy()

        if any(np.isinf(v) for v in food_fit):
            break

        iterations_completed += 1
        for ch in range(3):
            convergence[ch].append(float(food_fit[ch]))

        if (
            max_evaluations_per_channel is not None
            and all(e >= max_evaluations_per_channel for e in evaluations)
        ):
            break

        # Same iteration-level coefficients for all RGB channels, as in MATLAB.
        w = 0.9 - iteration * ((0.9 - 0.4) / max_iterations)
        my_c = 0.1 - iteration * (0.1 / (max_iterations / 2.0))
        my_c = max(my_c, 0.0)

        s = 2.0 * rng.random() * my_c
        a = 2.0 * rng.random() * my_c
        c = 2.0 * rng.random() * my_c
        f = 2.0 * rng.random()
        e = my_c
        if iteration > (3.0 * max_iterations / 4.0):
            e = 0.0

        n_neigh = population_size - 1

        for ch in range(3):
            sum_x = X[ch].astype(float).sum(axis=0)
            sum_d = Delta[ch].sum(axis=0)

            for i in range(population_size):
                xi = X[ch][i].astype(float)
                neigh_sum_x = sum_x - xi
                neigh_sum_d = sum_d - Delta[ch][i]

                # Supplied MATLAB equations.
                S = -(neigh_sum_x - n_neigh * xi)
                A = neigh_sum_d / n_neigh
                C = (neigh_sum_x / n_neigh) - xi
                F = food_pos[ch].astype(float) - xi
                E = enemy_pos[ch].astype(float) + xi

                Delta[ch][i] = (
                    s * S
                    + a * A
                    + c * C
                    + f * F
                    + e * E
                    + w * Delta[ch][i]
                )
                Delta[ch][i] = np.clip(Delta[ch][i], -6.0, 6.0)

                T = _v3(Delta[ch][i])
                flips = rng.random(dim) < T
                X[ch][i, flips] = 1 - X[ch][i, flips]

    names = ("R", "G", "B")
    channel_results = {}
    levels = []

    for ch, name in enumerate(names):
        level = decode_channel_bits(food_pos[ch])
        levels.append(level)
        channel_results[name] = asdict(
            JointBDAChannelResult(
                best_bits=food_pos[ch].astype(int).tolist(),
                best_level_count=int(level),
                best_fitness=float(food_fit[ch]),
                convergence=[float(x) for x in convergence[ch]],
                evaluations=int(evaluations[ch]),
            )
        )

    levels_rgb = tuple(levels)
    share1, share2, share_meta = generate_rgb_shares(
        image,
        levels_rgb,
        random_fields=random_fields,
    )
    recovered = xor_reconstruct(share1, share2)

    return {
        "levels_rgb": levels_rgb,
        "channel_results": channel_results,
        "share_metadata": share_meta,
        "share1": share1,
        "share2": share2,
        "recovered": recovered,
        "non_expansible": verify_non_expansion(image, share1, share2),
        "seed": int(seed),
        "population_size": int(population_size),
        "max_iterations": int(max_iterations),
        "iterations_completed": int(iterations_completed),
        "joint_rgb_loop": True,
    }


def run_image(
    image_path: str | Path,
    output_dir: str | Path,
    population_size: int = 60,
    max_iterations: int = 1000,
    seed: int = 20260911,
    max_evaluations_per_channel: int | None = None,
) -> dict:
    from PIL import Image

    image_path = Path(image_path)
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    image = load_rgb(image_path, require_native_rgb=True)
    result = optimize_rgb_levels_joint_bda(
        image=image,
        population_size=population_size,
        max_iterations=max_iterations,
        seed=seed,
        max_evaluations_per_channel=max_evaluations_per_channel,
    )

    stem = image_path.stem
    Image.fromarray(result["share1"]).save(output_dir / f"{stem}_share1.png")
    Image.fromarray(result["share2"]).save(output_dir / f"{stem}_share2.png")
    Image.fromarray(result["recovered"]).save(output_dir / f"{stem}_recovered.png")

    serializable = {
        k: v for k, v in result.items()
        if k not in {"share1", "share2", "recovered"}
    }
    (output_dir / f"{stem}_joint_bda_result.json").write_text(
        json.dumps(serializable, indent=2),
        encoding="utf-8",
    )
    return result
