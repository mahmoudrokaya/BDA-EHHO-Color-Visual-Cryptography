# Group 1 — Baseline Fidelity Correction

The fidelity audit produced a **conditional pass** and identified one material deviation:
the Python BDA baseline optimized R/G/B sequentially, whereas the reference/supplied MATLAB
BDA updates XR/XG/XB inside one joint loop.

Copy these three files into:

`D:\48\481\New Papers\BDA_To_HHO_paper\Codes\Group1_Common_VC_Core`

Run in this order:

```powershell
python g1_12_validate_joint_bda_on_real_images.py
python g1_11_fitness_sensitivity_audit.py
```

`g1_10_joint_rgb_bda_reference.py` is imported by the validation script.

Expected outputs:

1. `Outputs\Group1_Joint_BDA_Validation`
   - corrected joint-BDA results
   - comparison against previous sequential baseline
   - same-seed reproducibility
   - convergence checks

2. `Outputs\Fitness_Sensitivity_Audit`
   - signed CC vs |CC|
   - Share 1 vs Share 2 vs mean vs max aggregation
   - exhaustive NX=2..255 optimum comparison

Do not begin HHO/EHHO until both audits are reviewed.
