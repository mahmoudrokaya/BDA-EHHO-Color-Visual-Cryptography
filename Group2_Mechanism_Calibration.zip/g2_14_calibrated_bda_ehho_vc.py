#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Calibrated BDA-EHHO-VC hybrid.

Key correction:
The mixing probability is tied to consumed objective-evaluation budget:

    q = evaluations / B
    rho_BDA(q) = rho_min + (rho_max-rho_min)*(1-q)

Thus early search favors BDA and later search increasingly favors EHHO,
regardless of how many nominal iterations are actually reached.

This fixes the pilot problem where the run ended before the original
iteration-based schedule had time to transition.
"""

from __future__ import annotations
from dataclasses import dataclass
import numpy as np

from g2_01_common_vc_adapter import FrozenVCObjective
from g2_04_behho_vc import sigmoid


@dataclass
class CalibratedHybridResult:
    best_bits: list[int]
    best_levels_rgb: list[int]
    best_score: float
    convergence: list[float]
    evaluations: int
    iterations_completed: int
    bda_proposals: int
    ehho_proposals: int
    seed: int
    rho_max: float
    rho_min: float


def v3(delta):
    return np.abs(delta / np.sqrt(1.0 + delta**2))


def optimize_calibrated_bda_ehho_vc(
    objective: FrozenVCObjective,
    population_size=20,
    max_iterations=100,
    max_evaluations=400,
    seed=0,
    rho_max=0.80,
    rho_min=0.20,
):
    if not (0.0 <= rho_min <= rho_max <= 1.0):
        raise ValueError("Require 0 <= rho_min <= rho_max <= 1.")

    rng = np.random.default_rng(seed)
    n, dim = population_size, 24

    B = rng.integers(0, 2, size=(n, dim), dtype=np.uint8)
    D = rng.integers(0, 2, size=(n, dim)).astype(float)
    latent = np.where(B == 1, 1.0, -1.0)

    fit = np.full(n, np.inf)
    best_b = B[0].copy()
    best = float("inf")
    worst_b = B[0].copy()
    worst = -float("inf")

    convergence = []
    evaluations = 0
    completed = 0
    bda_n = 0
    ehho_n = 0

    def ev(bits):
        nonlocal evaluations
        s, _ = objective.evaluate_bits24(bits)
        evaluations += 1
        return float(np.mean(s))

    for t in range(max_iterations):
        # Current population evaluation.
        for i in range(n):
            if evaluations >= max_evaluations:
                break
            fit[i] = ev(B[i])
            if fit[i] < best:
                best = fit[i]
                best_b = B[i].copy()
            if fit[i] > worst:
                worst = fit[i]
                worst_b = B[i].copy()

        completed += 1
        convergence.append(float(best))

        if evaluations >= max_evaluations:
            break

        # Standard BDA coefficients remain iteration-dependent.
        w = 0.9 - (t + 1) * ((0.9 - 0.4) / max_iterations)
        my_c = max(
            0.1 - (t + 1) * (0.1 / (max_iterations / 2.0)),
            0.0
        )
        s = 2*rng.random()*my_c
        a = 2*rng.random()*my_c
        c = 2*rng.random()*my_c
        f = 2*rng.random()
        e = my_c
        if t + 1 > (3*max_iterations/4):
            e = 0.0

        sumB = B.astype(float).sum(axis=0)
        sumD = D.sum(axis=0)

        for i in range(n):
            if evaluations >= max_evaluations:
                break

            current = B[i].copy()
            current_fit = fit[i]
            if not np.isfinite(current_fit):
                current_fit = ev(current)
                if evaluations >= max_evaluations:
                    break

            q = min(max(evaluations / max_evaluations, 0.0), 1.0)
            rho = rho_min + (rho_max-rho_min)*(1.0-q)

            if rng.random() < rho:
                # BDA proposal.
                nn = n - 1
                xi = current.astype(float)
                neighB = sumB - xi
                neighD = sumD - D[i]

                S = -(neighB - nn*xi)
                A = neighD / nn
                C = (neighB / nn) - xi
                F = best_b.astype(float) - xi
                E = worst_b.astype(float) + xi

                D[i] = np.clip(
                    s*S + a*A + c*C + f*F + e*E + w*D[i],
                    -6.0, 6.0
                )
                prop = current.copy()
                flips = rng.random(dim) < v3(D[i])
                prop[flips] = 1 - prop[flips]
                bda_n += 1
            else:
                # EHHO-guided binary proposal.
                E1 = 2.0 * (1.0 - min(q, 1.0))
                Esc = E1 * (2*rng.random() - 1)
                rb = np.where(best_b == 1, 1.0, -1.0)
                xi = latent[i].copy()
                J = 2.0 * (1.0 - rng.random())

                if abs(Esc) >= 1:
                    xr = latent[int(rng.integers(0, n))]
                    newx = xr - rng.random()*np.abs(
                        xr - 2*rng.random()*xi
                    )
                elif rng.random() >= 0.5:
                    newx = rb - Esc*np.abs(J*rb - xi)
                else:
                    newx = rb - Esc*np.abs(
                        J*rb - np.mean(latent, axis=0)
                    )

                latent[i] = np.clip(newx, -6.0, 6.0)
                prop = (
                    rng.random(dim) < sigmoid(latent[i])
                ).astype(np.uint8)
                ehho_n += 1

            if evaluations >= max_evaluations:
                break

            pf = ev(prop)
            if pf <= current_fit:
                B[i] = prop
                fit[i] = pf
                latent[i] = np.where(prop == 1, 1.0, -1.0)
                if pf < best:
                    best = pf
                    best_b = prop.copy()
            else:
                fit[i] = current_fit

        if evaluations >= max_evaluations:
            break

    _, detail = objective.evaluate_bits24(best_b)

    return CalibratedHybridResult(
        best_bits=best_b.astype(int).tolist(),
        best_levels_rgb=list(detail["levels_rgb"]),
        best_score=float(best),
        convergence=convergence,
        evaluations=int(evaluations),
        iterations_completed=int(completed),
        bda_proposals=int(bda_n),
        ehho_proposals=int(ehho_n),
        seed=int(seed),
        rho_max=float(rho_max),
        rho_min=float(rho_min),
    )
