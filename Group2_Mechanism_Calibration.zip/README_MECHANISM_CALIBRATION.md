# Group 2 Mechanism-Calibration Stage

This stage addresses two issues detected by the pilot:

1. BEHHO diversity injection was almost dormant.
2. The BDA-EHHO hybrid was >90% BDA-driven because its mixing schedule followed nominal iteration number rather than consumed evaluation budget.

It also audits runtime outliers.

## Files

- `g2_12_calibration_config.py`
- `g2_13_calibrated_behho_vc.py`
- `g2_14_calibrated_bda_ehho_vc.py`
- `g2_15_runtime_outlier_audit.py`
- `g2_16_run_mechanism_calibration.py`
- `g2_17_analyze_mechanism_calibration.py`

## Run order

Copy all files into:

`D:\48\481\New Papers\BDA_To_HHO_paper\Codes\Group2_HHO_Progression`

Then:

```powershell
python g2_15_runtime_outlier_audit.py --profile pilot
python g2_16_run_mechanism_calibration.py
python g2_17_analyze_mechanism_calibration.py
```

## Design

Calibration uses the same 12 BSDS500 validation images as the pilot:
- population = 20
- budget = 400
- 2 runs/image

### BEHHO
Thresholds: 0.70, 0.75, 0.80
Injection fractions: 0.20, 0.30

Desired diagnostic behavior:
- injections occur in some, but not all, runs.

### Hybrid
Budget-based BDA schedule candidates:
- 0.80 -> 0.20
- 0.70 -> 0.30
- 0.65 -> 0.35

Desired diagnostic behavior:
- meaningful participation of both BDA and EHHO.

## Scientific safeguard

Settings are selected mechanism-first, not score-first. This stage is intended
to ensure that the named mechanisms are genuinely active before larger experiments.
