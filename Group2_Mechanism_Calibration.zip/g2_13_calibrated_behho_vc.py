#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Calibrated BEHHO-VC.

Same binary HHO representation as g2_04_behho_vc.py, but the diversity
threshold and injection fraction are explicit calibration parameters.

Binary diversity:
    D = mean_d [4 p_d (1-p_d)]
where p_d is the fraction of population bits equal to 1 at dimension d.
D lies in [0,1], with high values indicating a balanced binary population.
"""

from __future__ import annotations
from dataclasses import dataclass
import numpy as np

from g2_01_common_vc_adapter import FrozenVCObjective
from g2_02_hho_vc import levy_flight
from g2_04_behho_vc import sigmoid, binary_diversity


@dataclass
class CalibratedBEHHOResult:
    best_bits: list[int]
    best_levels_rgb: list[int]
    best_score: float
    best_channel_scores: list[float]
    convergence: list[float]
    diversity_history: list[float]
    injection_iterations: list[int]
    evaluations: int
    iterations_completed: int
    seed: int
    diversity_threshold: float
    injection_fraction: float


def optimize_calibrated_behho_vc(
    objective: FrozenVCObjective,
    population_size=20,
    max_iterations=30,
    max_evaluations=400,
    seed=0,
    diversity_threshold=0.75,
    injection_fraction=0.30,
    min_iteration_before_injection=2,
):
    rng = np.random.default_rng(seed)
    n, dim = population_size, 24

    X = rng.normal(0, 1, size=(n, dim))
    B = (rng.random((n, dim)) < sigmoid(X)).astype(np.uint8)

    rabbit_x = np.zeros(dim)
    rabbit_b = np.zeros(dim, dtype=np.uint8)
    rabbit_score = float("inf")
    rabbit_channels = np.full(3, np.inf)

    convergence = []
    div_hist = []
    injections = []
    evaluations = 0
    completed = 0

    def eval_bits(bits):
        nonlocal evaluations
        sc, _ = objective.evaluate_bits24(bits)
        evaluations += 1
        return float(np.mean(sc)), sc

    for t in range(max_iterations):
        # Evaluate current population.
        for i in range(n):
            if evaluations >= max_evaluations:
                break
            f, cs = eval_bits(B[i])
            if f < rabbit_score:
                rabbit_score = f
                rabbit_b = B[i].copy()
                rabbit_x = X[i].copy()
                rabbit_channels = cs.copy()

        completed += 1
        convergence.append(float(rabbit_score))

        div = binary_diversity(B)
        div_hist.append(div)

        if (
            t + 1 >= min_iteration_before_injection
            and div < diversity_threshold
            and evaluations < max_evaluations
        ):
            k = max(1, int(np.ceil(n * injection_fraction)))
            # Keep at least one elite-sized slot untouched.
            k = min(k, n - 1)
            idx = rng.choice(np.arange(n), size=k, replace=False)
            X[idx] = rng.normal(0, 1, size=(k, dim))
            B[idx] = (
                rng.random((k, dim)) < sigmoid(X[idx])
            ).astype(np.uint8)
            injections.append(t + 1)

        if evaluations >= max_evaluations:
            break

        E1 = 2.0 * (1.0 - (t + 1) / max_iterations)

        for i in range(n):
            E0 = 2.0 * rng.random() - 1.0
            E = E1 * E0

            if abs(E) >= 1.0:
                xr = X[int(rng.integers(0, n))].copy()
                q = rng.random()
                r1, r2 = rng.random(), rng.random()
                if q < 0.5:
                    newx = xr - r1 * np.abs(xr - 2*r2*X[i])
                else:
                    newx = (
                        rabbit_x
                        - np.mean(X, axis=0)
                        - r1 * (-6.0 + r2 * 12.0)
                    )
            else:
                r = rng.random()
                J = 2.0 * (1.0 - rng.random())
                delta = rabbit_x - X[i]

                if r >= 0.5 and abs(E) >= 0.5:
                    newx = delta - E*np.abs(J*rabbit_x - X[i])
                elif r >= 0.5 and abs(E) < 0.5:
                    newx = rabbit_x - E*np.abs(delta)
                else:
                    base = (
                        rabbit_x - E*np.abs(J*rabbit_x - X[i])
                        if abs(E) >= 0.5
                        else rabbit_x - E*np.abs(
                            J*rabbit_x - np.mean(X, axis=0)
                        )
                    )
                    newx = (
                        base
                        + rng.normal(size=dim) * levy_flight(dim, rng)
                    )

            X[i] = np.clip(newx, -6.0, 6.0)
            B[i] = (
                rng.random(dim) < sigmoid(X[i])
            ).astype(np.uint8)

        if evaluations >= max_evaluations:
            break

    _, detail = objective.evaluate_bits24(rabbit_b)

    return CalibratedBEHHOResult(
        best_bits=rabbit_b.astype(int).tolist(),
        best_levels_rgb=list(detail["levels_rgb"]),
        best_score=float(rabbit_score),
        best_channel_scores=rabbit_channels.tolist(),
        convergence=convergence,
        diversity_history=div_hist,
        injection_iterations=injections,
        evaluations=evaluations,
        iterations_completed=completed,
        seed=int(seed),
        diversity_threshold=float(diversity_threshold),
        injection_fraction=float(injection_fraction),
    )
