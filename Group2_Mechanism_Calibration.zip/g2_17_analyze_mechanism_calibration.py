#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Analyze mechanism calibration and recommend one BEHHO calibration and one
hybrid schedule based primarily on mechanism operation, secondarily on score.

This stage does NOT choose settings solely because they produce the best score.
"""

from __future__ import annotations
from pathlib import Path
import numpy as np
import pandas as pd

from g2_12_calibration_config import (
    TARGET_INJECTION_RATE_RANGE,
    TARGET_HYBRID_BDA_FRACTION_RANGE,
)

BASE=Path(r"D:\48\481\New Papers\BDA_To_HHO_paper")
OUT=BASE/"Outputs"/"Group2_Mechanism_Calibration"


def dist_to_interval(x, lo, hi):
    if lo <= x <= hi:
        return 0.0
    return min(abs(x-lo),abs(x-hi))


def main():
    df=pd.read_csv(OUT/"mechanism_calibration_raw.csv")

    b=df[df["mechanism"]=="BEHHO"].copy()
    bs=(
        b.groupby("variant")
        .agg(
            runs=("best_score","size"),
            mean_score=("best_score","mean"),
            median_score=("best_score","median"),
            mean_runtime_s=("runtime_s","mean"),
            mean_injections=("injection_count","mean"),
            pct_runs_with_injection=("injection_count",lambda s:100*np.mean(s>0)),
            mean_diversity=("mean_diversity","mean"),
            mean_final_diversity=("final_diversity","mean"),
        ).reset_index()
    )
    lo,hi=TARGET_INJECTION_RATE_RANGE
    bs["mechanism_penalty"]=bs["pct_runs_with_injection"].map(
        lambda x:dist_to_interval(x,lo,hi)
    )
    # mechanism first, score second
    bs=bs.sort_values(["mechanism_penalty","mean_score","mean_runtime_s"])
    bs.to_csv(OUT/"behho_calibration_summary.csv",index=False,encoding="utf-8-sig")

    h=df[df["mechanism"]=="HYBRID"].copy()
    hs=(
        h.groupby("variant")
        .agg(
            runs=("best_score","size"),
            mean_score=("best_score","mean"),
            median_score=("best_score","median"),
            mean_runtime_s=("runtime_s","mean"),
            mean_bda_fraction=("bda_fraction","mean"),
            mean_bda_proposals=("bda_proposals","mean"),
            mean_ehho_proposals=("ehho_proposals","mean"),
        ).reset_index()
    )
    lo2,hi2=TARGET_HYBRID_BDA_FRACTION_RANGE
    hs["mechanism_penalty"]=hs["mean_bda_fraction"].map(
        lambda x:dist_to_interval(x,lo2,hi2)
    )
    hs=hs.sort_values(["mechanism_penalty","mean_score","mean_runtime_s"])
    hs.to_csv(OUT/"hybrid_schedule_summary.csv",index=False,encoding="utf-8-sig")

    bbest=bs.iloc[0]
    hbest=hs.iloc[0]

    report=[
        "# Group 2 Mechanism Calibration",
        "",
        "## BEHHO diversity calibration",
        "",
        bs.to_markdown(index=False),
        "",
        f"Mechanism-first recommendation: **{bbest['variant']}**.",
        f"Its run-level injection rate is **{bbest['pct_runs_with_injection']:.2f}%**.",
        "",
        "## Hybrid schedule calibration",
        "",
        hs.to_markdown(index=False),
        "",
        f"Mechanism-first recommendation: **{hbest['variant']}**.",
        f"Its mean BDA proposal fraction is **{hbest['mean_bda_fraction']:.3f}** "
        f"(EHHO fraction ≈ {1-hbest['mean_bda_fraction']:.3f}).",
        "",
        "## Selection principle",
        "",
        "The recommended settings are selected first for evidence that the intended "
        "mechanism is actually operating, and only then by objective score/runtime. "
        "This prevents tuning the mechanisms merely to manufacture a favorable result.",
        "",
        "After accepting these settings, rerun the original 12-image pilot with the "
        "calibrated BEHHO and calibrated hybrid before proceeding to the larger screen profile.",
    ]
    (OUT/"mechanism_calibration_report.md").write_text(
        "\n".join(report),encoding="utf-8"
    )

    try:
        with pd.ExcelWriter(OUT/"mechanism_calibration.xlsx",engine="openpyxl") as w:
            bs.to_excel(w,sheet_name="BEHHO",index=False)
            hs.to_excel(w,sheet_name="Hybrid",index=False)
            df.to_excel(w,sheet_name="Raw",index=False)
    except Exception as exc:
        print("Excel export skipped:",exc)

    print("Report:",OUT/"mechanism_calibration_report.md")

if __name__=="__main__":
    main()
