#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Short mechanism-calibration design for Group 2.

Purpose:
1) recalibrate BEHHO binary diversity control so the enhancement mechanism is
   neither dormant nor constantly active;
2) correct the BDA-EHHO mixing schedule so it follows consumed evaluation
   budget rather than nominal iteration index;
3) audit runtime outliers from the pilot;
4) rerun the SAME 12-image pilot for a clean before/after comparison.

This stage is diagnostic/calibration, not performance fishing.
"""

BEHHO_THRESHOLDS = [0.70, 0.75, 0.80]
BEHHO_INJECTION_FRACTIONS = [0.20, 0.30]

HYBRID_SCHEDULES = [
    # label, rho_max, rho_min
    ("balanced_80_20", 0.80, 0.20),
    ("balanced_70_30", 0.70, 0.30),
    ("balanced_65_35", 0.65, 0.35),
]

CALIBRATION_IMAGES = 12
CALIBRATION_RUNS = 2
POPULATION = 20
BUDGET = 400
SELECTION_SEED = 481
BASE_SEED = 20260912

# Mechanism targets are diagnostic, not optimization targets.
# We want an enhancement that activates sometimes, not never and not always.
TARGET_INJECTION_RATE_RANGE = (10.0, 60.0)  # percent of runs
TARGET_HYBRID_BDA_FRACTION_RANGE = (0.35, 0.65)
