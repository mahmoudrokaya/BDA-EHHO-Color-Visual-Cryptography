#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Audit runtime outliers in the existing Group-2 pilot.

Uses robust statistics:
- median,
- MAD,
- robust z-score,
- IQR fences.

This does not delete or modify any run. It only flags unusual timings.
"""

from __future__ import annotations
import argparse
from pathlib import Path
import numpy as np
import pandas as pd

BASE = Path(r"D:\48\481\New Papers\BDA_To_HHO_paper")
ROOT = BASE/"Outputs"/"Group2_Validation_Tuning"


def robust_z(x):
    x = np.asarray(x, float)
    med = np.median(x)
    mad = np.median(np.abs(x-med))
    if mad == 0:
        return np.zeros_like(x)
    return 0.6745*(x-med)/mad


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--profile",default="pilot")
    args=ap.parse_args()

    folder=ROOT/args.profile
    path=folder/"tuning_raw_results.csv"
    df=pd.read_csv(path)
    flagged=[]

    group_cols=["algorithm","population_size","evaluation_budget"]

    for keys,g in df.groupby(group_cols):
        r=g["runtime_s"].to_numpy(float)
        q1,q3=np.percentile(r,[25,75])
        iqr=q3-q1
        upper=q3+3*iqr
        rz=robust_z(r)

        h=g.copy()
        h["robust_z_runtime"]=rz
        h["iqr_extreme_upper"]=upper
        h["runtime_outlier"]=(
            (h["runtime_s"]>upper)
            | (np.abs(h["robust_z_runtime"])>5.0)
        )
        flagged.append(h)

    audit=pd.concat(flagged,ignore_index=True)
    audit.to_csv(
        folder/"runtime_outlier_audit.csv",
        index=False,encoding="utf-8-sig"
    )

    outs=audit[audit["runtime_outlier"]].sort_values(
        "runtime_s",ascending=False
    )
    outs.to_csv(
        folder/"runtime_outliers_only.csv",
        index=False,encoding="utf-8-sig"
    )

    summary=(
        audit.groupby(group_cols)
        .agg(
            runs=("runtime_s","size"),
            median_runtime_s=("runtime_s","median"),
            mean_runtime_s=("runtime_s","mean"),
            max_runtime_s=("runtime_s","max"),
            outlier_count=("runtime_outlier","sum"),
        )
        .reset_index()
    )
    summary.to_csv(
        folder/"runtime_outlier_summary.csv",
        index=False,encoding="utf-8-sig"
    )

    report=[
        f"# Runtime Outlier Audit — {args.profile}",
        "",
        f"- Runs audited: **{len(audit)}**",
        f"- Runtime outliers flagged: **{len(outs)}**",
        "",
        "## Configuration summary",
        "",
        summary.to_markdown(index=False),
        "",
        "## Flagged runs",
        "",
        outs[[
            "experiment_id","run_index","algorithm","population_size",
            "evaluation_budget","runtime_s","robust_z_runtime"
        ]].to_markdown(index=False) if len(outs) else "_No outliers flagged._",
        "",
        "Outliers are retained in the raw data. Median runtime should be the primary "
        "descriptive runtime statistic unless a rerun confirms a genuine algorithmic cause.",
    ]
    (folder/"runtime_outlier_report.md").write_text(
        "\n".join(report),encoding="utf-8"
    )
    print(report[2])
    print("Report:",folder/"runtime_outlier_report.md")


if __name__=="__main__":
    main()
