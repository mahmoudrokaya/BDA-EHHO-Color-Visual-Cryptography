#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Run short mechanism calibration on the SAME 12 pilot validation images.

Experiments
-----------
A) BEHHO threshold/fraction grid:
   thresholds = 0.70, 0.75, 0.80
   injection fractions = 0.20, 0.30

B) Hybrid schedule grid:
   (rho_max, rho_min) =
       (0.80,0.20), (0.70,0.30), (0.65,0.35)

Common:
   population=20, budget=400, 2 runs/image.

No test images are used.
"""

from __future__ import annotations
import csv, hashlib, json, time
from pathlib import Path
import numpy as np
import pandas as pd

from g1_02_rgb_decomposition import load_rgb
from g2_01_common_vc_adapter import FrozenVCObjective
from g2_12_calibration_config import (
    BEHHO_THRESHOLDS, BEHHO_INJECTION_FRACTIONS,
    HYBRID_SCHEDULES, CALIBRATION_IMAGES, CALIBRATION_RUNS,
    POPULATION, BUDGET, SELECTION_SEED, BASE_SEED
)
from g2_13_calibrated_behho_vc import optimize_calibrated_behho_vc
from g2_14_calibrated_bda_ehho_vc import optimize_calibrated_bda_ehho_vc

BASE=Path(r"D:\48\481\New Papers\BDA_To_HHO_paper")
DATA=BASE/"Data"
MANIFEST=BASE/"Outputs"/"Manifests"/"dataset_manifest.csv"
OUT=BASE/"Outputs"/"Group2_Mechanism_Calibration"

FIELDS=[
    "run_key","mechanism","variant","experiment_id","filename","run_index",
    "population_size","evaluation_budget","seed","best_score",
    "level_R","level_G","level_B","evaluations","runtime_s",
    "diversity_threshold","injection_fraction","injection_count",
    "mean_diversity","final_diversity",
    "rho_max","rho_min","bda_proposals","ehho_proposals","bda_fraction"
]


def seed_from(*parts):
    d=hashlib.sha256("|".join(map(str,parts)).encode()).digest()
    return int.from_bytes(d[:4],"little") & 0x7fffffff


def selected_images():
    m=pd.read_csv(MANIFEST)
    v=m[(m["dataset"]=="BSDS500")&(m["split"]=="validation")].copy()
    return (
        v.sample(n=CALIBRATION_IMAGES,random_state=SELECTION_SEED)
        .sort_values("experiment_id").reset_index(drop=True)
    )


def append(path,row):
    new=not path.exists()
    with path.open("a",newline="",encoding="utf-8-sig") as f:
        w=csv.DictWriter(f,fieldnames=FIELDS)
        if new: w.writeheader()
        w.writerow(row); f.flush()


def main():
    OUT.mkdir(parents=True,exist_ok=True)
    raw=OUT/"mechanism_calibration_raw.csv"
    done=set()
    if raw.exists():
        done=set(pd.read_csv(raw)["run_key"].astype(str))

    sel=selected_images()
    sel.to_csv(OUT/"selected_images.csv",index=False)

    for _,row in sel.iterrows():
        image=load_rgb(DATA/row["relative_to_data"],True)

        for run_idx in range(1,CALIBRATION_RUNS+1):
            seed=seed_from(BASE_SEED,row["experiment_id"],run_idx)
            obj=FrozenVCObjective.from_seed(image,seed)

            for thr in BEHHO_THRESHOLDS:
                for frac in BEHHO_INJECTION_FRACTIONS:
                    variant=f"thr{thr:.2f}_frac{frac:.2f}"
                    key=f"BEHHO|{row['experiment_id']}|r{run_idx}|{variant}"
                    if key not in done:
                        t0=time.perf_counter()
                        r=optimize_calibrated_behho_vc(
                            obj,population_size=POPULATION,
                            max_iterations=max(30,int(BUDGET/POPULATION*3)),
                            max_evaluations=BUDGET,seed=seed,
                            diversity_threshold=thr,
                            injection_fraction=frac,
                        )
                        dt=time.perf_counter()-t0
                        div=r.diversity_history
                        append(raw,{
                            "run_key":key,"mechanism":"BEHHO","variant":variant,
                            "experiment_id":row["experiment_id"],"filename":row["filename"],
                            "run_index":run_idx,"population_size":POPULATION,
                            "evaluation_budget":BUDGET,"seed":seed,
                            "best_score":r.best_score,
                            "level_R":r.best_levels_rgb[0],
                            "level_G":r.best_levels_rgb[1],
                            "level_B":r.best_levels_rgb[2],
                            "evaluations":r.evaluations,"runtime_s":dt,
                            "diversity_threshold":thr,
                            "injection_fraction":frac,
                            "injection_count":len(r.injection_iterations),
                            "mean_diversity":float(np.mean(div)) if div else np.nan,
                            "final_diversity":float(div[-1]) if div else np.nan,
                            "rho_max":"","rho_min":"",
                            "bda_proposals":"","ehho_proposals":"","bda_fraction":"",
                        })
                        done.add(key)
                        print(key, "score", round(r.best_score,6),
                              "inj",len(r.injection_iterations))

            for label,rmax,rmin in HYBRID_SCHEDULES:
                key=f"HYBRID|{row['experiment_id']}|r{run_idx}|{label}"
                if key not in done:
                    t0=time.perf_counter()
                    r=optimize_calibrated_bda_ehho_vc(
                        obj,population_size=POPULATION,
                        max_iterations=max(30,int(BUDGET/POPULATION*3)),
                        max_evaluations=BUDGET,seed=seed,
                        rho_max=rmax,rho_min=rmin,
                    )
                    dt=time.perf_counter()-t0
                    tot=r.bda_proposals+r.ehho_proposals
                    append(raw,{
                        "run_key":key,"mechanism":"HYBRID","variant":label,
                        "experiment_id":row["experiment_id"],"filename":row["filename"],
                        "run_index":run_idx,"population_size":POPULATION,
                        "evaluation_budget":BUDGET,"seed":seed,
                        "best_score":r.best_score,
                        "level_R":r.best_levels_rgb[0],
                        "level_G":r.best_levels_rgb[1],
                        "level_B":r.best_levels_rgb[2],
                        "evaluations":r.evaluations,"runtime_s":dt,
                        "diversity_threshold":"","injection_fraction":"",
                        "injection_count":"","mean_diversity":"","final_diversity":"",
                        "rho_max":rmax,"rho_min":rmin,
                        "bda_proposals":r.bda_proposals,
                        "ehho_proposals":r.ehho_proposals,
                        "bda_fraction":r.bda_proposals/tot if tot else np.nan,
                    })
                    done.add(key)
                    print(key, "score", round(r.best_score,6),
                          "BDAfrac", round(r.bda_proposals/tot,3) if tot else None)

    print("Done:",raw)

if __name__=="__main__":
    main()
