#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Group 2 / Code 09
Resumable BSDS500-validation tuning runner.

Key design principles
---------------------
1. Uses ONLY BSDS500 validation images.
2. The test split is never touched.
3. Same image/run master seed is used across competing algorithms.
4. Same fixed VC random fields are used across algorithms for a paired run.
5. Equal objective-evaluation budget within every configuration.
6. Records mechanism diagnostics:
   - EHHO diversity and injection counts,
   - BEHHO binary diversity and injection counts,
   - hybrid BDA/EHHO proposal counts,
   - convergence traces,
   - runtime and budget compliance.
7. Resumable: completed runs are skipped using a canonical run key.
8. Writes one row immediately after every completed run.

Recommended workflow
--------------------
python g2_09_run_validation_tuning.py --profile pilot
python g2_10_analyze_validation_tuning.py --profile pilot

Then:
python g2_09_run_validation_tuning.py --profile screen
python g2_10_analyze_validation_tuning.py --profile screen

Finally, after selecting one common configuration:
python g2_09_run_validation_tuning.py --profile confirm --population 20 --budget 600
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import time
from pathlib import Path

import numpy as np
import pandas as pd

from g1_02_rgb_decomposition import load_rgb
from g2_01_common_vc_adapter import FrozenVCObjective
from g2_02_hho_vc import optimize_hho_vc
from g2_03_ehho_vc import optimize_ehho_vc
from g2_04_behho_vc import optimize_behho_vc
from g2_05_bda_ehho_vc import optimize_bda_ehho_vc
from g2_08_tuning_profiles import PROFILES, ALGORITHMS

BASE = Path(r"D:\48\481\New Papers\BDA_To_HHO_paper")
DATA = BASE / "Data"
MANIFEST = BASE / "Outputs" / "Manifests" / "dataset_manifest.csv"
OUTROOT = BASE / "Outputs" / "Group2_Validation_Tuning"

ALGO_FUNCS = {
    "HHO-VC": optimize_hho_vc,
    "EHHO-VC": optimize_ehho_vc,
    "BEHHO-VC": optimize_behho_vc,
    "BDA-EHHO-VC": optimize_bda_ehho_vc,
}

FIELDS = [
    "run_key", "profile", "experiment_id", "filename",
    "image_width", "image_height", "run_index",
    "population_size", "evaluation_budget",
    "master_seed", "objective_seed", "optimizer_seed",
    "algorithm", "best_score", "level_R", "level_G", "level_B",
    "evaluations", "budget_compliant", "runtime_s",
    "iterations_completed", "convergence_points",
    "final_convergence_value",
    "diversity_mean", "diversity_final", "injection_count",
    "bda_proposals", "ehho_proposals", "hybrid_bda_fraction",
]


def stable_int_seed(*parts) -> int:
    payload = "|".join(map(str, parts)).encode("utf-8")
    digest = hashlib.sha256(payload).digest()
    return int.from_bytes(digest[:4], "little") & 0x7FFFFFFF


def select_validation_images(manifest: pd.DataFrame, n_images: int, seed: int):
    val = manifest[
        (manifest["dataset"] == "BSDS500")
        & (manifest["split"] == "validation")
    ].copy().sort_values("experiment_id")
    if len(val) < n_images:
        raise RuntimeError(
            f"Requested {n_images} validation images but only {len(val)} found."
        )
    if n_images == len(val):
        return val.reset_index(drop=True)
    return (
        val.sample(n=n_images, random_state=seed)
        .sort_values("experiment_id")
        .reset_index(drop=True)
    )


def existing_keys(csv_path: Path) -> set[str]:
    if not csv_path.exists():
        return set()
    try:
        df = pd.read_csv(csv_path, usecols=["run_key"])
        return set(df["run_key"].astype(str))
    except Exception:
        return set()


def append_row(csv_path: Path, row: dict):
    new_file = not csv_path.exists()
    with csv_path.open("a", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=FIELDS, extrasaction="ignore")
        if new_file:
            w.writeheader()
        w.writerow(row)
        f.flush()


def mechanism_fields(result: dict):
    div = result.get("diversity_history", None)
    injections = result.get("injection_iterations", None)

    if div is None:
        div_mean = np.nan
        div_final = np.nan
    else:
        div_mean = float(np.mean(div)) if len(div) else np.nan
        div_final = float(div[-1]) if len(div) else np.nan

    inj_count = int(len(injections)) if injections is not None else 0
    bda_n = int(result.get("bda_proposals", 0) or 0)
    ehho_n = int(result.get("ehho_proposals", 0) or 0)
    total_prop = bda_n + ehho_n
    bda_frac = float(bda_n / total_prop) if total_prop else np.nan

    return {
        "diversity_mean": div_mean,
        "diversity_final": div_final,
        "injection_count": inj_count,
        "bda_proposals": bda_n,
        "ehho_proposals": ehho_n,
        "hybrid_bda_fraction": bda_frac,
    }


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--profile", choices=sorted(PROFILES), default="pilot")
    p.add_argument("--population", type=int, default=None,
                   help="Override profile with one common population size.")
    p.add_argument("--budget", type=int, default=None,
                   help="Override profile with one common evaluation budget.")
    p.add_argument("--runs", type=int, default=None)
    p.add_argument("--images", type=int, default=None)
    p.add_argument("--algorithms", nargs="+", choices=ALGORITHMS, default=None)
    return p.parse_args()


def main():
    args = parse_args()
    profile = dict(PROFILES[args.profile])

    populations = (
        [args.population] if args.population is not None
        else list(profile["population_sizes"])
    )
    budgets = (
        [args.budget] if args.budget is not None
        else list(profile["evaluation_budgets"])
    )
    n_runs = args.runs or profile["runs_per_image"]
    n_images = args.images or profile["n_images"]
    algorithms = args.algorithms or list(ALGORITHMS)

    manifest = pd.read_csv(MANIFEST)
    selected = select_validation_images(
        manifest, n_images, profile["selection_seed"]
    )

    outdir = OUTROOT / args.profile
    traces = outdir / "traces"
    outdir.mkdir(parents=True, exist_ok=True)
    traces.mkdir(exist_ok=True)

    selected.to_csv(outdir / "selected_validation_images.csv", index=False)

    config = {
        "profile": args.profile,
        "n_images": n_images,
        "runs_per_image": n_runs,
        "population_sizes": populations,
        "evaluation_budgets": budgets,
        "algorithms": algorithms,
        "selection_seed": profile["selection_seed"],
        "base_seed": profile["base_seed"],
        "total_planned_runs": (
            n_images * n_runs * len(populations) * len(budgets) * len(algorithms)
        ),
    }
    (outdir / "run_configuration.json").write_text(
        json.dumps(config, indent=2), encoding="utf-8"
    )

    csv_path = outdir / "tuning_raw_results.csv"
    done = existing_keys(csv_path)

    planned = config["total_planned_runs"]
    print("=" * 80)
    print("GROUP 2 VALIDATION/TUNING")
    print("=" * 80)
    print(json.dumps(config, indent=2))
    print(f"Already complete: {len(done)}")
    print()

    completed_now = 0

    for _, row in selected.iterrows():
        image = load_rgb(DATA / row["relative_to_data"], True)

        for run_idx in range(1, n_runs + 1):
            # Same objective/master seed for every algorithm in this image/run.
            master_seed = stable_int_seed(
                profile["base_seed"], row["experiment_id"], run_idx
            )
            objective_seed = master_seed
            optimizer_seed = master_seed

            objective = FrozenVCObjective.from_seed(image, objective_seed)

            for pop in populations:
                for budget in budgets:
                    if budget < pop:
                        raise ValueError(
                            f"Budget {budget} must be >= population {pop}."
                        )

                    # Large nominal iteration cap; evaluation budget is the true stop.
                    nominal_iterations = max(
                        10,
                        int(math.ceil(budget / pop) * 3)
                    )

                    for algo in algorithms:
                        run_key = (
                            f"{args.profile}|{row['experiment_id']}|r{run_idx}|"
                            f"n{pop}|b{budget}|{algo}"
                        )
                        if run_key in done:
                            continue

                        fn = ALGO_FUNCS[algo]
                        start = time.perf_counter()
                        result = fn(
                            objective,
                            population_size=pop,
                            max_iterations=nominal_iterations,
                            max_evaluations=budget,
                            seed=optimizer_seed,
                        )
                        runtime = time.perf_counter() - start
                        d = result.__dict__.copy()

                        conv = list(d.get("convergence", []))
                        mech = mechanism_fields(d)
                        levels = d["best_levels_rgb"]

                        record = {
                            "run_key": run_key,
                            "profile": args.profile,
                            "experiment_id": row["experiment_id"],
                            "filename": row["filename"],
                            "image_width": int(row["width"]),
                            "image_height": int(row["height"]),
                            "run_index": run_idx,
                            "population_size": pop,
                            "evaluation_budget": budget,
                            "master_seed": master_seed,
                            "objective_seed": objective_seed,
                            "optimizer_seed": optimizer_seed,
                            "algorithm": algo,
                            "best_score": float(d["best_score"]),
                            "level_R": int(levels[0]),
                            "level_G": int(levels[1]),
                            "level_B": int(levels[2]),
                            "evaluations": int(d["evaluations"]),
                            "budget_compliant": int(d["evaluations"]) <= budget,
                            "runtime_s": float(runtime),
                            "iterations_completed": int(
                                d.get("iterations_completed", len(conv))
                            ),
                            "convergence_points": len(conv),
                            "final_convergence_value": (
                                float(conv[-1]) if conv else np.nan
                            ),
                            **mech,
                        }
                        append_row(csv_path, record)

                        trace_name = (
                            f"{row['experiment_id']}_r{run_idx}_n{pop}_b{budget}_"
                            f"{algo.replace('-','_')}.csv"
                        )
                        pd.DataFrame({
                            "step": np.arange(1, len(conv) + 1),
                            "best_so_far": conv,
                        }).to_csv(traces / trace_name, index=False)

                        done.add(run_key)
                        completed_now += 1
                        print(
                            f"[{len(done)}/{planned}] {row['experiment_id']} "
                            f"r{run_idx} n={pop} b={budget} {algo}: "
                            f"score={record['best_score']:.6f}, "
                            f"evals={record['evaluations']}, "
                            f"{runtime:.2f}s"
                        )

    print()
    print("Completed in this invocation:", completed_now)
    print("Raw results:", csv_path)


if __name__ == "__main__":
    main()
