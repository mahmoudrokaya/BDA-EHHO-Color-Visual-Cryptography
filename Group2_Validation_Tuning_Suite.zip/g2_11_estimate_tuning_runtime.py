#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Group 2 / Code 11
Estimate runtime before launching a tuning profile.

Uses the six-image Group2_Controlled_Validation mean runtime at budget=100 as
an empirical scaling anchor when available.
"""

from __future__ import annotations
import argparse, json
from pathlib import Path
import pandas as pd
from g2_08_tuning_profiles import PROFILES, ALGORITHMS

BASE = Path(r"D:\48\481\New Papers\BDA_To_HHO_paper")
ANCHOR = BASE/"Outputs"/"Group2_Controlled_Validation"/"group2_validation_summary.csv"

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--profile",choices=sorted(PROFILES),default="pilot")
    ap.add_argument("--population",type=int,default=None)
    ap.add_argument("--budget",type=int,default=None)
    args=ap.parse_args()

    p=dict(PROFILES[args.profile])
    pops=[args.population] if args.population else p["population_sizes"]
    buds=[args.budget] if args.budget else p["evaluation_budgets"]

    if ANCHOR.exists():
        a=pd.read_csv(ANCHOR)
        sec100=float(a["runtime_s"].mean())
    else:
        sec100=6.0

    total_runs=p["n_images"]*p["runs_per_image"]*len(pops)*len(buds)*len(ALGORITHMS)
    weighted=0.0
    for b in buds:
        runs_b=p["n_images"]*p["runs_per_image"]*len(pops)*len(ALGORITHMS)
        weighted += runs_b*sec100*(b/100.0)

    print(json.dumps({
        "profile":args.profile,
        "images":p["n_images"],
        "runs_per_image":p["runs_per_image"],
        "population_sizes":pops,
        "budgets":buds,
        "algorithms":len(ALGORITHMS),
        "total_runs":total_runs,
        "anchor_seconds_per_run_at_budget_100":sec100,
        "rough_serial_hours":weighted/3600.0,
        "note":"Linear budget scaling is only a planning approximation."
    },indent=2))

if __name__=="__main__":
    main()
