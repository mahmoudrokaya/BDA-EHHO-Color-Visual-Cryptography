#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Group 2 / Code 10
Analyze BSDS500 validation/tuning runs.

Produces:
- configuration-level performance/runtime summaries;
- paired algorithm ranks within image/run/configuration blocks;
- budget-compliance audit;
- EHHO/BEHHO injection diagnostics;
- BDA-EHHO proposal-balance diagnostics;
- convergence stability indicators;
- common-configuration Pareto shortlist balancing score and runtime;
- recommendation report.

Important:
The script does NOT select algorithm-specific budgets. A common configuration
(population size + evaluation budget) is evaluated across all algorithms to
preserve comparative fairness.
"""

from __future__ import annotations

import argparse
from pathlib import Path
import numpy as np
import pandas as pd

BASE = Path(r"D:\48\481\New Papers\BDA_To_HHO_paper")
OUTROOT = BASE / "Outputs" / "Group2_Validation_Tuning"


def pareto_front(df, score_col, runtime_col):
    keep = []
    for i, r in df.iterrows():
        dominated = False
        for j, q in df.iterrows():
            if i == j:
                continue
            if (
                q[score_col] <= r[score_col]
                and q[runtime_col] <= r[runtime_col]
                and (
                    q[score_col] < r[score_col]
                    or q[runtime_col] < r[runtime_col]
                )
            ):
                dominated = True
                break
        if not dominated:
            keep.append(i)
    return df.loc[keep].copy()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--profile", default="pilot")
    args = ap.parse_args()

    outdir = OUTROOT / args.profile
    raw_path = outdir / "tuning_raw_results.csv"
    if not raw_path.exists():
        raise FileNotFoundError(raw_path)

    df = pd.read_csv(raw_path)

    # Basic completion/fairness.
    budget_audit = (
        df.groupby(["population_size", "evaluation_budget", "algorithm"])
        .agg(
            runs=("run_key", "size"),
            mean_evaluations=("evaluations", "mean"),
            max_evaluations=("evaluations", "max"),
            budget_compliance_rate=("budget_compliant", "mean"),
        )
        .reset_index()
    )
    budget_audit["budget_compliance_rate"] *= 100.0
    budget_audit.to_csv(
        outdir / "budget_compliance_audit.csv", index=False, encoding="utf-8-sig"
    )

    # Paired ranks: lower fitness is better.
    block_cols = [
        "experiment_id", "run_index", "population_size", "evaluation_budget"
    ]
    ranked = df.copy()
    ranked["paired_rank"] = ranked.groupby(block_cols)["best_score"].rank(
        method="average", ascending=True
    )
    ranked.to_csv(
        outdir / "paired_ranked_results.csv", index=False, encoding="utf-8-sig"
    )

    algo_summary = (
        ranked.groupby(["population_size", "evaluation_budget", "algorithm"])
        .agg(
            runs=("best_score", "size"),
            mean_best_score=("best_score", "mean"),
            median_best_score=("best_score", "median"),
            sd_best_score=("best_score", "std"),
            mean_paired_rank=("paired_rank", "mean"),
            median_runtime_s=("runtime_s", "median"),
            mean_runtime_s=("runtime_s", "mean"),
        )
        .reset_index()
    )
    algo_summary.to_csv(
        outdir / "algorithm_by_configuration_summary.csv",
        index=False, encoding="utf-8-sig"
    )

    # Common configuration score: average behavior across all algorithms.
    cfg = (
        ranked.groupby(["population_size", "evaluation_budget"])
        .agg(
            mean_best_score=("best_score", "mean"),
            median_best_score=("best_score", "median"),
            mean_paired_rank=("paired_rank", "mean"),
            median_runtime_s=("runtime_s", "median"),
            mean_runtime_s=("runtime_s", "mean"),
            total_runs=("best_score", "size"),
        )
        .reset_index()
    )

    # Score stability at paired image/run level.
    per_block = (
        ranked.groupby(block_cols)
        .agg(
            block_mean_score=("best_score", "mean"),
            block_score_spread=("best_score", lambda x: float(np.max(x)-np.min(x))),
        )
        .reset_index()
    )
    stab = (
        per_block.groupby(["population_size", "evaluation_budget"])
        .agg(
            median_block_score_spread=("block_score_spread", "median"),
            max_block_score_spread=("block_score_spread", "max"),
        )
        .reset_index()
    )
    cfg = cfg.merge(stab, on=["population_size", "evaluation_budget"])

    # Relative normalized score/runtime for human-readable screening.
    smin, smax = cfg["mean_best_score"].min(), cfg["mean_best_score"].max()
    rmin, rmax = cfg["median_runtime_s"].min(), cfg["median_runtime_s"].max()
    cfg["normalized_score_loss"] = (
        (cfg["mean_best_score"] - smin) / max(smax-smin, 1e-12)
    )
    cfg["normalized_runtime_cost"] = (
        (cfg["median_runtime_s"] - rmin) / max(rmax-rmin, 1e-12)
    )
    cfg["balanced_screening_index"] = (
        0.70*cfg["normalized_score_loss"]
        + 0.30*cfg["normalized_runtime_cost"]
    )

    pareto = pareto_front(cfg, "mean_best_score", "median_runtime_s")
    pareto = pareto.sort_values(
        ["mean_best_score", "median_runtime_s"]
    )
    pareto.to_csv(
        outdir / "common_configuration_pareto_shortlist.csv",
        index=False, encoding="utf-8-sig"
    )

    cfg = cfg.sort_values("balanced_screening_index")
    cfg.to_csv(
        outdir / "common_configuration_summary.csv",
        index=False, encoding="utf-8-sig"
    )

    # Mechanism diagnostics.
    mechanism_rows = []

    for algo in ["EHHO-VC", "BEHHO-VC"]:
        x = ranked[ranked["algorithm"] == algo]
        if not x.empty:
            g = (
                x.groupby(["population_size", "evaluation_budget"])
                .agg(
                    runs=("best_score", "size"),
                    mean_injections=("injection_count", "mean"),
                    pct_runs_with_injection=("injection_count", lambda s: 100*np.mean(s>0)),
                    mean_diversity=("diversity_mean", "mean"),
                    mean_final_diversity=("diversity_final", "mean"),
                )
                .reset_index()
            )
            g.insert(0, "algorithm", algo)
            mechanism_rows.append(g)

    x = ranked[ranked["algorithm"] == "BDA-EHHO-VC"]
    if not x.empty:
        g = (
            x.groupby(["population_size", "evaluation_budget"])
            .agg(
                runs=("best_score", "size"),
                mean_bda_proposals=("bda_proposals", "mean"),
                mean_ehho_proposals=("ehho_proposals", "mean"),
                mean_bda_fraction=("hybrid_bda_fraction", "mean"),
            )
            .reset_index()
        )
        g.insert(0, "algorithm", "BDA-EHHO-VC")
        mechanism_rows.append(g)

    if mechanism_rows:
        mech = pd.concat(mechanism_rows, ignore_index=True, sort=False)
        mech.to_csv(
            outdir / "mechanism_diagnostics.csv",
            index=False, encoding="utf-8-sig"
        )
    else:
        mech = pd.DataFrame()

    best = cfg.iloc[0]
    report = [
        f"# Group 2 Validation/Tuning Analysis — {args.profile}",
        "",
        "## Completion and fairness",
        "",
        f"- Completed runs: **{len(df)}**",
        f"- Overall budget compliance: **{100*df['budget_compliant'].mean():.2f}%**",
        "",
        "## Common configuration ranking",
        "",
        "The ranking below is for screening only. It uses one common population/budget "
        "configuration across all algorithms. Lower fitness and lower runtime are preferred.",
        "",
        cfg.to_markdown(index=False),
        "",
        "## Pareto shortlist",
        "",
        pareto.to_markdown(index=False),
        "",
        "## Preliminary screening recommendation",
        "",
        f"The lowest balanced screening index in this profile is obtained by "
        f"**population={int(best['population_size'])}, "
        f"budget={int(best['evaluation_budget'])}**.",
        "",
        "This is not automatically the final configuration. The recommendation must also "
        "be checked against mechanism diagnostics, convergence stability, and the next "
        "validation stage. Final settings are frozen only after the confirm profile.",
        "",
        "## Mechanism diagnostics",
        "",
        mech.to_markdown(index=False) if not mech.empty else "_No mechanism diagnostics available._",
    ]
    (outdir / "tuning_analysis_report.md").write_text(
        "\n".join(report), encoding="utf-8"
    )

    try:
        with pd.ExcelWriter(
            outdir / "tuning_analysis.xlsx", engine="openpyxl"
        ) as w:
            cfg.to_excel(w, sheet_name="Common Configurations", index=False)
            algo_summary.to_excel(w, sheet_name="Algorithms", index=False)
            budget_audit.to_excel(w, sheet_name="Budget Audit", index=False)
            pareto.to_excel(w, sheet_name="Pareto Shortlist", index=False)
            if not mech.empty:
                mech.to_excel(w, sheet_name="Mechanisms", index=False)
    except Exception as exc:
        print("Excel export skipped:", exc)

    print("Analysis complete:", outdir / "tuning_analysis_report.md")


if __name__ == "__main__":
    main()
