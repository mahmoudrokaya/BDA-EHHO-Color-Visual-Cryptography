# Group 2 Validation/Tuning Suite

This suite tunes the **single-objective** Group-2 methods using only the
BSDS500 validation split. It does not touch the final 200-image BSDS500 test set.

## Why staged tuning?

A naive full grid can require many thousands of optimizer runs. The suite therefore
uses three profiles:

### 1. `pilot`
- 12 validation images
- 2 independent runs
- populations: 10, 20
- budgets: 200, 400
- 4 algorithms

Use this first to verify mechanism activity and obtain a first cost/performance picture.

### 2. `screen`
- 24 validation images
- 3 runs
- populations: 10, 20, 30
- budgets: 300, 600
- 4 algorithms

Use only after the pilot is satisfactory.

### 3. `confirm`
- all 100 BSDS500 validation images
- 5 independent runs
- one selected common configuration
- 4 algorithms

Override the population and budget after screening, for example:

```powershell
python g2_09_run_validation_tuning.py --profile confirm --population 20 --budget 600
python g2_10_analyze_validation_tuning.py --profile confirm
```

## Files

- `g2_08_tuning_profiles.py`
- `g2_09_run_validation_tuning.py`
- `g2_10_analyze_validation_tuning.py`
- `g2_11_estimate_tuning_runtime.py`

## Fairness

For a given image, run, population, and budget:

- all algorithms receive the same run-level master seed;
- all algorithms use the same VC probabilistic random fields;
- all algorithms receive the same objective-evaluation budget;
- the same population size is used wherever mathematically applicable.

The suite does **not** allow algorithm-specific budget tuning.

## Resume support

`g2_09_run_validation_tuning.py` appends each completed run immediately to
`tuning_raw_results.csv`. If interrupted, rerun the same command. Completed run
keys are skipped automatically.

## Recommended commands

First estimate cost:

```powershell
python g2_11_estimate_tuning_runtime.py --profile pilot
```

Then run pilot:

```powershell
python g2_09_run_validation_tuning.py --profile pilot
python g2_10_analyze_validation_tuning.py --profile pilot
```

After reviewing pilot outputs, proceed to `screen`, then `confirm`.

## Important interpretation

The `balanced_screening_index` in the analysis is a screening aid only:
70% normalized optimization score + 30% normalized runtime.

It must not be presented as a scientific result in the manuscript. Final configuration
selection should consider:
- score,
- runtime,
- convergence stability,
- EHHO/BEHHO diversity activity,
- hybrid proposal balance,
- paired behavior across images/runs.
