#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Group 2 / Code 08
Predefined validation/tuning profiles.

The tuning suite is deliberately staged so the project does not accidentally
launch an unnecessarily expensive 100-image x many-configurations experiment.

Profiles
--------
pilot:
    Small implementation/mechanism screen.
screen:
    Broader parameter/budget screen.
confirm:
    Full 100-image confirmation for ONE selected configuration.

All images come ONLY from the BSDS500 validation partition.
The BSDS500 test partition remains untouched.
"""

from __future__ import annotations

PROFILES = {
    "pilot": {
        "n_images": 12,
        "runs_per_image": 2,
        "population_sizes": [10, 20],
        "evaluation_budgets": [200, 400],
        "selection_seed": 481,
        "base_seed": 20260912,
    },
    "screen": {
        "n_images": 24,
        "runs_per_image": 3,
        "population_sizes": [10, 20, 30],
        "evaluation_budgets": [300, 600],
        "selection_seed": 481,
        "base_seed": 20260912,
    },
    "confirm": {
        "n_images": 100,
        "runs_per_image": 5,
        # Override these from the command line after screening.
        "population_sizes": [20],
        "evaluation_budgets": [600],
        "selection_seed": 481,
        "base_seed": 20260912,
    },
}

ALGORITHMS = [
    "HHO-VC",
    "EHHO-VC",
    "BEHHO-VC",
    "BDA-EHHO-VC",
]
