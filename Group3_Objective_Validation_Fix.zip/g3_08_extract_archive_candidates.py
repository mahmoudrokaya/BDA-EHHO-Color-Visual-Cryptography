#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
g3_08_extract_archive_candidates.py — FIXED

Fix:
The archive `bits` column contains 24-character binary strings. Pandas may
infer these as numeric values when read normally; long values can then be
converted to floating/scientific notation (e.g. containing "." or "e"), which
destroys direct character-by-character parsing and can also remove leading 0s.

This version forces:
    dtype={"bits": "string"}
when reading every archive CSV, preserving the exact 24-bit text.

No optimizer rerun is required.
"""

from __future__ import annotations
from pathlib import Path
import numpy as np
import pandas as pd

BASE = Path(r"D:\48\481\New Papers\BDA_To_HHO_paper")
ARCH = BASE / "Outputs" / "Group3_MO_Validation" / "archives"
OUT = BASE / "Outputs" / "Group3_Objective_Validation"
MAX_PER_ARCHIVE = 40


def normalize_bits_text(bits) -> str:
    """
    Preserve/validate an exact 24-bit binary string.

    Because archive CSVs were originally written from strings, reading with
    dtype='string' should provide the exact representation, including leading
    zeros.
    """
    s = str(bits).strip()

    # Remove harmless CSV/quote whitespace only.
    s = s.replace(" ", "")

    if len(s) != 24:
        raise ValueError(
            f"Expected exactly 24 binary characters, got {len(s)}: {s!r}. "
            "Make sure the archive CSV is read with dtype={'bits':'string'}."
        )

    invalid = set(s) - {"0", "1"}
    if invalid:
        raise ValueError(
            f"Invalid characters in 24-bit string {s!r}: {sorted(invalid)}"
        )

    return s


def decode_bits(bits):
    s = normalize_bits_text(bits)
    b = [int(x) for x in s]

    vals = []
    for start in (0, 8, 16):
        v = 0
        for bit in b[start:start+8]:
            v = (v << 1) | bit
        # Keep executable VC group-count constraint.
        vals.append(max(2, min(255, v)))

    return vals


def compromise_idx(F):
    ideal = F.min(axis=0)
    nadir = F.max(axis=0)
    Z = (F - ideal) / np.maximum(nadir - ideal, 1e-12)
    d = np.sqrt(np.mean(Z**2, axis=1))
    return int(np.argmin(d))


def select_indices(df):
    n = len(df)
    F = df[
        [
            "f_reconstruction",
            "f_security",
            "f_robustness",
            "f_complexity",
        ]
    ].to_numpy(float)

    ids = set()

    # Objective-wise extremes.
    for j in range(F.shape[1]):
        ids.add(int(np.argmin(F[:, j])))
        ids.add(int(np.argmax(F[:, j])))

    # Equal-weight normalized compromise representative.
    ids.add(compromise_idx(F))

    if n <= MAX_PER_ARCHIVE:
        ids.update(range(n))
    else:
        # Evenly sample over complexity to cover the archive.
        order = np.argsort(F[:, 3], kind="mergesort")
        pos = np.linspace(
            0, n - 1, MAX_PER_ARCHIVE
        ).round().astype(int)
        ids.update(order[pos].tolist())

    return sorted(ids)


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    rows = []

    archive_files = sorted(ARCH.glob("*_archive.csv"))
    if not archive_files:
        raise FileNotFoundError(
            f"No archive CSV files found in:\n{ARCH}"
        )

    total_archive_rows = 0

    for p in archive_files:
        # CRITICAL FIX: preserve exact bit strings and leading zeros.
        df = pd.read_csv(
            p,
            dtype={"bits": "string"},
            keep_default_na=False,
        )

        required = {
            "f_reconstruction",
            "f_security",
            "f_robustness",
            "f_complexity",
            "bits",
        }
        missing = required - set(df.columns)
        if missing:
            raise ValueError(
                f"{p.name} is missing columns: {sorted(missing)}"
            )

        total_archive_rows += len(df)

        # Validate ALL bit strings in this archive before sampling.
        normalized_bits = [
            normalize_bits_text(x) for x in df["bits"].tolist()
        ]
        df = df.copy()
        df["bits"] = normalized_bits

        ids = select_indices(df)

        stem = p.stem.replace("_archive", "")
        experiment_id, run_token = stem.rsplit("_r", 1)
        run_index = int(run_token)

        for idx in ids:
            r = df.iloc[idx]
            bits_text = normalize_bits_text(r["bits"])
            levels = decode_bits(bits_text)

            rows.append({
                "experiment_id": experiment_id,
                "run_index": run_index,
                "archive_file": p.name,
                "archive_row": int(idx),
                "bits": bits_text,
                "level_R": levels[0],
                "level_G": levels[1],
                "level_B": levels[2],
                "old_f1_reconstruction": float(
                    r["f_reconstruction"]
                ),
                "old_f2_security": float(
                    r["f_security"]
                ),
                "old_f3_robustness": float(
                    r["f_robustness"]
                ),
                "old_f4_complexity": float(
                    r["f_complexity"]
                ),
            })

        print(
            f"{p.name}: archive={len(df)}, "
            f"selected={len(ids)}, bits=PASS"
        )

    out = pd.DataFrame(rows)

    # Final integrity checks.
    if out.empty:
        raise RuntimeError("No candidates were extracted.")

    if not out["bits"].map(
        lambda x: len(str(x)) == 24
        and set(str(x)) <= {"0", "1"}
    ).all():
        raise AssertionError(
            "Final candidate table contains invalid bit strings."
        )

    out.to_csv(
        OUT / "candidate_index.csv",
        index=False,
        encoding="utf-8-sig",
    )

    report = [
        "# Archive Candidate Extraction Integrity Report",
        "",
        f"- Archive files: **{len(archive_files)}**",
        f"- Total archive rows checked: **{total_archive_rows}**",
        f"- Candidates selected: **{len(out)}**",
        "- Every source bit string preserved as exactly 24 binary characters: **PASS**",
        "- Leading zero preservation: **PASS (string dtype enforced)**",
        "",
        "The fix changes only CSV parsing. No optimizer result, Pareto archive, "
        "objective value, or experimental parameter was modified.",
    ]

    (OUT / "candidate_extraction_integrity.md").write_text(
        "\n".join(report),
        encoding="utf-8",
    )

    print("=" * 72)
    print("ARCHIVE CANDIDATE EXTRACTION: PASS")
    print("=" * 72)
    print("Archives:", len(archive_files))
    print("Archive rows checked:", total_archive_rows)
    print("Selected candidates:", len(out))
    print("Output:", OUT / "candidate_index.csv")


if __name__ == "__main__":
    main()
