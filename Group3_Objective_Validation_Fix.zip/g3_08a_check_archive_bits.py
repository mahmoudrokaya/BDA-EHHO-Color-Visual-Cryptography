#!/usr/bin/env python3
from pathlib import Path
import pandas as pd

BASE=Path(r"D:\48\481\New Papers\BDA_To_HHO_paper")
ARCH=BASE/"Outputs"/"Group3_MO_Validation"/"archives"

files=sorted(ARCH.glob("*_archive.csv"))
if not files:
    raise FileNotFoundError(ARCH)

bad=[]
for p in files:
    df=pd.read_csv(p,dtype={"bits":"string"},keep_default_na=False)
    for i,s in enumerate(df["bits"].astype(str)):
        s=s.strip().replace(" ","")
        if len(s)!=24 or (set(s)-{"0","1"}):
            bad.append((p.name,i,s))

print("Archive files:",len(files))
print("Invalid bit rows:",len(bad))
if bad:
    print("First invalid examples:",bad[:10])
    raise SystemExit(1)
print("ARCHIVE BIT-STRING INTEGRITY: PASS")
