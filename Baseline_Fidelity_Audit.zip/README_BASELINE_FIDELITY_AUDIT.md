# Baseline Fidelity Audit

Place `g1_09_baseline_fidelity_audit.py` in:

`D:\48\481\New Papers\BDA_To_HHO_paper\Codes\Group1_Common_VC_Core`

Then run:

```powershell
python g1_09_baseline_fidelity_audit.py
```

The audit compares the current Group-1 implementation against the published BDA color-VC procedure and the supplied BDA MATLAB structure.

It does not silently resolve ambiguities in the source paper. Instead, it labels:
- MATCH
- MATCH_WITH_TIE_RULE
- ADAPTATION
- DEVIATION
- CONFIGURABLE

Main expected finding:
The current Python baseline optimizes RGB channels sequentially, while the supplied/reference BDA implementation updates XR/XG/XB jointly within the same BDA loop. This should be corrected before HHO/EHHO experiments.

Outputs are written to:
`D:\48\481\New Papers\BDA_To_HHO_paper\Outputs\Baseline_Fidelity_Audit`
