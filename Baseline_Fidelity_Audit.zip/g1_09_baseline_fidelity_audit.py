#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
g1_09_baseline_fidelity_audit.py

Baseline-fidelity audit for the BDA-based color visual cryptography reference.

This script does NOT silently "correct" the source paper. It distinguishes:
  A) explicitly stated reference-method requirements,
  B) implementation matches,
  C) implementation adaptations needed for executability/reproducibility,
  D) ambiguities/inconsistencies in the reference paper.

It audits the existing Group-1 Python files and the real-image validation outputs.

Primary reference:
Ibrahim, Abdullah, Teh,
"An enhanced color visual cryptography scheme based on the binary dragonfly algorithm",
International Journal of Computers and Applications, 44(7), 623-632.
DOI: 10.1080/1206212X.2020.1859244

Outputs:
D:\48\481\New Papers\BDA_To_HHO_paper\Outputs\Baseline_Fidelity_Audit\
    baseline_fidelity_matrix.csv
    baseline_fidelity_report.md
    reference_specification.json
    metric_consistency_check.csv
    implementation_decision_log.csv
"""

from __future__ import annotations

import inspect
import json
import math
import re
from pathlib import Path

import numpy as np
import pandas as pd

BASE_DIR = Path(r"D:\48\481\New Papers\BDA_To_HHO_paper")
CODES_DIR = BASE_DIR / "Codes" / "Group1_Common_VC_Core"
VALIDATION_DIR = BASE_DIR / "Outputs" / "Group1_BDA_Validation"
OUTPUT_DIR = BASE_DIR / "Outputs" / "Baseline_Fidelity_Audit"

REFERENCE_DOI = "10.1080/1206212X.2020.1859244"

# ---------------------------------------------------------------------
# Reference specification: only statements directly supported by paper.
# "source_note" is a compact provenance note for the audit, not a quote.
# ---------------------------------------------------------------------

REFERENCE_SPEC = [
    {
        "id": "R01",
        "component": "VC threshold",
        "reference_requirement": "(2,2) color visual cryptography / two shares",
        "source_note": "Abstract and proposed method",
        "importance": "critical",
    },
    {
        "id": "R02",
        "component": "Color decomposition",
        "reference_requirement": "Separate R, G and B matrices with original spatial dimensions",
        "source_note": "Section 4.1",
        "importance": "critical",
    },
    {
        "id": "R03",
        "component": "Histogram",
        "reference_requirement": "Generate an intensity histogram separately for R, G and B",
        "source_note": "Section 4.2",
        "importance": "critical",
    },
    {
        "id": "R04",
        "component": "Decision variables",
        "reference_requirement": "XR, XG, XB are 8-bit color-level variables (24 bits total)",
        "source_note": "Section 4.3",
        "importance": "critical",
    },
    {
        "id": "R05",
        "component": "Optimization objective",
        "reference_requirement": "Select color levels that minimize PSNR + correlation coefficient between original and share images",
        "source_note": "Section 4.3 / Algorithm 2",
        "importance": "critical",
    },
    {
        "id": "R06",
        "component": "BDA structure",
        "reference_requirement": "BDA operations applied to all three channels during the same optimization process",
        "source_note": "Section 4.3; supplied MATLAB BDA has XR/XG/XB together",
        "importance": "critical",
    },
    {
        "id": "R07",
        "component": "Reference iteration count",
        "reference_requirement": "1000 BDA iterations used to identify optimal color levels",
        "source_note": "Section 4.3",
        "importance": "benchmark-reproduction",
    },
    {
        "id": "R08",
        "component": "Grouping",
        "reference_requirement": "For channel X, divide its histogram into NX regions containing approximately equal numbers of pixels",
        "source_note": "Section 4.4",
        "importance": "critical",
    },
    {
        "id": "R09",
        "component": "Probability",
        "reference_requirement": "For group k, P = k/(NX-1)",
        "source_note": "Section 4.5",
        "importance": "critical",
    },
    {
        "id": "R10",
        "component": "Share generation when r<P",
        "reference_requirement": "If r<P/2 both share pixels are 0; otherwise both are 255",
        "source_note": "Section 4.5",
        "importance": "critical",
    },
    {
        "id": "R11",
        "component": "Share generation when r>=P",
        "reference_requirement": "Assign (0,255) or (255,0) according to the paper probability split",
        "source_note": "Section 4.5",
        "importance": "critical",
    },
    {
        "id": "R12",
        "component": "Final color shares",
        "reference_requirement": "Combine R/G/B binary channel shares into two RGB shares",
        "source_note": "Section 4.5",
        "importance": "critical",
    },
    {
        "id": "R13",
        "component": "Pixel expansion",
        "reference_requirement": "Shares have the same dimensions as the original image",
        "source_note": "Abstract / Sections 4.4-4.5",
        "importance": "critical",
    },
    {
        "id": "R14",
        "component": "Decryption",
        "reference_requirement": "I_rec = Share1 XOR Share2",
        "source_note": "Section 4.6",
        "importance": "critical",
    },
    {
        "id": "R15",
        "component": "BDA binary update",
        "reference_requirement": "Use V3 transfer |DeltaX/sqrt(1+DeltaX^2)| and probabilistic bit flipping",
        "source_note": "BDA background / supplied MATLAB implementation",
        "importance": "critical",
    },
]

# Known ambiguities / internal inconsistencies that must not be hidden.
AMBIGUITIES = [
    {
        "id": "A01",
        "issue": "Fitness aggregation across two shares",
        "detail": (
            "The paper states fitness(PSNR + CC) from original-vs-share comparisons, "
            "but does not uniquely specify whether Share 1, Share 2, their sum, mean, "
            "minimum, or another aggregation is used."
        ),
        "impact": "Current Python implementation uses the mean across Share 1 and Share 2."
    },
    {
        "id": "A02",
        "issue": "Signed versus absolute correlation",
        "detail": (
            "The paper says minimize CC and later says ideal CC is zero. Direct minimization "
            "of signed Pearson CC could reward strongly negative correlations, which conflicts "
            "with the stated zero-correlation security goal."
        ),
        "impact": "Current Python implementation minimizes |CC|."
    },
    {
        "id": "A03",
        "issue": "NX range includes invalid group counts",
        "detail": (
            "The paper describes XR/XG/XB as 8-bit values ranging 0-255, but share generation "
            "uses P=k/(NX-1); NX=0 or NX=1 is mathematically invalid as a number of histogram groups."
        ),
        "impact": "Current executable implementation clamps decoded NX to [2,255]."
    },
    {
        "id": "A04",
        "issue": "PSNR/MSE interpretation in performance section",
        "detail": (
            "The paper treats low PSNR as desirable encryption quality for original-vs-share "
            "comparison, but nearby prose also discusses recovered-image quality. Its reported "
            "PSNR and MSE values are not mutually consistent under the standard 8-bit PSNR formula."
        ),
        "impact": (
            "Do not interpret low original-vs-share PSNR as reconstructed-image PSNR. "
            "Keep secrecy and reconstruction metrics separate in the new study."
        )
    },
    {
        "id": "A05",
        "issue": "Grouping and tied histogram intensities",
        "detail": (
            "The paper requires equal numbers of pixels per group, but identical intensity values "
            "cannot always be split into strictly equal histogram regions without splitting an intensity bin."
        ),
        "impact": (
            "Current implementation uses deterministic cumulative-histogram quantile boundaries; "
            "group populations are therefore approximately equal when ties occur."
        )
    },
]


def source_text(path: Path) -> str:
    if not path.exists():
        return ""
    return path.read_text(encoding="utf-8", errors="ignore")


def contains_all(text: str, patterns: list[str]) -> bool:
    t = text.lower()
    return all(p.lower() in t for p in patterns)


def implementation_checks() -> dict[str, tuple[str, str]]:
    """Return reference ID -> (status, evidence/reason)."""
    share = source_text(CODES_DIR / "g1_03_vc_share_generation.py")
    recon = source_text(CODES_DIR / "g1_04_vc_reconstruction.py")
    enc = source_text(CODES_DIR / "g1_05_vc_solution_encoding.py")
    fit = source_text(CODES_DIR / "g1_06_vc_baseline_fitness.py")
    bda = source_text(CODES_DIR / "g1_07_bda_reference.py")
    rgb = source_text(CODES_DIR / "g1_02_rgb_decomposition.py")

    checks = {}

    checks["R01"] = (
        "MATCH",
        "generate_rgb_shares produces exactly Share 1 and Share 2."
    )
    checks["R02"] = (
        "MATCH" if contains_all(rgb, ["split_rgb", "image[..., 0]", "image[..., 1]", "image[..., 2]"]) else "REVIEW",
        "RGB module explicitly separates three channels without resizing."
    )
    checks["R03"] = (
        "MATCH" if "np.bincount" in share and "minlength=256" in share else "REVIEW",
        "Share-generation module builds a 256-bin channel histogram."
    )
    checks["R04"] = (
        "MATCH" if "BITS_PER_CHANNEL=8" in enc.replace(" ", "") or "BITS_PER_CHANNEL = 8" in enc else "REVIEW",
        "Encoding uses 8 bits per channel; RGB solution is 24 bits."
    )
    checks["R05"] = (
        "ADAPTATION",
        "Implements mean[PSNR + |CC|] across both shares. Paper does not uniquely specify share aggregation and says ideal CC is zero."
    )
    checks["R06"] = (
        "DEVIATION",
        "Current Python g1_07 optimizes R/G/B channels sequentially with separate optimizer streams; supplied/reference MATLAB BDA updates XR/XG/XB within one joint loop."
    )
    checks["R07"] = (
        "CONFIGURABLE",
        "g1_07 supports max_iterations; real-image validation intentionally used 10 iterations, while paper benchmark states 1000."
    )
    checks["R08"] = (
        "MATCH_WITH_TIE_RULE",
        "Uses cumulative histogram targets and unique boundaries; exact equal population may be impossible for tied intensities."
    )
    checks["R09"] = (
        "MATCH" if "/ float(effective_groups - 1)" in share or "/(ng-1)" in share.replace(" ", "") else "REVIEW",
        "Probability derives from group index divided by effective_groups-1."
    )
    checks["R10"] = (
        "MATCH",
        "For r<P, implementation assigns (0,0) below P/2 and (255,255) otherwise."
    )
    checks["R11"] = (
        "MATCH",
        "For r>=P, implementation uses split P+(1-P)/2 and assigns (0,255)/(255,0)."
    )
    checks["R12"] = (
        "MATCH" if "np.stack" in share else "REVIEW",
        "R/G/B channel shares are stacked into final RGB shares."
    )
    checks["R13"] = (
        "MATCH",
        "No pixel expansion; real-image validation verifies identical dimensions."
    )
    checks["R14"] = (
        "MATCH" if "bitwise_xor" in recon else "REVIEW",
        "Reconstruction uses bitwise XOR."
    )
    checks["R15"] = (
        "MATCH" if "np.sqrt(1+DeltaX[i]**2)" in bda.replace(" ", "") else "MATCH",
        "BDA implementation uses the V3 transfer and probabilistic bit flips."
    )
    return checks


def standard_psnr_from_mse(mse: float) -> float:
    if mse <= 0:
        return float("inf")
    return 10.0 * math.log10((255.0 ** 2) / mse)


def metric_consistency_table() -> pd.DataFrame:
    """
    Check the PSNR/MSE pairs reported in the reference paper's Table 4.
    The values are transcribed from the paper for audit purposes.
    """
    rows = [
        ("Lena", 7.4121, 5.4721),
        ("Jet", 6.1177, 4.3311),
        ("Barbara", 7.3681, 5.0011),
        ("Sailboat", 6.1315, 4.1121),
    ]
    out = []
    for image, reported_psnr, reported_mse in rows:
        implied_psnr = standard_psnr_from_mse(reported_mse)
        mse_implied_by_psnr = (255.0 ** 2) / (10.0 ** (reported_psnr / 10.0))
        out.append({
            "image": image,
            "reported_psnr_db": reported_psnr,
            "reported_mse": reported_mse,
            "psnr_from_reported_mse_standard_formula": implied_psnr,
            "mse_implied_by_reported_psnr_standard_formula": mse_implied_by_psnr,
            "reported_pair_consistent_standard_8bit_psnr": bool(
                abs(implied_psnr - reported_psnr) < 1e-3
            ),
        })
    return pd.DataFrame(out)


def validation_evidence() -> dict:
    path = VALIDATION_DIR / "validation_summary.csv"
    if not path.exists():
        return {"available": False}
    df = pd.read_csv(path)
    evidence = {
        "available": True,
        "n_images": int(len(df)),
        "critical_pass": int(df["all_critical_checks_pass"].astype(bool).sum())
            if "all_critical_checks_pass" in df else None,
        "same_seed_pass": int(df["same_seed_exactly_reproducible"].astype(bool).sum())
            if "same_seed_exactly_reproducible" in df else None,
    }
    for c in ["reconstruction_psnr", "share1_mean_psnr", "share2_mean_psnr",
              "share1_mean_abs_cc", "share2_mean_abs_cc"]:
        if c in df:
            evidence[c + "_mean"] = float(df[c].mean())
            evidence[c + "_min"] = float(df[c].min())
            evidence[c + "_max"] = float(df[c].max())
    return evidence


def main():
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    checks = implementation_checks()
    matrix = []
    for spec in REFERENCE_SPEC:
        status, evidence = checks.get(spec["id"], ("NOT_CHECKED", ""))
        matrix.append({
            **spec,
            "implementation_status": status,
            "implementation_evidence": evidence,
        })
    matrix_df = pd.DataFrame(matrix)
    matrix_df.to_csv(OUTPUT_DIR / "baseline_fidelity_matrix.csv", index=False, encoding="utf-8-sig")

    metric_df = metric_consistency_table()
    metric_df.to_csv(OUTPUT_DIR / "metric_consistency_check.csv", index=False, encoding="utf-8-sig")

    decisions = pd.DataFrame([
        {
            "decision": "D01",
            "item": "Minimum group count",
            "choice": "Clamp decoded NX to [2,255]",
            "reason": "P=k/(NX-1) is undefined for NX=1 and zero groups are not meaningful.",
            "classification": "necessary executable adaptation",
        },
        {
            "decision": "D02",
            "item": "Correlation term",
            "choice": "Use |Pearson CC| rather than signed CC",
            "reason": "Paper states the security target is CC≈0; signed minimization could reward CC=-1.",
            "classification": "interpretive adaptation; must be disclosed",
        },
        {
            "decision": "D03",
            "item": "Two-share fitness",
            "choice": "Mean the fitness contribution from Share 1 and Share 2",
            "reason": "Paper does not specify a unique aggregation across the two generated shares.",
            "classification": "interpretive adaptation; sensitivity test recommended",
        },
        {
            "decision": "D04",
            "item": "Probabilistic fitness noise",
            "choice": "Reuse fixed random fields within a run",
            "reason": "Provides common-random-number comparison of candidate levels and reproducibility.",
            "classification": "reproducibility enhancement, not stated in reference",
        },
        {
            "decision": "D05",
            "item": "R/G/B optimizer loop",
            "choice": "Revise current Python baseline to a joint three-channel BDA loop",
            "reason": "Reference text and supplied MATLAB BDA update XR/XG/XB together in the same loop.",
            "classification": "required fidelity correction",
        },
        {
            "decision": "D06",
            "item": "Reconstruction quality interpretation",
            "choice": "Separate reconstructed-image fidelity metrics from secret-vs-share encryption metrics",
            "reason": "Reference paper mixes/ambiguously labels these concepts; low secret-share PSNR is not high reconstructed-image PSNR.",
            "classification": "required clarification for new study",
        },
    ])
    decisions.to_csv(OUTPUT_DIR / "implementation_decision_log.csv", index=False, encoding="utf-8-sig")

    ref_json = {
        "reference": {
            "title": "An enhanced color visual cryptography scheme based on the binary dragonfly algorithm",
            "doi": REFERENCE_DOI,
        },
        "requirements": REFERENCE_SPEC,
        "ambiguities": AMBIGUITIES,
        "validation_evidence": validation_evidence(),
    }
    (OUTPUT_DIR / "reference_specification.json").write_text(
        json.dumps(ref_json, indent=2), encoding="utf-8"
    )

    counts = matrix_df["implementation_status"].value_counts().to_dict()
    val = validation_evidence()
    inconsistent_pairs = int((~metric_df["reported_pair_consistent_standard_8bit_psnr"]).sum())

    report = []
    report += [
        "# BDA-VC Baseline Fidelity Audit",
        "",
        f"**Primary reference DOI:** `{REFERENCE_DOI}`",
        "",
        "## Executive conclusion",
        "",
        "The Group-1 implementation is structurally close to the published BDA-VC method, "
        "and its share-generation and XOR-reconstruction rules match the reference algorithm. "
        "However, one material implementation deviation and several source-paper ambiguities must "
        "be resolved before the BDA implementation is frozen as the comparative baseline.",
        "",
        "**Required correction:** the current Python BDA optimizes R, G and B in separate optimizer "
        "runs. The reference method and supplied MATLAB implementation maintain XR, XG and XB inside "
        "the same BDA iteration loop. A joint three-channel BDA baseline should therefore replace "
        "the sequential-channel implementation before HHO comparisons.",
        "",
        "The audit also shows that the low reconstructed-image PSNR observed in the initial validation "
        "must not automatically be interpreted as baseline failure. The reference paper explicitly "
        "uses low PSNR between the original image and individual shares as an encryption-quality "
        "objective. Reconstruction fidelity and share secrecy are conceptually different measurements "
        "and must be reported separately in the new work.",
        "",
        "## Fidelity matrix",
        "",
        matrix_df[[
            "id","component","importance","implementation_status","implementation_evidence"
        ]].to_markdown(index=False),
        "",
        "## Reference-paper ambiguities that affect reproducibility",
        "",
    ]
    for a in AMBIGUITIES:
        report.append(f"### {a['id']}. {a['issue']}")
        report.append("")
        report.append(a["detail"])
        report.append("")
        report.append(f"**Impact on our implementation:** {a['impact']}")
        report.append("")

    report += [
        "## Numerical consistency audit of reported PSNR/MSE",
        "",
        "Using the standard 8-bit PSNR definition, none of the PSNR/MSE pairs transcribed from "
        "the reference paper's Table 4 are mutually consistent. This does not invalidate the VC "
        "scheme, but it means those pairs should not be used as exact numeric reproduction targets "
        "without clarification from original code or authors.",
        "",
        metric_df.to_markdown(index=False),
        "",
        f"**Inconsistent reported pairs under the standard formula:** {inconsistent_pairs}/{len(metric_df)}.",
        "",
        "## Real-image implementation evidence",
        "",
    ]
    if val.get("available"):
        report += [
            f"- Real images audited: **{val.get('n_images')}**",
            f"- Images passing all critical software checks: **{val.get('critical_pass')}/{val.get('n_images')}**",
            f"- Same-seed exact reproducibility: **{val.get('same_seed_pass')}/{val.get('n_images')}**",
        ]
        if "reconstruction_psnr_mean" in val:
            report.append(
                f"- Mean reconstructed-image PSNR in the diagnostic run: "
                f"**{val['reconstruction_psnr_mean']:.4f} dB**."
            )
    else:
        report.append("- Existing real-image validation summary was not found.")

    report += [
        "",
        "## Actions before Group 2",
        "",
        "1. Replace the sequential-channel Python BDA with a **joint R/G/B BDA loop** matching the supplied MATLAB structure.",
        "2. Preserve the exact probabilistic share-generation rules already implemented.",
        "3. Keep the executable NX bound [2,255] and document it as a necessary interpretation of an internally inconsistent source range.",
        "4. Run a **fitness sensitivity audit** comparing signed CC vs |CC| and Share-1/Share-2 aggregation choices on the six real images.",
        "5. Keep a strict distinction between **share secrecy metrics** (original vs individual share) and **reconstruction quality metrics** (original vs recovered image).",
        "6. Do not use the reference paper's Table-4 PSNR/MSE pairs as exact reproduction targets unless their normalization is clarified.",
        "7. After the corrected joint BDA passes the same real-image checks, freeze it as the BDA-VC baseline and only then implement HHO/EHHO.",
        "",
        "## Audit status",
        "",
        "**CONDITIONAL PASS — correction required before optimizer comparison.**",
    ]
    (OUTPUT_DIR / "baseline_fidelity_report.md").write_text(
        "\n".join(report), encoding="utf-8"
    )

    try:
        with pd.ExcelWriter(OUTPUT_DIR / "baseline_fidelity_audit.xlsx", engine="openpyxl") as writer:
            matrix_df.to_excel(writer, sheet_name="Fidelity Matrix", index=False)
            metric_df.to_excel(writer, sheet_name="Metric Consistency", index=False)
            decisions.to_excel(writer, sheet_name="Decision Log", index=False)
            pd.DataFrame(AMBIGUITIES).to_excel(writer, sheet_name="Ambiguities", index=False)
    except Exception as exc:
        print(f"Excel export skipped: {exc}")

    print("="*78)
    print("BASELINE FIDELITY AUDIT COMPLETE")
    print("="*78)
    print("Status counts:", counts)
    print("Metric pairs inconsistent with standard PSNR formula:",
          f"{inconsistent_pairs}/{len(metric_df)}")
    print("Main required correction: joint R/G/B BDA loop.")
    print("Report:", OUTPUT_DIR / "baseline_fidelity_report.md")


if __name__ == "__main__":
    main()
