#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
E5 statistical analysis.

Primary inferential unit: image.
Five stochastic runs are summarized by image median.

Security:
- four leakage metrics, all lower better.

Robustness:
- per family/rate results;
- rate-averaged family degradation;
- seen robustness = central block;
- unseen robustness = average of random block, dropout, bit flip, crop loss;
- all-family robustness.

Tests:
- Friedman across five algorithms;
- paired Wilcoxon each SO method vs MO;
- Holm correction within each metric;
- matched-pairs rank-biserial effect size;
- win/loss/tie counts.
"""

from __future__ import annotations
import json
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.stats import friedmanchisquare,wilcoxon

from e5_01_common import ALGORITHMS

BASE=Path(r"D:\48\481\New Papers\BDA_To_HHO_paper")
OUT=BASE/"Outputs"/"E5_Robustness_Security"
MO="MO-BDA-EHHO-VC"
SO=[a for a in ALGORITHMS if a!=MO]

SEC_METRICS=[
    "sec_abs_corr",
    "sec_nmi",
    "sec_hist_overlap",
    "sec_similarity_nmse",
]


def holm(pvals):
    p=np.asarray(pvals,float);m=len(p);order=np.argsort(p)
    adj=np.empty(m);running=0.0
    for rank,idx in enumerate(order):
        v=(m-rank)*p[idx];running=max(running,v);adj[idx]=min(running,1.0)
    return adj


def rank_biserial(x,y):
    d=np.asarray(x,float)-np.asarray(y,float)
    d=d[np.abs(d)>1e-15]
    if len(d)==0:return 0.0
    a=np.abs(d);order=np.argsort(a);ranks=np.empty(len(d))
    vals=a[order];start=0;rank0=1
    while start<len(d):
        end=start+1
        while end<len(d) and vals[end]==vals[start]:
            end+=1
        ranks[order[start:end]]=np.mean(np.arange(rank0,rank0+end-start))
        rank0+=end-start;start=end
    wp=ranks[d>0].sum();wn=ranks[d<0].sum()
    return float((wp-wn)/(wp+wn)) if wp+wn else 0.0


def image_median(df,metric):
    x=df.groupby(["experiment_id","algorithm"])[metric].median().reset_index()
    return x.pivot(index="experiment_id",columns="algorithm",values=metric)


def compare_metric(df,metric):
    piv=image_median(df,metric)
    arrays=[piv[a].to_numpy() for a in ALGORITHMS]
    fr=friedmanchisquare(*arrays)
    mo=piv[MO].to_numpy()
    rows=[];pvals=[]

    for alg in SO:
        x=piv[alg].to_numpy()
        w=wilcoxon(
            x,mo,zero_method="pratt",
            alternative="two-sided",method="auto"
        )
        d=x-mo
        rows.append({
            "metric":metric,
            "algorithm_A":alg,
            "algorithm_B":MO,
            "median_difference_A_minus_MO":float(np.median(d)),
            "wilcoxon_statistic":float(w.statistic),
            "p_raw":float(w.pvalue),
            "rank_biserial_A_minus_MO":rank_biserial(x,mo),
            "wins_MO":int(np.sum(mo<x)),
            "wins_A":int(np.sum(x<mo)),
            "ties":int(np.sum(np.abs(d)<=1e-12)),
        })
        pvals.append(float(w.pvalue))

    adj=holm(pvals)
    for r,p in zip(rows,adj):
        r["p_holm"]=float(p)
        r["significant_holm_0_05"]=bool(p<.05)

    return {
        "metric":metric,
        "friedman_statistic":float(fr.statistic),
        "friedman_p":float(fr.pvalue),
    },rows


def main():
    sec=pd.read_csv(OUT/"e5_security_results.csv")
    rob=pd.read_csv(OUT/"e5_robustness_results.csv")

    # Average Share1/Share2 first for each family/rate.
    rob_sr=(
        rob.groupby(
            ["experiment_id","run_index","algorithm","family","rate"]
        )
        .agg(
            delta_nmse=("delta_nmse","mean"),
            secret_nmse=("secret_nmse","mean"),
            secret_psnr_db=("secret_psnr_db","mean"),
        )
        .reset_index()
    )

    # Rate-average per family.
    fam=(
        rob_sr.groupby(
            ["experiment_id","run_index","algorithm","family"]
        )
        .agg(
            mean_delta_nmse=("delta_nmse","mean"),
            mean_secret_nmse=("secret_nmse","mean"),
            mean_secret_psnr_db=("secret_psnr_db","mean"),
        )
        .reset_index()
    )

    # Wide family aggregates for primary robustness comparisons.
    wide=fam.pivot_table(
        index=["experiment_id","run_index","algorithm"],
        columns="family",
        values="mean_delta_nmse"
    ).reset_index()

    unseen=[
        "random_block","pixel_dropout","bit_flip","crop_loss"
    ]
    wide["rob_seen_central_delta_nmse"]=wide["central_block"]
    wide["rob_unseen_delta_nmse"]=wide[unseen].mean(axis=1)
    wide["rob_allfamilies_delta_nmse"]=wide[
        ["central_block"]+unseen
    ].mean(axis=1)

    security_summary=(
        sec.groupby("algorithm")[SEC_METRICS]
        .median().reset_index()
    )
    security_summary.to_csv(
        OUT/"e5_security_summary.csv",
        index=False,encoding="utf-8-sig"
    )

    robustness_summary=(
        fam.groupby(["algorithm","family"])
        .agg(
            median_delta_nmse=("mean_delta_nmse","median"),
            median_secret_nmse=("mean_secret_nmse","median"),
            median_secret_psnr_db=("mean_secret_psnr_db","median"),
        )
        .reset_index()
    )
    robustness_summary.to_csv(
        OUT/"e5_robustness_summary.csv",
        index=False,encoding="utf-8-sig"
    )

    primary_rob_summary=(
        wide.groupby("algorithm")[
            [
                "rob_seen_central_delta_nmse",
                "rob_unseen_delta_nmse",
                "rob_allfamilies_delta_nmse",
            ]
        ].median().reset_index()
    )
    primary_rob_summary.to_csv(
        OUT/"e5_primary_robustness_summary.csv",
        index=False,encoding="utf-8-sig"
    )

    omnibus=[];pairs=[]

    for metric in SEC_METRICS:
        o,p=compare_metric(sec,metric)
        omnibus.append(o);pairs.extend(p)

    for metric in [
        "rob_seen_central_delta_nmse",
        "rob_unseen_delta_nmse",
        "rob_allfamilies_delta_nmse",
    ]:
        o,p=compare_metric(wide,metric)
        omnibus.append(o);pairs.extend(p)

    omnibus=pd.DataFrame(omnibus)
    pairdf=pd.DataFrame(pairs)

    omnibus.to_csv(
        OUT/"e5_omnibus_tests.csv",
        index=False,encoding="utf-8-sig"
    )
    pairdf.to_csv(
        OUT/"e5_pairwise_vs_mo.csv",
        index=False,encoding="utf-8-sig"
    )

    # Rate response summaries for figures/tables.
    rate_summary=(
        rob_sr.groupby(["algorithm","family","rate"])
        .agg(
            median_delta_nmse=("delta_nmse","median"),
            median_secret_nmse=("secret_nmse","median"),
            median_psnr_db=("secret_psnr_db","median"),
        )
        .reset_index()
    )
    rate_summary.to_csv(
        OUT/"e5_robustness_by_rate.csv",
        index=False,encoding="utf-8-sig"
    )

    decision={
        "experiment":"E5 robustness and security",
        "design":"100 images x 5 runs x 5 frozen methods; no optimizer rerun",
        "security_metrics":[
            "absolute secret-share correlation",
            "normalized mutual information",
            "histogram overlap",
            "1-normalized secret-share MSE similarity"
        ],
        "robustness_families":[
            "central block erasure (seen)",
            "random block erasure",
            "pixel dropout",
            "bit flip",
            "crop loss"
        ],
        "rates":[0.05,0.10,0.20,0.30],
        "primary_robustness_metrics":[
            "seen central-block mean delta NMSE",
            "unseen-family mean delta NMSE",
            "all-family mean delta NMSE"
        ],
        "note":"E5 evaluates generalization beyond the optimized central-block robustness objective; unseen perturbations are primary evidence of robustness transfer."
    }
    (OUT/"e5_decision.json").write_text(
        json.dumps(decision,indent=2),encoding="utf-8"
    )

    report=[
        "# E5 — Robustness and Security Experiments","",
        "## Design","",
        "- 100 BSDS500 validation images.",
        "- 5 runs per image.",
        "- Five frozen methods; no optimizer rerun.",
        "- E4 representative solutions reused.",
        "- Independent common E5 share-generation realization per image/run.",
        "- Identical perturbation masks across methods within image/run.",
        "- Primary inferential unit: image median across five runs.","",
        "## Security summary (lower is better)","",
        security_summary.to_markdown(index=False),"",
        "## Primary robustness summary (lower is better)","",
        primary_rob_summary.to_markdown(index=False),"",
        "## Perturbation-family robustness summary","",
        robustness_summary.to_markdown(index=False),"",
        "## Omnibus tests","",
        omnibus.to_markdown(index=False),"",
        "## Pairwise comparisons against MO-BDA–EHHO","",
        pairdf.to_markdown(index=False),"",
        "## Interpretation rule","",
        "Security conclusions should be supported particularly by NMI and histogram overlap, because they were not optimization objectives. "
        "Robustness generalization should be supported primarily by the unseen perturbation aggregate (random block, dropout, bit flip, crop loss), "
        "not only by central block erasure, which was included in the MO objective."
    ]

    (OUT/"e5_analysis_report.md").write_text(
        "\n".join(report),encoding="utf-8"
    )

    try:
        with pd.ExcelWriter(OUT/"e5_analysis.xlsx",engine="openpyxl") as w:
            security_summary.to_excel(w,sheet_name="Security Summary",index=False)
            primary_rob_summary.to_excel(w,sheet_name="Primary Robustness",index=False)
            robustness_summary.to_excel(w,sheet_name="Robustness Families",index=False)
            rate_summary.to_excel(w,sheet_name="Robustness Rates",index=False)
            omnibus.to_excel(w,sheet_name="Omnibus",index=False)
            pairdf.to_excel(w,sheet_name="Pairwise vs MO",index=False)
    except Exception as e:
        print("Excel export skipped:",e)

    print("E5 analysis complete.")
    print("Report:",OUT/"e5_analysis_report.md")


if __name__=="__main__":
    main()
