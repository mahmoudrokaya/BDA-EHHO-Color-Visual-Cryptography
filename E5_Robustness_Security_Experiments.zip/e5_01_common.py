#!/usr/bin/env python3
from __future__ import annotations
import hashlib, numpy as np

ALGORITHMS=["HHO-VC","EHHO-VC","BEHHO-VC-Calibrated","BDA-EHHO-VC-Calibrated","MO-BDA-EHHO-VC"]
RATES=(0.05,0.10,0.20,0.30)
FAMILIES=("central_block","random_block","pixel_dropout","bit_flip","crop_loss")
E5_BASE_SEED=20260914

def stable_seed(*parts):
    d=hashlib.sha256("|".join(map(str,parts)).encode()).digest()
    return int.from_bytes(d[:4],"little") & 0x7fffffff

def share_seed(experiment_id,run_index):
    return stable_seed(E5_BASE_SEED,experiment_id,run_index,"E5_SHARES")

def perturb_seed(experiment_id,run_index,family,rate,share_index):
    return stable_seed(E5_BASE_SEED,experiment_id,run_index,family,float(rate),int(share_index),"E5_PERTURB")
