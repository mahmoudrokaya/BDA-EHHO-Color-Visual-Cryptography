#!/usr/bin/env python3
from __future__ import annotations
import math,numpy as np
MAX_MSE=255.0**2

def mse(a,b):
    x=np.asarray(a,np.float64);y=np.asarray(b,np.float64)
    return float(np.mean((x-y)**2))

def psnr_from_mse(m):
    return float("inf") if m<=1e-15 else float(10*np.log10(MAX_MSE/m))

def block_hw(h,w,frac):
    area=max(1,int(round(h*w*float(frac))));aspect=w/max(h,1)
    bh=max(1,int(round(math.sqrt(area/max(aspect,1e-12)))));bw=max(1,int(round(area/bh)))
    return min(bh,h),min(bw,w)

def central_block(shape,frac):
    h,w,_=shape;bh,bw=block_hw(h,w,frac);y0=max(0,(h-bh)//2);x0=max(0,(w-bw)//2)
    m=np.zeros((h,w),bool);m[y0:y0+bh,x0:x0+bw]=True
    return np.repeat(m[...,None],3,2)

def random_block(shape,frac,rng):
    h,w,_=shape;bh,bw=block_hw(h,w,frac);y0=int(rng.integers(0,max(1,h-bh+1)));x0=int(rng.integers(0,max(1,w-bw+1)))
    m=np.zeros((h,w),bool);m[y0:y0+bh,x0:x0+bw]=True
    return np.repeat(m[...,None],3,2)

def pixel_mask(shape,frac,rng):
    h,w,_=shape;m=rng.random((h,w))<float(frac);return np.repeat(m[...,None],3,2)

def crop_mask(shape,frac):
    h,w,_=shape;sf=1.0-math.sqrt(max(0.0,1.0-float(frac)));ch=max(1,int(round(h*sf)));cw=max(1,int(round(w*sf)))
    m=np.zeros((h,w),bool);m[h-ch:h,:]=True;m[:,w-cw:w]=True
    return np.repeat(m[...,None],3,2)

def apply_damage(share,family,mask):
    out=share.copy()
    if family=="bit_flip":out[mask]=255-out[mask]
    else:out[mask]=0
    return out

def measures(secret,clean_rec,damaged_rec):
    d=mse(clean_rec,damaged_rec);s=mse(secret,damaged_rec)
    return {"delta_nmse":float(d/MAX_MSE),"secret_nmse":float(s/MAX_MSE),"secret_psnr_db":psnr_from_mse(s)}
