#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
E5 main evaluator.

No optimizer rerun.
Uses E4 representative solutions and an independent E5 evaluation realization.

Outputs:
- e5_security_results.csv
- e5_robustness_results.csv
- e5_clean_reconstruction_summary.csv
"""

from __future__ import annotations

import csv
from pathlib import Path
import numpy as np
import pandas as pd

from g1_02_rgb_decomposition import load_rgb
from g1_03_vc_share_generation import generate_rgb_shares
from g1_04_vc_reconstruction import xor_reconstruct

from e5_01_common import (
    ALGORITHMS, RATES, FAMILIES, share_seed, perturb_seed
)
from e5_03_security_metrics import evaluate_security, mse as sec_mse
from e5_04_robustness_metrics import (
    central_block, random_block, pixel_mask, crop_mask,
    apply_damage, measures
)

BASE=Path(r"D:\48\481\New Papers\BDA_To_HHO_paper")
DATA=BASE/"Data"
MANIFEST=BASE/"Outputs"/"Manifests"/"dataset_manifest.csv"
OUT=BASE/"Outputs"/"E5_Robustness_Security"
SOL=OUT/"e5_solution_table.csv"

SEC_FIELDS=[
    "run_key","experiment_id","filename","run_index","algorithm",
    "sec_abs_corr","sec_nmi","sec_hist_overlap","sec_similarity_nmse"
]
ROB_FIELDS=[
    "run_key","experiment_id","filename","run_index","algorithm",
    "family","rate","share_index",
    "delta_nmse","secret_nmse","secret_psnr_db"
]
CLEAN_FIELDS=[
    "run_key","experiment_id","filename","run_index","algorithm",
    "clean_secret_nmse"
]


def append(path, fields, row):
    new=not path.exists()
    with path.open("a",newline="",encoding="utf-8-sig") as f:
        w=csv.DictWriter(f,fieldnames=fields)
        if new:w.writeheader()
        w.writerow(row);f.flush()


def existing_keys(path):
    if not path.exists(): return set()
    try:
        return set(pd.read_csv(path,usecols=["run_key"])["run_key"].astype(str))
    except Exception:
        return set()


def build_masks(shape,eid,run):
    masks={}
    for family in FAMILIES:
        for rate in RATES:
            for share_index in (1,2):
                seed=perturb_seed(eid,run,family,rate,share_index)
                rng=np.random.default_rng(seed)

                if family=="central_block":
                    m=central_block(shape,rate)
                elif family=="random_block":
                    m=random_block(shape,rate,rng)
                elif family in ("pixel_dropout","bit_flip"):
                    m=pixel_mask(shape,rate,rng)
                elif family=="crop_loss":
                    m=crop_mask(shape,rate)
                else:
                    raise ValueError(family)

                masks[(family,rate,share_index)]=m
    return masks


def main():
    OUT.mkdir(parents=True,exist_ok=True)

    solutions=pd.read_csv(SOL)
    man=pd.read_csv(MANIFEST)
    path_map=dict(zip(man["experiment_id"],man["relative_to_data"]))

    sec_path=OUT/"e5_security_results.csv"
    rob_path=OUT/"e5_robustness_results.csv"
    clean_path=OUT/"e5_clean_reconstruction_summary.csv"

    sec_done=existing_keys(sec_path)
    clean_done=existing_keys(clean_path)

    total=len(solutions)

    for block_idx,((eid,run),block) in enumerate(
        solutions.groupby(["experiment_id","run_index"],sort=True),
        start=1
    ):
        image=load_rgb(DATA/path_map[eid],True)

        # Common share-generation realization across all five methods.
        ss=np.random.SeedSequence(share_seed(eid,int(run)))
        children=ss.spawn(3)
        random_fields=tuple(
            np.random.default_rng(children[i]).random(image.shape[:2])
            for i in range(3)
        )

        masks=build_masks(image.shape,eid,int(run))

        for _,r in block.iterrows():
            alg=r["algorithm"]
            key=f"{eid}|r{int(run)}|{alg}"
            levels=(int(r["level_R"]),int(r["level_G"]),int(r["level_B"]))

            share1,share2,_=generate_rgb_shares(
                image,levels,random_fields=random_fields
            )
            clean=xor_reconstruct(share1,share2)

            if key not in sec_done:
                sec=evaluate_security(image,share1,share2)
                append(sec_path,SEC_FIELDS,{
                    "run_key":key,"experiment_id":eid,"filename":r["filename"],
                    "run_index":int(run),"algorithm":alg,**sec
                })
                sec_done.add(key)

            if key not in clean_done:
                clean_nmse=sec_mse(image,clean)/(255.0**2)
                append(clean_path,CLEAN_FIELDS,{
                    "run_key":key,"experiment_id":eid,"filename":r["filename"],
                    "run_index":int(run),"algorithm":alg,
                    "clean_secret_nmse":float(clean_nmse)
                })
                clean_done.add(key)

            # robustness rows are cheap enough to overwrite only through unique output;
            # skip entire method if all expected rows already exist.
            # 5 families * 4 rates * 2 shares = 40 rows/method.
            expected_rows=40
            if rob_path.exists():
                try:
                    old=pd.read_csv(
                        rob_path,
                        usecols=["run_key"]
                    )
                    n_old=int((old["run_key"].astype(str)==key).sum())
                except Exception:
                    n_old=0
            else:
                n_old=0

            if n_old>=expected_rows:
                continue

            # If partially written due interruption, drop partial rows once,
            # then regenerate complete method block.
            if n_old>0:
                old=pd.read_csv(rob_path)
                old=old[old["run_key"].astype(str)!=key]
                old.to_csv(rob_path,index=False,encoding="utf-8-sig")

            for family in FAMILIES:
                for rate in RATES:
                    for share_index in (1,2):
                        mask=masks[(family,rate,share_index)]

                        if share_index==1:
                            d1=apply_damage(share1,family,mask)
                            d2=share2
                        else:
                            d1=share1
                            d2=apply_damage(share2,family,mask)

                        damaged=xor_reconstruct(d1,d2)
                        vals=measures(image,clean,damaged)

                        append(rob_path,ROB_FIELDS,{
                            "run_key":key,"experiment_id":eid,
                            "filename":r["filename"],"run_index":int(run),
                            "algorithm":alg,"family":family,
                            "rate":float(rate),"share_index":share_index,
                            **vals
                        })

        print(
            f"[{block_idx}/500 blocks] {eid} r{int(run)} complete"
        )

    print("E5 evaluation complete.")
    print("Security:",sec_path)
    print("Robustness:",rob_path)


if __name__=="__main__":
    main()
