# E5 — Robustness and Security Experiments

E5 evaluates the **security** and **robustness generalization** of the five frozen methods after E4.

## Important design principle

**No optimizer is rerun.**

E5 reuses the exact representative solutions already established in E4:
- HHO-VC
- EHHO-VC
- BEHHO-VC-Calibrated
- BDA-EHHO-VC-Calibrated
- MO-BDA-EHHO-VC compromise solution

For fairness, every method within the same image/run is evaluated using:
- the same independent E5 share-generation random fields;
- the same perturbation masks;
- the same damage rates.

This separates E5 evaluation randomness from optimization randomness.

## Dataset/protocol

- 100 BSDS500 validation images
- 5 runs/image
- 5 methods
- 2,500 attained solutions
- no optimization calls

## Security experiments

All four security measures are minimized.

1. **Absolute secret-share Pearson correlation**
   - This is the frozen MO security objective.

2. **Normalized mutual information (NMI)**
   - External leakage measure not used as an optimization objective.

3. **Histogram overlap**
   - External distributional similarity measure not used as an optimization objective.

4. **1 - normalized secret-share MSE**
   - Lower means greater secret-share dissimilarity.

Security is evaluated over both shares and all RGB channels.

The strongest generalization evidence should come from NMI and histogram overlap because they were not optimized directly.

## Robustness experiments

Each damage model is evaluated at:
- 5%
- 10%
- 20%
- 30%

Damage is applied separately to Share 1 and Share 2 and then averaged.

### R1 — Central block erasure
This is the **seen** perturbation family because central block erasure is the frozen f3 MO robustness objective.

### R2 — Random-location block erasure
Out-of-objective perturbation.

### R3 — Pixel dropout
Out-of-objective perturbation.

### R4 — Bit flip
Out-of-objective perturbation.

### R5 — Crop loss
Out-of-objective perturbation.

For each damaged reconstruction E5 records:
- clean-vs-damaged normalized MSE;
- secret-vs-damaged normalized MSE;
- secret-vs-damaged PSNR.

Primary robustness analyses:
1. seen central-block rate-averaged delta NMSE;
2. unseen-family average delta NMSE across random block, dropout, bit flip, and crop loss;
3. all-family average delta NMSE.

The **unseen perturbation aggregate** is the most important evidence of robustness generalization.

## Statistics

Primary inferential unit: image.

For each algorithm:
- 5 runs/image -> median;
- 100 paired image-level observations.

Tests:
- Friedman omnibus;
- paired Wilcoxon vs MO-BDA-EHHO;
- Holm correction;
- matched-pairs rank-biserial effect size;
- win/loss/tie counts.

## Files

- e5_01_common.py
- e5_02_build_solution_table.py
- e5_03_security_metrics.py
- e5_04_robustness_metrics.py
- e5_05_run_security_robustness.py
- e5_06_analyze.py
- e5_07_run_all.py

## Installation

Copy all files into:

`D:\48\481\New Papers\BDA_To_HHO_paper\Codes\Group3_MO_BDA_EHHO`

Install:

```powershell
pip install -r requirements_e5.txt
```

## Run

You may run the full E5 pipeline with:

```powershell
python e5_07_run_all.py
```

or individually:

```powershell
python e5_02_build_solution_table.py
python e5_05_run_security_robustness.py
python e5_06_analyze.py
```

## Outputs

`D:\48\481\New Papers\BDA_To_HHO_paper\Outputs\E5_Robustness_Security`

Important files:
- e5_analysis_report.md
- e5_decision.json
- e5_security_summary.csv
- e5_primary_robustness_summary.csv
- e5_robustness_summary.csv
- e5_robustness_by_rate.csv
- e5_omnibus_tests.csv
- e5_pairwise_vs_mo.csv
- e5_analysis.xlsx

## Interpretation discipline

Do not claim robustness only from central block erasure because that perturbation was included in the MO objective.

A strong E5 robustness claim requires favorable behavior under the **unseen perturbation aggregate**.

Similarly, do not claim improved secrecy only from Pearson correlation because it was directly optimized. NMI and histogram overlap provide the more independent confirmation.
