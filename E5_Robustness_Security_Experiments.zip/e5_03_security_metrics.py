#!/usr/bin/env python3
from __future__ import annotations
import numpy as np
MAX_MSE=255.0**2

def mse(a,b):
    x=np.asarray(a,np.float64);y=np.asarray(b,np.float64)
    return float(np.mean((x-y)**2))

def pearson(a,b):
    x=np.asarray(a,np.float64).ravel();y=np.asarray(b,np.float64).ravel()
    sx,sy=x.std(),y.std()
    if sx<=1e-15 or sy<=1e-15:return 0.0
    return float(np.corrcoef(x,y)[0,1])

def entropy(p):
    p=np.asarray(p,float);p=p[p>0]
    return float(-np.sum(p*np.log(p))) if len(p) else 0.0

def normalized_mutual_information(a,b,bins=32):
    x=np.asarray(a).ravel();y=np.asarray(b).ravel()
    joint,_,_=np.histogram2d(x,y,bins=bins,range=[[0,256],[0,256]])
    joint=joint.astype(float);joint/=max(joint.sum(),1.0)
    px=joint.sum(1);py=joint.sum(0);den=px[:,None]*py[None,:];nz=joint>0
    mi=np.sum(joint[nz]*np.log(joint[nz]/np.maximum(den[nz],1e-300)))
    h=np.sqrt(max(entropy(px)*entropy(py),1e-300))
    return float(mi/h) if h>0 else 0.0

def histogram_overlap(a,b,bins=32):
    ha,_=np.histogram(a,bins=bins,range=(0,256));hb,_=np.histogram(b,bins=bins,range=(0,256))
    ha=ha.astype(float);hb=hb.astype(float);ha/=max(ha.sum(),1.0);hb/=max(hb.sum(),1.0)
    return float(np.minimum(ha,hb).sum())

def evaluate_security(secret,share1,share2):
    corr=[];nmi=[];hov=[];sim=[]
    for share in (share1,share2):
        for ch in range(3):
            sec=secret[...,ch];sh=share[...,ch]
            corr.append(abs(pearson(sec,sh)))
            nmi.append(normalized_mutual_information(sec,sh))
            hov.append(histogram_overlap(sec,sh))
            nmse=min(max(mse(sec,sh)/MAX_MSE,0.0),1.0);sim.append(1.0-nmse)
    return {"sec_abs_corr":float(np.mean(corr)),"sec_nmi":float(np.mean(nmi)),
            "sec_hist_overlap":float(np.mean(hov)),"sec_similarity_nmse":float(np.mean(sim))}
