#!/usr/bin/env python3
from __future__ import annotations
from pathlib import Path
import numpy as np,pandas as pd
from g1_05_vc_solution_encoding import decode_channel_bits
from e4_01_common import ALGORITHMS_SO
from e5_01_common import ALGORITHMS

BASE=Path(r"D:\48\481\New Papers\BDA_To_HHO_paper")
E4=BASE/"Outputs"/"E4_Multiobjective_Comparison"
SO=E4/"e4_singleobjective_common_eval.csv"
ARCH=E4/"mo_archives_common_eval"
OUT=BASE/"Outputs"/"E5_Robustness_Security"
OBJ=["eval_f1_reconstruction","eval_f2_security","eval_f3_robustness","eval_f4_complexity"]

def decode_bits_string(s):
    s=str(s).strip()
    if len(s)!=24 or set(s)-{"0","1"}: raise ValueError(f"Invalid bit string {s!r}")
    b=np.asarray([int(x) for x in s],dtype=np.uint8)
    return (decode_channel_bits(b[:8]),decode_channel_bits(b[8:16]),decode_channel_bits(b[16:24]))

def compromise_index(F,ideal,nadir):
    Z=(F-ideal)/np.maximum(nadir-ideal,1e-12)
    return int(np.argmin(np.sqrt(np.mean(Z**2,axis=1))))

def main():
    OUT.mkdir(parents=True,exist_ok=True)
    so=pd.read_csv(SO); rows=[]
    for (eid,run),block in so.groupby(["experiment_id","run_index"],sort=True):
        for _,r in block.iterrows():
            rows.append({"experiment_id":eid,"filename":r["filename"],"run_index":int(run),"algorithm":r["algorithm"],
                         "level_R":int(r["level_R"]),"level_G":int(r["level_G"]),"level_B":int(r["level_B"]),
                         "source":"E4_singleobjective_attained_solution"})
        p=ARCH/f"{eid}_r{int(run)}_mo_archive_common_eval.csv"
        mo=pd.read_csv(p,dtype={"bits":"string"},keep_default_na=False)
        Fmo=mo[OBJ].to_numpy(float); Fso=block[OBJ].to_numpy(float); pooled=np.vstack([Fmo,Fso])
        ci=compromise_index(Fmo,pooled.min(0),pooled.max(0)); lv=decode_bits_string(mo.iloc[ci]["bits"])
        rows.append({"experiment_id":eid,"filename":block.iloc[0]["filename"],"run_index":int(run),"algorithm":"MO-BDA-EHHO-VC",
                     "level_R":int(lv[0]),"level_G":int(lv[1]),"level_B":int(lv[2]),"source":"E4_MO_equal_weight_compromise"})
    out=pd.DataFrame(rows); expected=2500
    if len(out)!=expected: raise RuntimeError(f"Expected {expected}, found {len(out)}")
    counts=out.groupby("algorithm").size().to_dict()
    for alg in ALGORITHMS:
        if counts.get(alg,0)!=500: raise RuntimeError(f"{alg}: {counts.get(alg,0)}")
    out.to_csv(OUT/"e5_solution_table.csv",index=False,encoding="utf-8-sig")
    print("E5 solution table:",len(out));print(counts)

if __name__=="__main__":main()
