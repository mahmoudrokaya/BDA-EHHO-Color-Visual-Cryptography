#!/usr/bin/env python3
import subprocess,sys

scripts=[
    "e5_02_build_solution_table.py",
    "e5_05_run_security_robustness.py",
    "e5_06_analyze.py",
]

for s in scripts:
    print("="*78);print("RUNNING",s);print("="*78)
    r=subprocess.run([sys.executable,s])
    if r.returncode!=0:
        raise SystemExit(f"{s} failed with return code {r.returncode}")

print("="*78)
print("E5 ROBUSTNESS + SECURITY PIPELINE: COMPLETE")
print("="*78)
