# E4 — Multi-Objective Comparative Experiment

E4 tests the multi-objective effect after Group 2 and Group 3 were frozen.

## Methods
Single-objective methods reused from Group 2:
- HHO-VC
- EHHO-VC
- BEHHO-VC-Calibrated
- BDA-EHHO-VC-Calibrated

New multi-objective method:
- MO-BDA-EHHO-VC

## Frozen configuration
- Population N = 30
- Evaluation budget B = 600
- 100 BSDS500 validation images
- 5 runs/image
- MO archive size = 100

## Frozen objectives
- f1 normalized reconstruction MSE
- f2 mean absolute secret-share Pearson correlation
- f3 mean normalized clean-vs-damaged reconstruction MSE under 5/10/20% central Share-1 block erasure
- f4 mean RGB group count / 255

## Fairness
The four single-objective methods are NOT rerun. Their frozen Group-2 solutions are reused.

MO-BDA-EHHO is the only method newly optimized.

All attained solutions are then re-evaluated under a separate common E4 evaluation seed for each image/run. This decouples comparison from each optimizer's own stochastic realization.

## Primary E4 metrics
- Hypervolume, higher is better
- IGD to pooled empirical nondominated front, lower is better
- Additive epsilon indicator, lower is better
- Pareto-set cardinality/diversity

## Secondary analysis
One MO compromise point is selected by equal-weight normalized distance to the pooled ideal point and compared on f1-f4. This is secondary and should not replace the Pareto-set analysis.

## Statistics
Primary inferential unit: image.
Five runs are summarized by image median.
Friedman omnibus tests and paired Wilcoxon tests with Holm correction are used.

## Run order

Copy all files into:
`D:\48\481\New Papers\BDA_To_HHO_paper\Codes\Group3_MO_BDA_EHHO`

Install:
```powershell
pip install -r requirements_e4.txt
```

Estimate runtime:
```powershell
python e4_07_estimate_runtime.py
```

Run 500 MO optimizations:
```powershell
python e4_02_run_mo_100image.py
```

The runner is resumable.

After all 500 finish:
```powershell
python e4_06_run_all_after_mo.py
```

Outputs:
`D:\48\481\New Papers\BDA_To_HHO_paper\Outputs\E4_Multiobjective_Comparison`

Key files:
- e4_analysis_report.md
- e4_decision.json
- e4_setlevel_summary.csv
- e4_representative_summary.csv
- e4_omnibus_tests.csv
- e4_pairwise_vs_mo.csv
- e4_analysis.xlsx
