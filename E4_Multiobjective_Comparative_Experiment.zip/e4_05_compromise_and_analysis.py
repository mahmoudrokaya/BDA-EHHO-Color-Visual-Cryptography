#!/usr/bin/env python3
from __future__ import annotations
import json
from pathlib import Path
import numpy as np,pandas as pd
from scipy.stats import friedmanchisquare,wilcoxon
from e4_01_common import ALGORITHMS_SO,ALGORITHM_MO,ALL_ALGORITHMS

BASE=Path(r"D:\48\481\New Papers\BDA_To_HHO_paper")
OUT=BASE/"Outputs"/"E4_Multiobjective_Comparison"; ARCH=OUT/"mo_archives_common_eval"
OBJ=["eval_f1_reconstruction","eval_f2_security","eval_f3_robustness","eval_f4_complexity"]

def holm(pvals):
    p=np.asarray(pvals,float);m=len(p);order=np.argsort(p);adj=np.empty(m);run=0.0
    for rank,idx in enumerate(order):
        v=(m-rank)*p[idx];run=max(run,v);adj[idx]=min(run,1.0)
    return adj

def rb(x,y):
    d=np.asarray(x,float)-np.asarray(y,float);d=d[np.abs(d)>1e-15]
    if len(d)==0:return 0.0
    a=np.abs(d);order=np.argsort(a);ranks=np.empty(len(d));vals=a[order];start=0;rank0=1
    while start<len(d):
        end=start+1
        while end<len(d) and vals[end]==vals[start]:end+=1
        ranks[order[start:end]]=np.mean(np.arange(rank0,rank0+end-start));rank0+=end-start;start=end
    wp=ranks[d>0].sum();wn=ranks[d<0].sum()
    return float((wp-wn)/(wp+wn)) if wp+wn else 0.0

def compromise(F,ideal,nadir):
    Z=(F-ideal)/np.maximum(nadir-ideal,1e-12)
    return int(np.argmin(np.sqrt(np.mean(Z**2,axis=1))))

def build_reps():
    so=pd.read_csv(OUT/"e4_singleobjective_common_eval.csv");rows=[]
    for (eid,run),block in so.groupby(["experiment_id","run_index"],sort=True):
        mo=pd.read_csv(ARCH/f"{eid}_r{int(run)}_mo_archive_common_eval.csv");Fmo=mo[OBJ].to_numpy(float)
        Fso=block[OBJ].to_numpy(float);P=np.vstack([Fmo,Fso]);ideal=P.min(0);nadir=P.max(0);ci=compromise(Fmo,ideal,nadir)
        for _,r in block.iterrows():
            rec={"experiment_id":eid,"run_index":int(run),"algorithm":r["algorithm"]}
            rec.update({OBJ[j]:float(r[OBJ[j]]) for j in range(4)});rows.append(rec)
        rec={"experiment_id":eid,"run_index":int(run),"algorithm":ALGORITHM_MO}
        rec.update({OBJ[j]:float(Fmo[ci,j]) for j in range(4)});rows.append(rec)
    df=pd.DataFrame(rows);df.to_csv(OUT/"e4_representative_solutions.csv",index=False,encoding="utf-8-sig");return df

def image_median(df,col):
    x=df.groupby(["experiment_id","algorithm"])[col].median().reset_index()
    return x.pivot(index="experiment_id",columns="algorithm",values=col)

def analyze(df,metric,higher=False):
    piv=image_median(df,metric)
    arr=[piv[a].to_numpy() for a in ALL_ALGORITHMS]
    fr=friedmanchisquare(*arr);mo=piv[ALGORITHM_MO].to_numpy();pairs=[];ps=[]
    for alg in ALGORITHMS_SO:
        x=piv[alg].to_numpy();w=wilcoxon(x,mo,zero_method="pratt",alternative="two-sided",method="auto");d=x-mo
        wins_mo=int(np.sum(mo>x)) if higher else int(np.sum(mo<x))
        wins_a=int(np.sum(x>mo)) if higher else int(np.sum(x<mo))
        ties=int(np.sum(np.abs(d)<=1e-12))
        pairs.append({"metric":metric,"algorithm_A":alg,"algorithm_B":ALGORITHM_MO,
                      "median_difference_A_minus_MO":float(np.median(d)),
                      "wilcoxon_statistic":float(w.statistic),"p_raw":float(w.pvalue),
                      "rank_biserial_A_minus_MO":rb(x,mo),"wins_MO":wins_mo,"wins_A":wins_a,"ties":ties})
        ps.append(float(w.pvalue))
    adj=holm(ps)
    for r,p in zip(pairs,adj):
        r["p_holm"]=float(p);r["significant_holm_0_05"]=bool(p<.05)
    return {"metric":metric,"friedman_statistic":float(fr.statistic),"friedman_p":float(fr.pvalue)},pairs

def main():
    metrics=pd.read_csv(OUT/"e4_pareto_metrics.csv");reps=build_reps();omni=[];pairs=[]
    for m,h in [("hypervolume",True),("igd",False),("epsilon_additive",False)]:
        o,p=analyze(metrics,m,h);omni.append(o);pairs.extend(p)
    for m in OBJ:
        o,p=analyze(reps,m,False);omni.append(o);pairs.extend(p)
    omni=pd.DataFrame(omni);pairdf=pd.DataFrame(pairs)
    omni.to_csv(OUT/"e4_omnibus_tests.csv",index=False,encoding="utf-8-sig")
    pairdf.to_csv(OUT/"e4_pairwise_vs_mo.csv",index=False,encoding="utf-8-sig")

    ss=(metrics.groupby("algorithm").agg(runs=("hypervolume","size"),median_hv=("hypervolume","median"),
        mean_hv=("hypervolume","mean"),median_igd=("igd","median"),mean_igd=("igd","mean"),
        median_epsilon=("epsilon_additive","median"),mean_epsilon=("epsilon_additive","mean"),
        median_set_size=("set_size","median"),mean_set_size=("set_size","mean")).reset_index())
    rs=(reps.groupby("algorithm").agg(runs=("eval_f1_reconstruction","size"),median_f1=("eval_f1_reconstruction","median"),
        median_f2=("eval_f2_security","median"),median_f3=("eval_f3_robustness","median"),
        median_f4=("eval_f4_complexity","median")).reset_index())
    ss.to_csv(OUT/"e4_setlevel_summary.csv",index=False,encoding="utf-8-sig")
    rs.to_csv(OUT/"e4_representative_summary.csv",index=False,encoding="utf-8-sig")

    hv_mo=float(ss.loc[ss.algorithm==ALGORITHM_MO,"median_hv"].iloc[0])
    best_so_hv=float(ss[ss.algorithm.isin(ALGORITHMS_SO)]["median_hv"].max())
    igd_mo=float(ss.loc[ss.algorithm==ALGORITHM_MO,"median_igd"].iloc[0])
    best_so_igd=float(ss[ss.algorithm.isin(ALGORITHMS_SO)]["median_igd"].min())
    decision={"experiment":"E4 multi-objective effect","comparison_unit":"100 images; 5 runs summarized by image median",
              "mo_median_hypervolume":hv_mo,"best_singleobjective_median_hypervolume":best_so_hv,
              "mo_median_igd":igd_mo,"best_singleobjective_median_igd":best_so_igd,
              "note":"Interpret E4 primarily from set-level HV/IGD/epsilon, not from forcing one compromise point to win every objective."}
    (OUT/"e4_decision.json").write_text(json.dumps(decision,indent=2),encoding="utf-8")
    report=["# E4 — Multi-Objective Comparative Experiment","",
        "## Design","",
        "- 100 BSDS500 validation images.",
        "- 5 runs per image.",
        "- Frozen N=30, B=600.",
        "- Four single-objective methods reused from Group 2; they were not rerun.",
        "- MO-BDA–EHHO newly executed with the frozen four-objective formulation.",
        "- All attained solutions re-evaluated under one common independent E4 evaluation realization per image/run.",
        "- Primary inferential unit: image median across five runs.","",
        "## Set-level Pareto summary","",ss.to_markdown(index=False),"",
        "## Representative-solution summary","",rs.to_markdown(index=False),"",
        "## Omnibus tests","",omni.to_markdown(index=False),"",
        "## Pairwise comparisons against MO-BDA–EHHO","",pairdf.to_markdown(index=False),"",
        "## Interpretation","",
        "The principal E4 evidence is set-level Pareto quality (hypervolume, IGD, additive epsilon). "
        "The representative compromise analysis is secondary."]
    (OUT/"e4_analysis_report.md").write_text("\n".join(report),encoding="utf-8")
    try:
        with pd.ExcelWriter(OUT/"e4_analysis.xlsx",engine="openpyxl") as w:
            ss.to_excel(w,sheet_name="Set Summary",index=False);rs.to_excel(w,sheet_name="Representative",index=False)
            omni.to_excel(w,sheet_name="Omnibus",index=False);pairdf.to_excel(w,sheet_name="Pairwise vs MO",index=False)
            metrics.to_excel(w,sheet_name="Pareto Metrics",index=False);reps.to_excel(w,sheet_name="Representative Runs",index=False)
    except Exception as e: print("Excel export skipped:",e)
    print("E4 analysis complete.");print("Report:",OUT/"e4_analysis_report.md")

if __name__=="__main__":main()
