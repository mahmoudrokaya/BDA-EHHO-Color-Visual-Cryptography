#!/usr/bin/env python3
from __future__ import annotations
import csv,time
from pathlib import Path
import numpy as np,pandas as pd
from g1_02_rgb_decomposition import load_rgb
from g3_03_mo_bda_ehho_vc import optimize_mo_bda_ehho_vc
from g3_17_multiobjective_vc_final import MultiObjectiveVCProblemFinal
from e4_01_common import POPULATION,BUDGET,RUNS_PER_IMAGE,N_IMAGES,MO_ARCHIVE_SIZE,mo_optimization_seed,bits24_to_string

BASE=Path(r"D:\48\481\New Papers\BDA_To_HHO_paper")
DATA=BASE/"Data"; MANIFEST=BASE/"Outputs"/"Manifests"/"dataset_manifest.csv"
OUT=BASE/"Outputs"/"E4_Multiobjective_Comparison"; ARCH=OUT/"mo_archives"
FIELDS=["run_key","experiment_id","filename","run_index","seed","runtime_s","evaluations","budget_compliant","archive_size",
"mean_diversity","final_diversity","injection_count","bda_proposals","ehho_proposals","bda_fraction","cache_hit_rate"]

def append_row(path,row):
    new=not path.exists()
    with path.open("a",newline="",encoding="utf-8-sig") as f:
        w=csv.DictWriter(f,fieldnames=FIELDS)
        if new:w.writeheader()
        w.writerow(row);f.flush()

def existing(path):
    return set() if not path.exists() else set(pd.read_csv(path,usecols=["run_key"])["run_key"].astype(str))

def main():
    OUT.mkdir(parents=True,exist_ok=True); ARCH.mkdir(exist_ok=True)
    m=pd.read_csv(MANIFEST)
    images=m[(m["dataset"]=="BSDS500")&(m["split"]=="validation")].copy().sort_values("experiment_id").reset_index(drop=True)
    if len(images)!=N_IMAGES: raise RuntimeError(f"Expected {N_IMAGES}, found {len(images)}")
    raw=OUT/"e4_mo_run_summary.csv"; done=existing(raw); total=N_IMAGES*RUNS_PER_IMAGE
    for _,row in images.iterrows():
        image=load_rgb(DATA/row["relative_to_data"],True)
        for run_index in range(1,RUNS_PER_IMAGE+1):
            key=f"{row['experiment_id']}|r{run_index}"
            if key in done: continue
            seed=mo_optimization_seed(row["experiment_id"],run_index)
            problem=MultiObjectiveVCProblemFinal.from_seed(image,seed)
            t0=time.perf_counter()
            result=optimize_mo_bda_ehho_vc(problem,population_size=POPULATION,max_iterations=100,
                max_evaluations=BUDGET,seed=seed,archive_size=MO_ARCHIVE_SIZE,rho_max=.70,rho_min=.30,
                diversity_threshold=.70,injection_fraction=.30)
            dt=time.perf_counter()-t0
            F=np.asarray(result.archive_objectives,float); B=np.asarray(result.archive_bits,np.uint8)
            arc=pd.DataFrame(F,columns=["opt_f1_reconstruction","opt_f2_security","opt_f3_robustness","opt_f4_complexity"])
            arc["bits"]=[bits24_to_string(x) for x in B]
            arc.to_csv(ARCH/f"{row['experiment_id']}_r{run_index}_mo_archive.csv",index=False,encoding="utf-8-sig")
            div=result.diversity_history; tot=result.bda_proposals+result.ehho_proposals
            rec={"run_key":key,"experiment_id":row["experiment_id"],"filename":row["filename"],"run_index":run_index,
                 "seed":seed,"runtime_s":dt,"evaluations":result.evaluations,"budget_compliant":result.evaluations<=BUDGET,
                 "archive_size":len(F),"mean_diversity":float(np.mean(div)) if div else np.nan,
                 "final_diversity":float(div[-1]) if div else np.nan,"injection_count":len(result.injection_iterations),
                 "bda_proposals":result.bda_proposals,"ehho_proposals":result.ehho_proposals,
                 "bda_fraction":result.bda_proposals/tot if tot else np.nan,
                 "cache_hit_rate":problem.cache_stats()["tuple_cache_hit_rate"]}
            append_row(raw,rec); done.add(key)
            print(f"[{len(done)}/{total}] {row['experiment_id']} r{run_index}: archive={len(F)}, BDA={rec['bda_fraction']:.3f}, {dt:.2f}s")
    print("E4 MO runs complete:",raw)

if __name__=="__main__": main()
