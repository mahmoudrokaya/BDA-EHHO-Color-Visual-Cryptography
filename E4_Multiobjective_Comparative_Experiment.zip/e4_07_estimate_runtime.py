from pathlib import Path
import pandas as pd
BASE=Path(r"D:\48\481\New Papers\BDA_To_HHO_paper")
P=BASE/"Outputs"/"Group3_Final_Objective_Validation"/"final_validation_raw.csv"
sec=float(pd.read_csv(P)["runtime_s"].median()) if P.exists() else 130.0
runs=500
print(f"Anchor median seconds/run: {sec:.2f}")
print(f"MO runs required: {runs}")
print(f"Approx serial runtime: {runs*sec/3600:.2f} hours")
print("Runner is resumable.")
