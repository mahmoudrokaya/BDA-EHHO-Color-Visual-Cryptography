#!/usr/bin/env python3
from __future__ import annotations
import hashlib, numpy as np

ALGORITHMS_SO=["HHO-VC","EHHO-VC","BEHHO-VC-Calibrated","BDA-EHHO-VC-Calibrated"]
ALGORITHM_MO="MO-BDA-EHHO-VC"
ALL_ALGORITHMS=ALGORITHMS_SO+[ALGORITHM_MO]
OBJECTIVE_NAMES=["f1_reconstruction","f2_security","f3_robustness","f4_complexity"]
POPULATION=30; BUDGET=600; RUNS_PER_IMAGE=5; N_IMAGES=100; MO_ARCHIVE_SIZE=100
OPT_BASE_SEED=20260913; EVAL_BASE_SEED=20260913

def stable_seed(*parts):
    d=hashlib.sha256("|".join(map(str,parts)).encode()).digest()
    return int.from_bytes(d[:4],"little") & 0x7fffffff

def mo_optimization_seed(experiment_id,run_index):
    return stable_seed(OPT_BASE_SEED,experiment_id,run_index,"E4_MO_OPT")

def e4_evaluation_seed(experiment_id,run_index):
    return stable_seed(EVAL_BASE_SEED,experiment_id,run_index,"E4_COMMON_EVAL")

def bits24_to_string(bits):
    return "".join(map(str,np.asarray(bits,dtype=int).ravel().tolist()))

def string_to_bits24(s):
    s=str(s).strip()
    if len(s)!=24 or (set(s)-{"0","1"}): raise ValueError(f"Invalid 24-bit string: {s!r}")
    return np.asarray([int(x) for x in s],dtype=np.uint8)
