#!/usr/bin/env python3
import subprocess,sys
for s in ["e4_03_common_reevaluation.py","e4_04_pareto_metrics.py","e4_05_compromise_and_analysis.py"]:
    print("="*78);print("RUNNING",s);print("="*78)
    r=subprocess.run([sys.executable,s])
    if r.returncode!=0: raise SystemExit(f"{s} failed with return code {r.returncode}")
print("="*78);print("E4 POST-OPTIMIZATION PIPELINE: COMPLETE");print("="*78)
