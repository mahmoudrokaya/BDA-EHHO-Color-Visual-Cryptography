#!/usr/bin/env python3
from __future__ import annotations
from pathlib import Path
import numpy as np,pandas as pd
from g1_02_rgb_decomposition import load_rgb
from g3_02_pareto_archive import nondominated_mask
from g3_17_multiobjective_vc_final import MultiObjectiveVCProblemFinal
from e4_01_common import ALGORITHMS_SO,RUNS_PER_IMAGE,N_IMAGES,e4_evaluation_seed,string_to_bits24

BASE=Path(r"D:\48\481\New Papers\BDA_To_HHO_paper")
DATA=BASE/"Data"; MANIFEST=BASE/"Outputs"/"Manifests"/"dataset_manifest.csv"
G2=BASE/"Outputs"/"Group2_100Image_Confirmation"/"confirmation_raw_results.csv"
OUT=BASE/"Outputs"/"E4_Multiobjective_Comparison"
ARCH_IN=OUT/"mo_archives"; ARCH_EVAL=OUT/"mo_archives_common_eval"

def main():
    OUT.mkdir(parents=True,exist_ok=True); ARCH_EVAL.mkdir(exist_ok=True)
    g2=pd.read_csv(G2); g2=g2[g2["algorithm"].isin(ALGORITHMS_SO)].copy()
    expected=N_IMAGES*RUNS_PER_IMAGE*len(ALGORITHMS_SO)
    if len(g2)!=expected: raise RuntimeError(f"Expected {expected} Group2 rows, found {len(g2)}.")
    man=pd.read_csv(MANIFEST); path_map=dict(zip(man["experiment_id"],man["relative_to_data"]))
    so_rows=[]
    for (experiment_id,run_index),block in g2.groupby(["experiment_id","run_index"],sort=True):
        image=load_rgb(DATA/path_map[experiment_id],True)
        problem=MultiObjectiveVCProblemFinal.from_seed(image,e4_evaluation_seed(experiment_id,int(run_index)))
        for _,r in block.iterrows():
            levels=(int(r["level_R"]),int(r["level_G"]),int(r["level_B"]))
            F,_=problem.evaluate_levels(levels)
            so_rows.append({"experiment_id":experiment_id,"filename":r["filename"],"run_index":int(run_index),"algorithm":r["algorithm"],
                "level_R":levels[0],"level_G":levels[1],"level_B":levels[2],
                "eval_f1_reconstruction":float(F[0]),"eval_f2_security":float(F[1]),
                "eval_f3_robustness":float(F[2]),"eval_f4_complexity":float(F[3])})
        p=ARCH_IN/f"{experiment_id}_r{int(run_index)}_mo_archive.csv"
        if not p.exists(): raise FileNotFoundError(p)
        arc=pd.read_csv(p,dtype={"bits":"string"},keep_default_na=False)
        F_eval=[]; bits=[]
        for s in arc["bits"].astype(str):
            F,_=problem.evaluate_bits24(string_to_bits24(s))
            F_eval.append(F); bits.append(s)
        F_eval=np.asarray(F_eval,float); keep=nondominated_mask(F_eval)
        F_nd=F_eval[keep]; bits_nd=[b for b,k in zip(bits,keep) if k]
        out=pd.DataFrame(F_nd,columns=["eval_f1_reconstruction","eval_f2_security","eval_f3_robustness","eval_f4_complexity"])
        out["bits"]=bits_nd
        out.to_csv(ARCH_EVAL/f"{experiment_id}_r{int(run_index)}_mo_archive_common_eval.csv",index=False,encoding="utf-8-sig")
        print(experiment_id,"run",int(run_index),"MO",len(arc),"-> ND",len(F_nd))
    pd.DataFrame(so_rows).to_csv(OUT/"e4_singleobjective_common_eval.csv",index=False,encoding="utf-8-sig")
    print("Common reevaluation complete.")

if __name__=="__main__": main()
