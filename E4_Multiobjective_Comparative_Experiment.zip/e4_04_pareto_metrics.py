#!/usr/bin/env python3
from __future__ import annotations
from pathlib import Path
import numpy as np,pandas as pd
from g3_02_pareto_archive import nondominated_mask
from e4_01_common import ALGORITHMS_SO,ALGORITHM_MO

BASE=Path(r"D:\48\481\New Papers\BDA_To_HHO_paper")
OUT=BASE/"Outputs"/"E4_Multiobjective_Comparison"; ARCH=OUT/"mo_archives_common_eval"
COLS=["eval_f1_reconstruction","eval_f2_security","eval_f3_robustness","eval_f4_complexity"]

def nondominated(F):
    F=np.asarray(F,float)
    return F[nondominated_mask(F)]

def normalize(F,ideal,nadir):
    return (np.asarray(F,float)-ideal)/np.maximum(nadir-ideal,1e-12)

def hv_recursive(points,ref):
    P=np.asarray(points,float); ref=np.asarray(ref,float)
    if len(P)==0:return 0.0
    P=P[np.all(P<ref+1e-15,axis=1)]
    if len(P)==0:return 0.0
    P=nondominated(P); d=P.shape[1]
    if d==1:return float(max(0.0,ref[0]-np.min(P[:,0])))
    xs=np.unique(P[:,0]); hv=0.0; prev=ref[0]
    for x in xs[::-1]:
        width=prev-x
        if width>0:
            hv+=width*hv_recursive(P[P[:,0]<=x,1:],ref[1:]); prev=x
    return float(hv)

def igd(A,R):
    A=np.asarray(A,float);R=np.asarray(R,float)
    return float(np.mean([np.min(np.linalg.norm(A-r,axis=1)) for r in R]))

def eps_add(A,R):
    A=np.asarray(A,float);R=np.asarray(R,float)
    return float(np.max([np.min(np.max(A-r,axis=1)) for r in R]))

def mean_nn(F):
    F=np.asarray(F,float)
    if len(F)<=1:return 0.0
    D=np.linalg.norm(F[:,None,:]-F[None,:,:],axis=2);np.fill_diagonal(D,np.inf)
    return float(np.mean(np.min(D,axis=1)))

def main():
    so=pd.read_csv(OUT/"e4_singleobjective_common_eval.csv"); rows=[]
    for (experiment_id,run_index),block in so.groupby(["experiment_id","run_index"],sort=True):
        mo=pd.read_csv(ARCH/f"{experiment_id}_r{int(run_index)}_mo_archive_common_eval.csv")
        Fmo=mo[COLS].to_numpy(float); pooled=[Fmo]; single={}
        for alg in ALGORITHMS_SO:
            r=block[block["algorithm"]==alg]
            if len(r)!=1: raise RuntimeError(f"{experiment_id} r{run_index} {alg}: {len(r)} rows")
            f=r[COLS].to_numpy(float); single[alg]=f; pooled.append(f)
        P=np.vstack(pooled);ideal=P.min(0);nadir=P.max(0)
        ref=nondominated(normalize(P,ideal,nadir)); rp=np.full(4,1.10)
        methods={a:normalize(f,ideal,nadir) for a,f in single.items()}
        methods[ALGORITHM_MO]=normalize(Fmo,ideal,nadir)
        for alg,F in methods.items():
            Fnd=nondominated(F)
            rows.append({"experiment_id":experiment_id,"run_index":int(run_index),"algorithm":alg,"set_size":len(Fnd),
                "hypervolume":hv_recursive(Fnd,rp),"igd":igd(Fnd,ref),"epsilon_additive":eps_add(Fnd,ref),
                "mean_nn_distance":mean_nn(Fnd),"reference_front_size":len(ref)})
        print(experiment_id,"run",int(run_index),"reference",len(ref),"MO",len(Fmo))
    pd.DataFrame(rows).to_csv(OUT/"e4_pareto_metrics.csv",index=False,encoding="utf-8-sig")
    print("Pareto metrics complete.")

if __name__=="__main__": main()
