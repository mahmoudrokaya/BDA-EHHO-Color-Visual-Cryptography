#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Extract representative candidate solutions from existing Group-3 Pareto archives.

No optimizer rerun is required.

For each archive:
- include every archive solution if archive size <= 40;
- otherwise sample 40 points evenly across sorted complexity;
- always include objective-wise extremes;
- always include the equal-weight normalized compromise candidate.

Output:
candidate_index.csv
"""

from __future__ import annotations
from pathlib import Path
import numpy as np
import pandas as pd

BASE = Path(r"D:\48\481\New Papers\BDA_To_HHO_paper")
ARCH = BASE / "Outputs" / "Group3_MO_Validation" / "archives"
OUT = BASE / "Outputs" / "Group3_Objective_Validation"
MAX_PER_ARCHIVE = 40


def decode_bits(bits):
    b = [int(x) for x in str(bits).strip()]
    if len(b) != 24:
        raise ValueError("Expected 24-bit string.")
    vals = []
    for start in (0, 8, 16):
        v = 0
        for bit in b[start:start+8]:
            v = (v << 1) | bit
        vals.append(max(2, min(255, v)))
    return vals


def compromise_idx(F):
    ideal = F.min(axis=0)
    nadir = F.max(axis=0)
    Z = (F - ideal) / np.maximum(nadir - ideal, 1e-12)
    d = np.sqrt(np.mean(Z**2, axis=1))
    return int(np.argmin(d))


def select_indices(df):
    n = len(df)
    F = df[
        ["f_reconstruction", "f_security", "f_robustness", "f_complexity"]
    ].to_numpy(float)

    ids = set()

    # objective extremes
    for j in range(F.shape[1]):
        ids.add(int(np.argmin(F[:, j])))
        ids.add(int(np.argmax(F[:, j])))

    # compromise
    ids.add(compromise_idx(F))

    if n <= MAX_PER_ARCHIVE:
        ids.update(range(n))
    else:
        order = np.argsort(F[:, 3], kind="mergesort")
        pos = np.linspace(0, n - 1, MAX_PER_ARCHIVE).round().astype(int)
        ids.update(order[pos].tolist())

    return sorted(ids)


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    rows = []

    files = sorted(ARCH.glob("*_archive.csv"))
    if not files:
        raise FileNotFoundError(f"No archive CSVs found in {ARCH}")

    for p in files:
        df = pd.read_csv(p)
        ids = select_indices(df)

        stem = p.stem.replace("_archive", "")
        experiment_id, run_token = stem.rsplit("_r", 1)
        run_index = int(run_token)

        for idx in ids:
            r = df.iloc[idx]
            levels = decode_bits(r["bits"])
            rows.append({
                "experiment_id": experiment_id,
                "run_index": run_index,
                "archive_file": p.name,
                "archive_row": idx,
                "bits": str(r["bits"]),
                "level_R": levels[0],
                "level_G": levels[1],
                "level_B": levels[2],
                "old_f1_reconstruction": r["f_reconstruction"],
                "old_f2_security": r["f_security"],
                "old_f3_robustness": r["f_robustness"],
                "old_f4_complexity": r["f_complexity"],
            })

    out = pd.DataFrame(rows)
    out.to_csv(
        OUT / "candidate_index.csv",
        index=False,
        encoding="utf-8-sig",
    )

    print("Archives:", len(files))
    print("Selected candidates:", len(out))
    print("Output:", OUT / "candidate_index.csv")


if __name__ == "__main__":
    main()
