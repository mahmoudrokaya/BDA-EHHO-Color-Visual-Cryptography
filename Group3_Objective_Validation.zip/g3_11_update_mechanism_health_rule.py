#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Re-evaluate Group-3 diversity health using the correct conditional rule:

Healthy if either:
A) final diversity remains >= trigger, or
B) injection occurs when diversity falls below trigger.

This does not modify optimizer output.
"""

from pathlib import Path
import json
import numpy as np
import pandas as pd

BASE = Path(r"D:\48\481\New Papers\BDA_To_HHO_paper")
SRC = BASE / "Outputs" / "Group3_MO_Validation" / "mo_validation_raw.csv"
OUT = BASE / "Outputs" / "Group3_Objective_Validation"
TRIGGER = 0.70


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    df = pd.read_csv(SRC)

    df["diversity_healthy"] = (
        (df["final_diversity"] >= TRIGGER)
        | (df["injection_count"] > 0)
    )

    pct = float(100 * df["diversity_healthy"].mean())
    min_final = float(df["final_diversity"].min())
    mean_final = float(df["final_diversity"].mean())

    result = {
        "trigger": TRIGGER,
        "healthy_runs_pct": pct,
        "minimum_final_diversity": min_final,
        "mean_final_diversity": mean_final,
        "injection_active_runs_pct": float(
            100 * np.mean(df["injection_count"] > 0)
        ),
        "mechanism_health_pass": bool(pct == 100.0),
        "interpretation": (
            "Zero injections are not a failure if diversity never falls below "
            "the trigger threshold."
        ),
    }

    (OUT / "diversity_health_reassessment.json").write_text(
        json.dumps(result, indent=2),
        encoding="utf-8",
    )

    df[
        [
            "experiment_id",
            "run_index",
            "mean_diversity",
            "final_diversity",
            "injection_count",
            "diversity_healthy",
        ]
    ].to_csv(
        OUT / "diversity_health_reassessment.csv",
        index=False,
        encoding="utf-8-sig",
    )

    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
