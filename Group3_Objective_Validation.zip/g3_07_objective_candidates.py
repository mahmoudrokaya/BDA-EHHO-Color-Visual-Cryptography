#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Group 3 Objective Validation / Code 07

Candidate definitions for validating the multi-objective formulation BEFORE E4.

This suite does not tune the optimizer. It audits whether candidate objective
definitions are informative, stable, and conceptually appropriate.

Robustness candidates
---------------------
R1: rec-vs-perturbed MSE
    MSE(I_rec_clean, I_rec_perturbed) / 255^2

R2: rec-vs-perturbed MAE
    MAE(I_rec_clean, I_rec_perturbed) / 255

R3: original-relative absolute error under perturbation
    MSE(I_secret, I_rec_perturbed) / 255^2

R4: symmetric degradation ratio
    |MSE(secret, perturbed) - MSE(secret, clean)| / 255^2

Security candidates
-------------------
S1: current bounded formulation
    0.5*(1-NMSE(secret, share)) + 0.5*|CC(secret, share)|

S2: |CC| only

S3: similarity-to-secret by SSIM-like normalized contrast surrogate
    Here we deliberately avoid external skimage dependence and instead use:
        0.5*(1-NMSE) + 0.25*|CC| + 0.25*histogram-overlap

S4: worst-share current formulation
    max over the two shares of mean channel security score

All are minimized.

Important:
This is an audit suite. No optimizer parameters are changed.
"""

from __future__ import annotations
import numpy as np

MAX_MSE = 255.0 ** 2


def mse(a, b):
    x = np.asarray(a, dtype=np.float64)
    y = np.asarray(b, dtype=np.float64)
    return float(np.mean((x - y) ** 2))


def mae(a, b):
    x = np.asarray(a, dtype=np.float64)
    y = np.asarray(b, dtype=np.float64)
    return float(np.mean(np.abs(x - y)))


def pearson(a, b):
    x = np.asarray(a, dtype=np.float64).ravel()
    y = np.asarray(b, dtype=np.float64).ravel()
    sx, sy = x.std(), y.std()
    if sx <= 1e-15 or sy <= 1e-15:
        return 0.0
    return float(np.corrcoef(x, y)[0, 1])


def histogram_overlap(a, b, bins=32):
    ha, _ = np.histogram(a, bins=bins, range=(0, 256), density=False)
    hb, _ = np.histogram(b, bins=bins, range=(0, 256), density=False)
    ha = ha.astype(float)
    hb = hb.astype(float)
    if ha.sum() == 0 or hb.sum() == 0:
        return 0.0
    ha /= ha.sum()
    hb /= hb.sum()
    return float(np.minimum(ha, hb).sum())


def security_scores(secret, share1, share2):
    """
    Return S1-S4, all minimized.
    """
    share_scores = []
    cc_only = []
    rich_scores = []

    for share in (share1, share2):
        per_channel = []
        cc_ch = []
        rich_ch = []

        for ch in range(3):
            sec = secret[..., ch]
            sh = share[..., ch]

            nmse = min(max(mse(sec, sh) / MAX_MSE, 0.0), 1.0)
            cc = min(max(abs(pearson(sec, sh)), 0.0), 1.0)
            hov = min(max(histogram_overlap(sec, sh), 0.0), 1.0)

            base = 0.5 * (1.0 - nmse) + 0.5 * cc
            rich = 0.5 * (1.0 - nmse) + 0.25 * cc + 0.25 * hov

            per_channel.append(base)
            cc_ch.append(cc)
            rich_ch.append(rich)

        share_scores.append(float(np.mean(per_channel)))
        cc_only.append(float(np.mean(cc_ch)))
        rich_scores.append(float(np.mean(rich_ch)))

    return {
        "S1_current_mean": float(np.mean(share_scores)),
        "S2_abs_cc_only": float(np.mean(cc_only)),
        "S3_nmse_cc_hist": float(np.mean(rich_scores)),
        "S4_worst_share": float(np.max(share_scores)),
    }


def robustness_scores(secret, clean_rec, perturbed_recs):
    """
    perturbed_recs: dict[label -> reconstructed image]
    Return rate-specific and averaged variants.
    """
    clean_secret_mse = mse(secret, clean_rec)

    rows = {}
    r1, r2, r3, r4 = [], [], [], []

    for label, noisy in perturbed_recs.items():
        v1 = mse(clean_rec, noisy) / MAX_MSE
        v2 = mae(clean_rec, noisy) / 255.0
        noisy_secret_mse = mse(secret, noisy)
        v3 = noisy_secret_mse / MAX_MSE
        v4 = abs(noisy_secret_mse - clean_secret_mse) / MAX_MSE

        rows[f"R1_clean_vs_noisy_mse_{label}"] = float(v1)
        rows[f"R2_clean_vs_noisy_mae_{label}"] = float(v2)
        rows[f"R3_secret_vs_noisy_mse_{label}"] = float(v3)
        rows[f"R4_abs_delta_secret_mse_{label}"] = float(v4)

        r1.append(v1)
        r2.append(v2)
        r3.append(v3)
        r4.append(v4)

    rows.update({
        "R1_clean_vs_noisy_mse_mean": float(np.mean(r1)),
        "R2_clean_vs_noisy_mae_mean": float(np.mean(r2)),
        "R3_secret_vs_noisy_mse_mean": float(np.mean(r3)),
        "R4_abs_delta_secret_mse_mean": float(np.mean(r4)),
    })
    return rows
