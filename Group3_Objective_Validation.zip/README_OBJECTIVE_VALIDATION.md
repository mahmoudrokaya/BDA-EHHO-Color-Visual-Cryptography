# Group3_Objective_Validation

Compact audit suite for fixing the multi-objective definitions before E4.

## Why this stage is needed

The first Group-3 validation passed:
- run completion;
- budget compliance;
- nonempty Pareto archives;
- archive nondominance;
- BDA/EHHO balance.

But:
- the original robustness objective collapsed to zero;
- the security objective had a very narrow range;
- zero diversity injections were incorrectly treated as mechanism failure even
  though diversity remained above threshold.

## Important scientific constraint

**This suite does not rerun or retune the optimizer.**

It evaluates alternative objective definitions using solutions already generated
in the existing Pareto archives.

## Candidate robustness definitions

- R1: MSE(clean reconstruction, perturbed reconstruction) / 255²
- R2: MAE(clean reconstruction, perturbed reconstruction) / 255
- R3: MSE(secret, perturbed reconstruction) / 255²
- R4: absolute change in secret-relative reconstruction MSE / 255²

Perturbation rates:
- 1%
- 5%
- 10%

## Candidate security definitions

- S1: current mean bounded NMSE + |CC|
- S2: |CC| only
- S3: NMSE + |CC| + histogram-overlap
- S4: worst-share version of S1

## Files

- g3_07_objective_candidates.py
- g3_08_extract_archive_candidates.py
- g3_09_recompute_candidate_objectives.py
- g3_10_analyze_objective_discrimination.py
- g3_11_update_mechanism_health_rule.py
- g3_12_run_objective_validation_all.py

## Installation

Copy these files into:

`D:\48\481\New Papers\BDA_To_HHO_paper\Codes\Group3_MO_BDA_EHHO`

Group 1 must remain importable.

## Run

You can execute everything with:

```powershell
python g3_12_run_objective_validation_all.py
```

or run the steps individually in order.

## Output

`D:\48\481\New Papers\BDA_To_HHO_paper\Outputs\Group3_Objective_Validation`

Important outputs:

- objective_validation_report.md
- objective_validation_decision.json
- objective_candidate_statistics.csv
- objective_spearman_correlations.csv
- objective_validation.xlsx
- diversity_health_reassessment.json
- objective_recomputed_candidates.csv

## Decision rule

Do not automatically choose an objective solely because its numeric
discrimination score is highest. The final choice must satisfy both:

1. good discrimination among candidate solutions;
2. conceptual validity for the VC property being measured.

Once objectives are frozen, modify only the objective-definition code and rerun
the same 12-image Group-3 validation before E4.
