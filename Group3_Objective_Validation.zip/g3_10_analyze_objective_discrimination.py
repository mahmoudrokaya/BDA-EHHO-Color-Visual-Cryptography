#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Analyze candidate objective definitions without rerunning optimization.

Selection principles
--------------------
A defensible objective should:
1. not collapse to a constant;
2. vary within most image/run archives;
3. have a useful normalized dynamic range;
4. not be almost perfectly redundant with another objective;
5. be conceptually aligned with what it claims to measure.

This analyzer does not automatically optimize weights.
"""

from __future__ import annotations
import json
from pathlib import Path
import numpy as np
import pandas as pd

BASE = Path(r"D:\48\481\New Papers\BDA_To_HHO_paper")
OUT = BASE / "Outputs" / "Group3_Objective_Validation"
INPUT = OUT / "objective_recomputed_candidates.csv"

SECURITY = [
    "S1_current_mean",
    "S2_abs_cc_only",
    "S3_nmse_cc_hist",
    "S4_worst_share",
]

ROBUSTNESS = [
    "R1_clean_vs_noisy_mse_mean",
    "R2_clean_vs_noisy_mae_mean",
    "R3_secret_vs_noisy_mse_mean",
    "R4_abs_delta_secret_mse_mean",
]

REFERENCE_OBJECTIVES = [
    "old_f1_reconstruction",
    "old_f4_complexity",
]


def normalized_iqr(x):
    x = np.asarray(x, float)
    q1, q3 = np.percentile(x, [25, 75])
    lo, hi = np.min(x), np.max(x)
    return float((q3 - q1) / max(hi - lo, 1e-12))


def candidate_stats(df, col):
    vals = df[col].to_numpy(float)

    groups = []
    nonconstant = 0
    cvs = []
    spans = []

    for _, g in df.groupby(["experiment_id", "run_index"]):
        x = g[col].to_numpy(float)
        span = float(np.max(x) - np.min(x))
        groups.append(span)
        if span > 1e-12:
            nonconstant += 1
        mean_abs = abs(np.mean(x))
        cvs.append(float(np.std(x) / max(mean_abs, 1e-12)))
        spans.append(span)

    return {
        "objective_candidate": col,
        "global_min": float(np.min(vals)),
        "global_max": float(np.max(vals)),
        "global_span": float(np.max(vals) - np.min(vals)),
        "global_std": float(np.std(vals)),
        "normalized_iqr": normalized_iqr(vals),
        "pct_archives_nonconstant": float(100 * nonconstant / len(groups)),
        "median_within_archive_span": float(np.median(spans)),
        "median_within_archive_cv": float(np.median(cvs)),
    }


def spearman_matrix(df, cols):
    return df[cols].corr(method="spearman")


def score_discrimination(stats):
    """
    Mechanism-neutral screening score for ranking candidates.
    Higher = more discriminative.
    This is for audit only, not manuscript science.
    """
    return (
        0.50 * (stats["pct_archives_nonconstant"] / 100.0)
        + 0.25 * min(stats["normalized_iqr"] / 0.25, 1.0)
        + 0.25 * min(stats["median_within_archive_cv"] / 0.05, 1.0)
    )


def main():
    df = pd.read_csv(INPUT)

    rows = []
    for col in SECURITY + ROBUSTNESS:
        s = candidate_stats(df, col)
        s["family"] = "security" if col in SECURITY else "robustness"
        s["discrimination_score"] = score_discrimination(s)
        rows.append(s)

    stats = pd.DataFrame(rows)
    stats = stats.sort_values(
        ["family", "discrimination_score"],
        ascending=[True, False],
    )

    stats.to_csv(
        OUT / "objective_candidate_statistics.csv",
        index=False,
        encoding="utf-8-sig",
    )

    all_cols = REFERENCE_OBJECTIVES + SECURITY + ROBUSTNESS
    corr = spearman_matrix(df, all_cols)
    corr.to_csv(
        OUT / "objective_spearman_correlations.csv",
        encoding="utf-8-sig",
    )

    # Mechanism-independent recommendations:
    # robustness: prioritize non-collapse + discrimination
    rob = stats[stats["family"] == "robustness"].copy()
    sec = stats[stats["family"] == "security"].copy()

    rob_pick = rob.iloc[0]["objective_candidate"]
    sec_pick = sec.iloc[0]["objective_candidate"]

    # Redundancy warnings relative to reconstruction and complexity.
    warnings = []
    for col in SECURITY + ROBUSTNESS:
        for ref in REFERENCE_OBJECTIVES:
            rho = float(corr.loc[col, ref])
            if abs(rho) >= 0.95:
                warnings.append(
                    f"{col} is highly redundant with {ref} (Spearman rho={rho:.3f})."
                )

    decision = {
        "recommended_security_candidate_by_discrimination": sec_pick,
        "recommended_robustness_candidate_by_discrimination": rob_pick,
        "security_requires_human_conceptual_review": True,
        "robustness_requires_human_conceptual_review": True,
        "redundancy_warnings": warnings,
        "note": (
            "Automatic rankings are diagnostic only. Final objective definitions "
            "must be frozen based on both discrimination and conceptual validity."
        ),
    }

    (OUT / "objective_validation_decision.json").write_text(
        json.dumps(decision, indent=2),
        encoding="utf-8",
    )

    report = [
        "# Group 3 — Objective Validation",
        "",
        "## Purpose",
        "",
        "This audit evaluates alternative security and robustness objectives on "
        "candidate solutions already generated by Group 3. No optimizer is rerun "
        "and no optimizer parameter is changed.",
        "",
        "## Candidate discrimination",
        "",
        stats.to_markdown(index=False),
        "",
        "## Spearman correlations",
        "",
        corr.to_markdown(),
        "",
        "## Automatic discrimination-only ranking",
        "",
        f"- Security candidate: **{sec_pick}**",
        f"- Robustness candidate: **{rob_pick}**",
        "",
        "These are not automatically the final scientific choices. A candidate "
        "can be numerically discriminative yet conceptually inappropriate or "
        "redundant with another objective.",
        "",
        "## Redundancy warnings",
        "",
    ]

    if warnings:
        report.extend([f"- {x}" for x in warnings])
    else:
        report.append("- No |Spearman rho| >= 0.95 redundancy warning detected.")

    report += [
        "",
        "## Recommended next action",
        "",
        "Review the top security and robustness candidates conceptually. Once the "
        "definitions are frozen, update g3_01_multiobjective_vc.py and rerun only "
        "the 12-image Group-3 validation before E4.",
    ]

    (OUT / "objective_validation_report.md").write_text(
        "\n".join(report),
        encoding="utf-8",
    )

    try:
        with pd.ExcelWriter(
            OUT / "objective_validation.xlsx",
            engine="openpyxl",
        ) as w:
            stats.to_excel(w, sheet_name="Candidate Statistics", index=False)
            corr.to_excel(w, sheet_name="Correlations")
            df.to_excel(w, sheet_name="Candidates", index=False)
    except Exception as exc:
        print("Excel export skipped:", exc)

    print("Objective validation complete.")
    print("Security candidate:", sec_pick)
    print("Robustness candidate:", rob_pick)
    print("Report:", OUT / "objective_validation_report.md")


if __name__ == "__main__":
    main()
