#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Convenience runner for the compact Group3 Objective Validation suite."""

import subprocess
import sys

SCRIPTS = [
    "g3_08_extract_archive_candidates.py",
    "g3_09_recompute_candidate_objectives.py",
    "g3_10_analyze_objective_discrimination.py",
    "g3_11_update_mechanism_health_rule.py",
]

for script in SCRIPTS:
    print("=" * 78)
    print("RUNNING", script)
    print("=" * 78)
    result = subprocess.run([sys.executable, script])
    if result.returncode != 0:
        raise SystemExit(
            f"{script} failed with return code {result.returncode}"
        )

print("=" * 78)
print("GROUP 3 OBJECTIVE VALIDATION SUITE: COMPLETE")
print("=" * 78)
