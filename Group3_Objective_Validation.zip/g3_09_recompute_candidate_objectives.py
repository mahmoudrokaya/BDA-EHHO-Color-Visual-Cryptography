#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Recompute alternative security and robustness definitions for candidates
sampled from the already generated Group-3 archives.

No optimizer parameters are changed and no optimization is rerun.

Robustness perturbations:
- deterministic binary flip masks at 1%, 5%, 10%
- both shares corrupted independently
- same masks reused for every candidate within an image/run

This makes the objective discrimination audit paired and reproducible.
"""

from __future__ import annotations
import hashlib
from pathlib import Path
import numpy as np
import pandas as pd

from g1_02_rgb_decomposition import load_rgb
from g1_03_vc_share_generation import generate_rgb_shares
from g1_04_vc_reconstruction import xor_reconstruct
from g3_07_objective_candidates import security_scores, robustness_scores

BASE = Path(r"D:\48\481\New Papers\BDA_To_HHO_paper")
DATA = BASE / "Data"
MANIFEST = BASE / "Outputs" / "Manifests" / "dataset_manifest.csv"
INPUT = BASE / "Outputs" / "Group3_Objective_Validation" / "candidate_index.csv"
OUT = BASE / "Outputs" / "Group3_Objective_Validation"

RATES = (0.01, 0.05, 0.10)
BASE_SEED = 20260913


def stable_seed(*parts):
    d = hashlib.sha256("|".join(map(str, parts)).encode()).digest()
    return int.from_bytes(d[:4], "little") & 0x7fffffff


def main():
    candidates = pd.read_csv(INPUT)
    manifest = pd.read_csv(MANIFEST)
    path_map = dict(zip(manifest["experiment_id"], manifest["relative_to_data"]))

    rows = []

    grouped = candidates.groupby(["experiment_id", "run_index"], sort=False)

    for (experiment_id, run_index), group in grouped:
        image = load_rgb(DATA / path_map[experiment_id], True)

        # Same share-generation random fields as a deterministic audit realization.
        seed = stable_seed(BASE_SEED, experiment_id, run_index, "OBJ_AUDIT")
        ss = np.random.SeedSequence(seed)
        children = ss.spawn(3 + 2 * len(RATES))

        random_fields = tuple(
            np.random.default_rng(children[i]).random(image.shape[:2])
            for i in range(3)
        )

        masks = {}
        base = 3
        for ridx, rate in enumerate(RATES):
            for share_idx in (0, 1):
                rng = np.random.default_rng(children[base + 2*ridx + share_idx])
                masks[(rate, share_idx)] = rng.random(image.shape) < rate

        for _, r in group.iterrows():
            levels = (
                int(r["level_R"]),
                int(r["level_G"]),
                int(r["level_B"]),
            )

            share1, share2, _ = generate_rgb_shares(
                image,
                levels,
                random_fields=random_fields,
            )
            clean = xor_reconstruct(share1, share2)

            noisy_recs = {}
            for rate in RATES:
                a = share1.copy()
                b = share2.copy()
                a[masks[(rate, 0)]] = 255 - a[masks[(rate, 0)]]
                b[masks[(rate, 1)]] = 255 - b[masks[(rate, 1)]]
                noisy_recs[f"{int(rate*100)}pct"] = xor_reconstruct(a, b)

            sec = security_scores(image, share1, share2)
            rob = robustness_scores(image, clean, noisy_recs)

            row = dict(r)
            row.update(sec)
            row.update(rob)
            rows.append(row)

        print(experiment_id, "run", run_index, "candidates", len(group))

    out = pd.DataFrame(rows)
    out.to_csv(
        OUT / "objective_recomputed_candidates.csv",
        index=False,
        encoding="utf-8-sig",
    )

    print("Output:", OUT / "objective_recomputed_candidates.csv")


if __name__ == "__main__":
    main()
