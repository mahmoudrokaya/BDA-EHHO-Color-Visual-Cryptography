#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from __future__ import annotations
import argparse, json, math, time
from pathlib import Path
from typing import Any
import numpy as np
import pandas as pd
from PIL import Image, ImageDraw

from g1_02_rgb_decomposition import load_rgb
from g1_04_vc_reconstruction import xor_reconstruct
from g1_06_vc_baseline_fitness import mse, psnr, pearson_cc
from g1_07_bda_reference import optimize_rgb_levels_bda

BASE_DIR = Path(r"D:\48\481\New Papers\BDA_To_HHO_paper")
DATA_DIR = BASE_DIR / "Data"
MANIFEST = BASE_DIR / "Outputs" / "Manifests" / "dataset_manifest.csv"
OUTPUT_DIR = BASE_DIR / "Outputs" / "Group1_BDA_Validation"
PER_IMAGE_DIR = OUTPUT_DIR / "per_image"


def safe_name(text: str) -> str:
    return ''.join(ch if ch.isalnum() or ch in '-_' else '_' for ch in text)[:100]


def is_binary_share(arr: np.ndarray) -> bool:
    return bool(np.all(np.isin(np.unique(arr), [0, 255])))


def monotonic_nonincreasing(values, atol=1e-12) -> bool:
    if len(values) <= 1:
        return True
    return bool(np.all(np.diff(np.asarray(values, float)) <= atol))


def image_metrics(reference, candidate):
    return {
        'mse': float(mse(reference, candidate)),
        'psnr': float(psnr(reference, candidate)),
        'cc': float(pearson_cc(reference, candidate)),
    }


def channel_share_metrics(secret_rgb, share_rgb, prefix):
    out = {}
    for i, ch in enumerate(('R','G','B')):
        out[f'{prefix}_{ch}_psnr'] = float(psnr(secret_rgb[..., i], share_rgb[..., i]))
        out[f'{prefix}_{ch}_cc'] = float(pearson_cc(secret_rgb[..., i], share_rgb[..., i]))
    out[f'{prefix}_mean_psnr'] = float(np.mean([out[f'{prefix}_{c}_psnr'] for c in ('R','G','B')]))
    out[f'{prefix}_mean_abs_cc'] = float(np.mean([abs(out[f'{prefix}_{c}_cc']) for c in ('R','G','B')]))
    return out


def pick_two(df, seed):
    if len(df) <= 2:
        return df.copy()
    return df.sample(n=2, random_state=seed).sort_values('experiment_id')


def select_validation_images(manifest, selection_seed):
    bsds_val = manifest[(manifest['dataset']=='BSDS500') & (manifest['split']=='validation')]
    bsds_test = manifest[(manifest['dataset']=='BSDS500') & (manifest['split']=='test')]
    sipi = manifest[manifest['dataset']=='USC-SIPI Miscellaneous']
    selected = pd.concat([
        pick_two(bsds_val, selection_seed+11),
        pick_two(bsds_test, selection_seed+23),
        pick_two(sipi, selection_seed+37),
    ], ignore_index=True)
    if selected.empty:
        raise RuntimeError('No images selected from manifest.')
    return selected


def fit_image(im, max_size=(360,300)):
    x = im.copy(); x.thumbnail(max_size, Image.Resampling.LANCZOS); return x


def labeled(im, label, width=380, height=340):
    canvas = Image.new('RGB',(width,height),'white')
    pic = fit_image(im,(width-20,height-50))
    x = (width-pic.width)//2; y = 35 + (height-45-pic.height)//2
    canvas.paste(pic,(x,y)); ImageDraw.Draw(canvas).text((10,10),label,fill='black')
    return canvas


def save_panel(original, share1, share2, rec, path):
    ims=[labeled(Image.fromarray(original),'Original'),labeled(Image.fromarray(share1),'Share 1'),labeled(Image.fromarray(share2),'Share 2'),labeled(Image.fromarray(rec),'XOR Reconstruction')]
    panel=Image.new('RGB',(ims[0].width*2,ims[0].height*2),'white')
    panel.paste(ims[0],(0,0)); panel.paste(ims[1],(ims[0].width,0)); panel.paste(ims[2],(0,ims[0].height)); panel.paste(ims[3],(ims[0].width,ims[0].height))
    panel.save(path)


def save_run(image_dir, original, result, label='primary'):
    d = image_dir if label=='primary' else image_dir/label
    d.mkdir(parents=True, exist_ok=True)
    Image.fromarray(original).save(d/'original.png')
    Image.fromarray(result['share1']).save(d/'share1.png')
    Image.fromarray(result['share2']).save(d/'share2.png')
    Image.fromarray(result['recovered']).save(d/'reconstructed.png')
    save_panel(original,result['share1'],result['share2'],result['recovered'],d/'comparison_panel.png')
    serial={k:v for k,v in result.items() if k not in {'share1','share2','recovered'}}
    (d/'bda_result.json').write_text(json.dumps(serial,indent=2),encoding='utf-8')
    for ch in ('R','G','B'):
        conv=result['channel_results'][ch]['convergence']
        pd.DataFrame({'iteration':range(1,len(conv)+1),'best_so_far_fitness':conv}).to_csv(d/f'convergence_{ch}.csv',index=False)


def timed_run(image,population,iterations,seed,budget):
    t0=time.perf_counter()
    result=optimize_rgb_levels_bda(image,population_size=population,max_iterations=iterations,seed=seed,max_evaluations_per_channel=budget)
    return result, time.perf_counter()-t0


def validate_image(row,population,iterations,base_seed,alt_seed_offset,save_repro=False):
    path=DATA_DIR/Path(row['relative_to_data'])
    image=load_rgb(path,require_native_rgb=True)
    exp_id=str(row['experiment_id'])
    outdir=PER_IMAGE_DIR/f'{exp_id}_{safe_name(path.stem)}'; outdir.mkdir(parents=True,exist_ok=True)
    try: num=int(exp_id.split('_')[-1])
    except: num=0
    seed=base_seed+num; alt_seed=seed+alt_seed_offset; budget=population*iterations
    primary,t1=timed_run(image,population,iterations,seed,budget); save_run(outdir,image,primary,'primary')
    same,t2=timed_run(image,population,iterations,seed,budget)
    alt,t3=timed_run(image,population,iterations,alt_seed,budget)
    if save_repro:
        save_run(outdir,image,same,'same_seed_rerun'); save_run(outdir,image,alt,'alternate_seed_run')
    levels=tuple(int(x) for x in primary['levels_rgb'])
    same_seed_exact=(primary['levels_rgb']==same['levels_rgb'] and all(np.array_equal(primary[k],same[k]) for k in ('share1','share2','recovered')))
    alt_diff=(primary['levels_rgb']!=alt['levels_rgb'] or not np.array_equal(primary['share1'],alt['share1']) or not np.array_equal(primary['share2'],alt['share2']))
    recm=image_metrics(image,primary['recovered'])
    s1m=channel_share_metrics(image,primary['share1'],'share1'); s2m=channel_share_metrics(image,primary['share2'],'share2')
    assertions={
        'same_spatial_dimensions': primary['share1'].shape==image.shape and primary['share2'].shape==image.shape and primary['recovered'].shape==image.shape,
        'non_expansible_flag': bool(primary['non_expansible']),
        'share1_binary_0_255': is_binary_share(primary['share1']),
        'share2_binary_0_255': is_binary_share(primary['share2']),
        'xor_reconstruction_exact': np.array_equal(xor_reconstruct(primary['share1'],primary['share2']),primary['recovered']),
        'optimized_levels_valid_2_255': all(2<=x<=255 for x in levels),
        'fitness_values_finite': all(np.isfinite(float(primary['channel_results'][c]['best_fitness'])) for c in ('R','G','B')),
        'best_so_far_convergence_monotonic': all(monotonic_nonincreasing(primary['channel_results'][c]['convergence']) for c in ('R','G','B')),
        'same_seed_exactly_reproducible': same_seed_exact,
        'alternate_seed_shows_variability': alt_diff,
    }
    critical=[k for k in assertions if k!='alternate_seed_shows_variability']
    rowout={
        'experiment_id':exp_id,'dataset':row['dataset'],'split':row['split'],'filename':row['filename'],
        'source_width':int(row['width']),'source_height':int(row['height']),'seed':seed,'alternate_seed':alt_seed,
        'population_size':population,'iterations':iterations,'eval_budget_per_channel':budget,
        'best_level_R':levels[0],'best_level_G':levels[1],'best_level_B':levels[2],
        'best_fitness_R':primary['channel_results']['R']['best_fitness'],'best_fitness_G':primary['channel_results']['G']['best_fitness'],'best_fitness_B':primary['channel_results']['B']['best_fitness'],
        'runtime_primary_s':t1,'runtime_same_seed_s':t2,'runtime_alt_seed_s':t3,
        'reconstruction_mse':recm['mse'],'reconstruction_psnr':recm['psnr'],'reconstruction_cc':recm['cc'],
        **s1m,**s2m,**assertions,
        'all_critical_checks_pass':all(assertions[k] for k in critical),
        'artifact_dir':str(outdir),
    }
    repro={'experiment_id':exp_id,'filename':row['filename'],'primary_seed':seed,'same_seed_exactly_reproducible':same_seed_exact,'alternate_seed':alt_seed,'alternate_seed_shows_variability':alt_diff,'primary_levels':str(primary['levels_rgb']),'same_seed_levels':str(same['levels_rgb']),'alternate_seed_levels':str(alt['levels_rgb'])}
    return rowout,repro


def write_report(summary, selected, runtime_projection, args):
    critical=['same_spatial_dimensions','non_expansible_flag','share1_binary_0_255','share2_binary_0_255','xor_reconstruction_exact','optimized_levels_valid_2_255','fitness_values_finite','best_so_far_convergence_monotonic','same_seed_exactly_reproducible']
    checks=[]
    for c in critical:
        p=int(summary[c].astype(bool).sum()); checks.append({'check':c,'passed':p,'total':len(summary),'status':'PASS' if p==len(summary) else 'REVIEW'})
    lines=['# Group 1 Real-Image BDA Baseline Validation','',f'- Selected images: **{len(summary)}**',f'- Population: **{args.population}**',f'- Iterations: **{args.iterations}**',f'- Budget/channel: **{args.population*args.iterations}**','','## Selected images','',selected[['experiment_id','dataset','split','filename','width','height']].to_markdown(index=False),'','## Critical checks','',pd.DataFrame(checks).to_markdown(index=False),'','## Reproducibility','',f"- Same-seed exact reproducibility: **{int(summary['same_seed_exactly_reproducible'].sum())}/{len(summary)}**",f"- Alternate-seed variability: **{int(summary['alternate_seed_shows_variability'].sum())}/{len(summary)}**",'','## Runtime','',f"- Mean primary runtime/image: **{summary['runtime_primary_s'].mean():.3f} s**",f"- Projected BDA-only time for 214 images × 30 runs at this validation budget: **{runtime_projection['bda_214_images_30_runs_hours']:.2f} h**",'','## Overall status','']
    npass=int(summary['all_critical_checks_pass'].sum())
    lines.append(f"**{'PASS' if npass==len(summary) else 'REVIEW REQUIRED'}:** {npass}/{len(summary)} images passed all critical checks.")
    (OUTPUT_DIR/'validation_report.md').write_text('\n'.join(lines),encoding='utf-8')


def parse_args():
    p=argparse.ArgumentParser()
    p.add_argument('--population',type=int,default=10)
    p.add_argument('--iterations',type=int,default=10)
    p.add_argument('--seed',type=int,default=20260911)
    p.add_argument('--selection-seed',type=int,default=481)
    p.add_argument('--alt-seed-offset',type=int,default=1000003)
    p.add_argument('--save-repro-artifacts',action='store_true')
    return p.parse_args()


def main():
    args=parse_args()
    if not MANIFEST.exists(): raise FileNotFoundError(f'Manifest not found: {MANIFEST}')
    if args.population<2 or args.iterations<1: raise ValueError('population>=2 and iterations>=1 required')
    OUTPUT_DIR.mkdir(parents=True,exist_ok=True); PER_IMAGE_DIR.mkdir(parents=True,exist_ok=True)
    manifest=pd.read_csv(MANIFEST); selected=select_validation_images(manifest,args.selection_seed)
    selected.to_csv(OUTPUT_DIR/'selected_images.csv',index=False)
    rows=[]; repro=[]
    print('='*72); print('GROUP 1 REAL-IMAGE BDA VALIDATION'); print('='*72)
    for i,(_,r) in enumerate(selected.iterrows(),1):
        print(f"[{i}/{len(selected)}] {r['experiment_id']} | {r['dataset']} | {r['filename']}")
        a,b=validate_image(r,args.population,args.iterations,args.seed,args.alt_seed_offset,args.save_repro_artifacts)
        rows.append(a); repro.append(b)
        print(f"  levels: {a['best_level_R']}, {a['best_level_G']}, {a['best_level_B']} | runtime {a['runtime_primary_s']:.3f}s | {'PASS' if a['all_critical_checks_pass'] else 'REVIEW'}")
    summary=pd.DataFrame(rows); reprodf=pd.DataFrame(repro)
    summary.to_csv(OUTPUT_DIR/'validation_summary.csv',index=False,encoding='utf-8-sig')
    reprodf.to_csv(OUTPUT_DIR/'reproducibility_checks.csv',index=False,encoding='utf-8-sig')
    try:
        with pd.ExcelWriter(OUTPUT_DIR/'validation_summary.xlsx',engine='openpyxl') as w:
            summary.to_excel(w,sheet_name='Validation',index=False); reprodf.to_excel(w,sheet_name='Reproducibility',index=False); selected.to_excel(w,sheet_name='Selected Images',index=False)
    except Exception as e:
        print('Excel workbook skipped:',e)
    mean_rt=float(summary['runtime_primary_s'].mean()); final_runs=214*30
    projection={'validation_population':args.population,'validation_iterations':args.iterations,'validation_eval_budget_per_channel':args.population*args.iterations,'mean_primary_runtime_seconds_per_image':mean_rt,'bda_final_image_run_count_214_x_30':final_runs,'bda_214_images_30_runs_hours':mean_rt*final_runs/3600.0,'warning':'Planning estimate only; final frozen budget may differ.'}
    (OUTPUT_DIR/'runtime_projection.json').write_text(json.dumps(projection,indent=2),encoding='utf-8')
    write_report(summary,selected,projection,args)
    print('\nValidation complete.')
    print('Critical-pass images:',f"{int(summary['all_critical_checks_pass'].sum())}/{len(summary)}")
    print('Report:',OUTPUT_DIR/'validation_report.md')

if __name__=='__main__': main()
