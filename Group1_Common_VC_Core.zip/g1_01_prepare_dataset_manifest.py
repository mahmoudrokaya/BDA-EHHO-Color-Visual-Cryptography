#!/usr/bin/env python3
from __future__ import annotations
import csv, hashlib, json
from pathlib import Path
from PIL import Image

BASE_DIR = Path(r"D:\48\481\New Papers\BDA_To_HHO_paper")
DATA_DIR = BASE_DIR / "Data"
OUTPUT_DIR = BASE_DIR / "Outputs" / "Manifests"
BSDS_VAL = DATA_DIR / "BSR" / "BSDS500" / "data" / "images" / "val"
BSDS_TEST = DATA_DIR / "BSR" / "BSDS500" / "data" / "images" / "test"
SIPI_MISC = DATA_DIR / "misc"
IMAGE_EXTENSIONS = {".jpg",".jpeg",".png",".bmp",".tif",".tiff",".webp"}

def sha256_file(path, chunk_size=1024*1024):
    h=hashlib.sha256()
    with open(path,"rb") as f:
        while True:
            b=f.read(chunk_size)
            if not b: break
            h.update(b)
    return h.hexdigest()

def iter_images(folder):
    if not folder.exists(): return []
    return sorted(p for p in folder.rglob("*") if p.is_file() and p.suffix.lower() in IMAGE_EXTENSIONS)

def inspect_image(path):
    with Image.open(path) as im:
        return dict(width=im.width,height=im.height,mode=im.mode,format=im.format)

def add_records(records, folder, dataset, split, role, rgb_only=False):
    for path in iter_images(folder):
        info=inspect_image(path)
        if rgb_only and info["mode"]!="RGB": continue
        records.append({
            "dataset":dataset,"split":split,"experimental_role":role,
            "relative_to_data":str(path.relative_to(DATA_DIR)),
            "filename":path.name,**info,"sha256":sha256_file(path)
        })

def main():
    OUTPUT_DIR.mkdir(parents=True,exist_ok=True)
    rec=[]
    add_records(rec,BSDS_VAL,"BSDS500","validation","development_parameter_selection")
    add_records(rec,BSDS_TEST,"BSDS500","test","final_evaluation_natural_images")
    add_records(rec,SIPI_MISC,"USC-SIPI Miscellaneous","classical","final_evaluation_classical",rgb_only=True)
    excluded=[r for r in rec if r["mode"]!="RGB"]
    rec=[r for r in rec if r["mode"]=="RGB"]
    for i,r in enumerate(rec,1): r["experiment_id"]=f"IMG_{i:04d}"
    fields=["experiment_id","dataset","split","experimental_role","relative_to_data","filename","width","height","mode","format","sha256"]
    with open(OUTPUT_DIR/"dataset_manifest.csv","w",newline="",encoding="utf-8-sig") as f:
        w=csv.DictWriter(f,fieldnames=fields); w.writeheader(); w.writerows(rec)
    (OUTPUT_DIR/"dataset_manifest.json").write_text(json.dumps(rec,indent=2),encoding="utf-8")
    summary={
        "total_color_images":len(rec),
        "bsds500_validation":sum(r["dataset"]=="BSDS500" and r["split"]=="validation" for r in rec),
        "bsds500_test":sum(r["dataset"]=="BSDS500" and r["split"]=="test" for r in rec),
        "usc_sipi_rgb":sum(r["dataset"]=="USC-SIPI Miscellaneous" for r in rec),
        "excluded_non_rgb_count":len(excluded),
        "resizing":"none; native dimensions retained"
    }
    (OUTPUT_DIR/"dataset_manifest_summary.json").write_text(json.dumps(summary,indent=2),encoding="utf-8")
    print(json.dumps(summary,indent=2))
if __name__=="__main__": main()
