import numpy as np
BITS_PER_CHANNEL=8; MIN_GROUPS=2; MAX_GROUPS=255
def bits_to_uint8(bits):
    bits=np.asarray(bits,dtype=np.uint8).ravel()
    if len(bits)!=8 or not np.all((bits==0)|(bits==1)): raise ValueError("Expected 8 binary bits.")
    return int(np.dot(bits,2**np.arange(7,-1,-1,dtype=np.int64)))
def decode_channel_bits(bits):
    return int(np.clip(bits_to_uint8(bits),MIN_GROUPS,MAX_GROUPS))
def uint8_to_bits(v):
    v=int(np.clip(v,0,255))
    return np.array([(v>>s)&1 for s in range(7,-1,-1)],dtype=np.uint8)
def decode_rgb_solution(bits24):
    x=np.asarray(bits24,dtype=np.uint8).ravel()
    if len(x)!=24: raise ValueError("Expected 24 bits.")
    return tuple(decode_channel_bits(x[i:i+8]) for i in (0,8,16))
def encode_rgb_levels(levels):
    return np.concatenate([uint8_to_bits(v) for v in levels])
