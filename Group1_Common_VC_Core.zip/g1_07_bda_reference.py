from __future__ import annotations
from dataclasses import dataclass,asdict
from pathlib import Path
from typing import Callable
import json,numpy as np
from g1_02_rgb_decomposition import load_rgb
from g1_03_vc_share_generation import generate_rgb_shares
from g1_04_vc_reconstruction import xor_reconstruct,verify_non_expansion
from g1_05_vc_solution_encoding import decode_channel_bits
from g1_06_vc_baseline_fitness import make_bda_cost

@dataclass
class BDAResult:
    best_bits:list[int]
    best_level_count:int
    best_fitness:float
    convergence:list[float]
    evaluations:int
    iterations_completed:int
    seed:int

def optimize_channel_bda(cost_function:Callable[[np.ndarray],float],population_size=60,
                         max_iterations=1000,dim=8,seed=0,max_evaluations=None):
    rng=np.random.default_rng(seed)
    X=rng.integers(0,2,size=(population_size,dim),dtype=np.uint8)
    DeltaX=rng.integers(0,2,size=(population_size,dim)).astype(float)
    food_fit=float("inf"); food=np.zeros(dim,dtype=np.uint8)
    enemy_fit=-float("inf"); enemy=np.zeros(dim,dtype=np.uint8)
    convergence=[]; evaluations=0; completed=0

    for iteration in range(1,max_iterations+1):
        fitness=np.full(population_size,np.nan)
        for i in range(population_size):
            if max_evaluations is not None and evaluations>=max_evaluations: break
            fv=float(cost_function(X[i].copy())); evaluations+=1; fitness[i]=fv
            if fv<food_fit: food_fit=fv; food=X[i].copy()
            if fv>enemy_fit: enemy_fit=fv; enemy=X[i].copy()

        if not np.any(np.isfinite(fitness)): break
        completed+=1; convergence.append(float(food_fit))
        if max_evaluations is not None and evaluations>=max_evaluations: break

        w=0.9-iteration*((0.9-0.4)/max_iterations)
        my_c=max(0.1-iteration*(0.1/(max_iterations/2.0)),0.0)
        s=2*rng.random()*my_c; a=2*rng.random()*my_c
        c=2*rng.random()*my_c; f=2*rng.random(); e=my_c
        if iteration>(3*max_iterations/4): e=0.0

        sumX=X.astype(float).sum(axis=0); sumD=DeltaX.sum(axis=0)
        n=population_size-1
        if n<=0: raise ValueError("population_size must be >=2")

        for i in range(population_size):
            xi=X[i].astype(float)
            neighX=sumX-xi; neighD=sumD-DeltaX[i]
            S=-(neighX-n*xi)
            A=neighD/n
            C=(neighX/n)-xi
            F=food.astype(float)-xi
            E=enemy.astype(float)+xi
            DeltaX[i]=s*S+a*A+c*C+f*F+e*E+w*DeltaX[i]
            DeltaX[i]=np.clip(DeltaX[i],-6,6)
            T=np.abs(DeltaX[i]/np.sqrt(1+DeltaX[i]**2))
            flips=rng.random(dim)<T
            X[i,flips]=1-X[i,flips]

    return BDAResult(food.astype(int).tolist(),decode_channel_bits(food),float(food_fit),
                     convergence,evaluations,completed,int(seed))

def optimize_rgb_levels_bda(image,population_size=60,max_iterations=1000,
                            seed=20260911,max_evaluations_per_channel=None):
    ss=np.random.SeedSequence(seed); child=ss.spawn(6)
    random_fields=[np.random.default_rng(child[i]).random(image.shape[:2]) for i in range(3)]
    opt_seeds=[int(np.random.default_rng(child[3+i]).integers(0,2**31-1)) for i in range(3)]
    names=("R","G","B"); results={}
    for ch,name in enumerate(names):
        cost=make_bda_cost(image[...,ch],random_fields[ch])
        results[name]=optimize_channel_bda(cost,population_size,max_iterations,8,opt_seeds[ch],max_evaluations_per_channel)
    levels=tuple(results[n].best_level_count for n in names)
    share1,share2,meta=generate_rgb_shares(image,levels,random_fields=tuple(random_fields))
    rec=xor_reconstruct(share1,share2)
    return {"levels_rgb":levels,"channel_results":{k:asdict(v) for k,v in results.items()},
            "share_metadata":meta,"share1":share1,"share2":share2,"recovered":rec,
            "non_expansible":verify_non_expansion(image,share1,share2),"seed":seed}

def run_image(image_path,output_dir,population_size=60,max_iterations=1000,
              seed=20260911,max_evaluations_per_channel=None):
    from PIL import Image
    image_path=Path(image_path); output_dir=Path(output_dir); output_dir.mkdir(parents=True,exist_ok=True)
    image=load_rgb(image_path,True)
    result=optimize_rgb_levels_bda(image,population_size,max_iterations,seed,max_evaluations_per_channel)
    stem=image_path.stem
    Image.fromarray(result["share1"]).save(output_dir/f"{stem}_share1.png")
    Image.fromarray(result["share2"]).save(output_dir/f"{stem}_share2.png")
    Image.fromarray(result["recovered"]).save(output_dir/f"{stem}_recovered.png")
    serial={k:v for k,v in result.items() if k not in {"share1","share2","recovered"}}
    (output_dir/f"{stem}_bda_result.json").write_text(json.dumps(serial,indent=2),encoding="utf-8")
    return result
