import numpy as np

def equal_population_boundaries(channel,n_groups):
    channel=np.asarray(channel,dtype=np.uint8)
    n_groups=int(np.clip(n_groups,2,255))
    hist=np.bincount(channel.ravel(),minlength=256)
    cdf=np.cumsum(hist); total=int(cdf[-1])
    targets=np.arange(1,n_groups,dtype=float)*total/n_groups
    return np.unique(np.searchsorted(cdf,targets,side="left").astype(np.int16))

def channel_group_indices(channel,n_groups):
    boundaries=equal_population_boundaries(channel,n_groups)
    idx=np.searchsorted(boundaries,channel,side="right")
    return idx.astype(np.int16),len(boundaries)+1,boundaries

def generate_channel_shares(channel,n_groups,rng=None,random_field=None):
    if channel.ndim!=2: raise ValueError("Channel must be 2-D.")
    rng=np.random.default_rng() if rng is None else rng
    k,ng,bounds=channel_group_indices(channel,n_groups)
    p=np.zeros_like(channel,dtype=float) if ng<=1 else k.astype(float)/(ng-1)
    r=rng.random(channel.shape) if random_field is None else np.asarray(random_field,float)
    if r.shape!=channel.shape: raise ValueError("random_field shape mismatch.")
    s1=np.empty(channel.shape,np.uint8); s2=np.empty(channel.shape,np.uint8)
    same=r<p; z=same&(r<p/2); o=same&~z
    diff=~same; split=p+(1-p)/2; a=diff&(r<split); b=diff&~a
    s1[z]=0; s2[z]=0; s1[o]=255; s2[o]=255
    s1[a]=0; s2[a]=255; s1[b]=255; s2[b]=0
    return s1,s2,{"requested_groups":int(n_groups),"effective_groups":int(ng),"boundaries":bounds.tolist()}

def generate_rgb_shares(image,levels_rgb,seed=None,random_fields=None):
    if image.ndim!=3 or image.shape[2]!=3: raise ValueError("Expected HxWx3.")
    rng=np.random.default_rng(seed); a=[]; b=[]; meta={}
    for i,name in enumerate(("R","G","B")):
        rf=None if random_fields is None else random_fields[i]
        s1,s2,m=generate_channel_shares(image[...,i],levels_rgb[i],rng,rf)
        a.append(s1); b.append(s2); meta[name]=m
    return np.stack(a,-1),np.stack(b,-1),meta
