import json,numpy as np
from g1_03_vc_share_generation import generate_rgb_shares
from g1_04_vc_reconstruction import xor_reconstruct,verify_non_expansion
from g1_05_vc_solution_encoding import encode_rgb_levels,decode_rgb_solution
from g1_07_bda_reference import optimize_rgb_levels_bda

def synthetic_rgb(h=48,w=64):
    y,x=np.mgrid[0:h,0:w]
    r=(255*x/max(w-1,1)).astype(np.uint8)
    g=(255*y/max(h-1,1)).astype(np.uint8)
    b=((r.astype(int)+g.astype(int))//2).astype(np.uint8)
    return np.stack([r,g,b],-1)

img=synthetic_rgb(); levels=(8,16,32)
assert decode_rgb_solution(encode_rgb_levels(levels))==levels
rng=np.random.default_rng(123); fields=tuple(rng.random(img.shape[:2]) for _ in range(3))
s1,s2,_=generate_rgb_shares(img,levels,random_fields=fields)
rec=xor_reconstruct(s1,s2)
assert s1.shape==s2.shape==rec.shape==img.shape
assert verify_non_expansion(img,s1,s2)
out=optimize_rgb_levels_bda(img,population_size=8,max_iterations=3,seed=42,max_evaluations_per_channel=24)
print(json.dumps({"levels_rgb":list(out["levels_rgb"]),
                  "non_expansible":out["non_expansible"],
                  "evaluations":{k:v["evaluations"] for k,v in out["channel_results"].items()}},indent=2))
print("GROUP 1 SMOKE TEST: PASS")
