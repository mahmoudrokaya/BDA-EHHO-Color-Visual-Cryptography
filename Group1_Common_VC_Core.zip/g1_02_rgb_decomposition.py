from pathlib import Path
import numpy as np
from PIL import Image

def load_rgb(path, require_native_rgb=True):
    path=Path(path)
    with Image.open(path) as im:
        if require_native_rgb and im.mode!="RGB":
            raise ValueError(f"{path.name} is mode={im.mode}, not native RGB.")
        return np.asarray(im.convert("RGB"),dtype=np.uint8)

def split_rgb(image):
    if image.ndim!=3 or image.shape[2]!=3: raise ValueError("Expected HxWx3 RGB image.")
    return image[...,0],image[...,1],image[...,2]

def merge_rgb(r,g,b):
    if r.shape!=g.shape or r.shape!=b.shape: raise ValueError("Channel shapes differ.")
    return np.stack([r,g,b],axis=-1).astype(np.uint8)
