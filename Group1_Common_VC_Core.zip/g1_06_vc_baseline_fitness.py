import math, numpy as np
from g1_03_vc_share_generation import generate_channel_shares
from g1_05_vc_solution_encoding import decode_channel_bits

def mse(a,b):
    d=a.astype(float)-b.astype(float); return float(np.mean(d*d))
def psnr(a,b,data_range=255.0):
    e=mse(a,b)
    return float("inf") if e==0 else float(10*math.log10((data_range**2)/e))
def pearson_cc(a,b):
    x=a.astype(float).ravel(); y=b.astype(float).ravel()
    if x.std()==0 or y.std()==0: return 0.0
    return float(np.corrcoef(x,y)[0,1])
def channel_level_fitness(secret_channel,level_count,random_field):
    s1,s2,meta=generate_channel_shares(secret_channel,level_count,random_field=random_field)
    p1,p2=psnr(secret_channel,s1),psnr(secret_channel,s2)
    c1,c2=pearson_cc(secret_channel,s1),pearson_cc(secret_channel,s2)
    score=.5*((p1+abs(c1))+(p2+abs(c2)))
    return float(score),{"level_count":int(level_count),"fitness":float(score),
        "share1_psnr":p1,"share2_psnr":p2,"share1_cc":c1,"share2_cc":c2,**meta}
def make_bda_cost(secret_channel,random_field):
    def cost(bits8):
        return channel_level_fitness(secret_channel,decode_channel_bits(bits8),random_field)[0]
    return cost
