import numpy as np
def xor_reconstruct(share1,share2):
    if share1.shape!=share2.shape: raise ValueError("Share shapes differ.")
    return np.bitwise_xor(share1.astype(np.uint8),share2.astype(np.uint8))
def verify_non_expansion(original,*shares):
    return all(s.shape[:2]==original.shape[:2] for s in shares)
