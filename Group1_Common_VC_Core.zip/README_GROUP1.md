# Group 1 — Common VC Core and BDA Reference

Implements the fixed Section 3.1 architecture before any HHO-based changes.

## Codes
- `g1_01_prepare_dataset_manifest.py`: locks BSDS500 validation/test and genuine RGB USC-SIPI images, with SHA-256 provenance.
- `g1_02_rgb_decomposition.py`: native-RGB loading and RGB channel handling.
- `g1_03_vc_share_generation.py`: non-expansible probabilistic (2,2) share generation.
- `g1_04_vc_reconstruction.py`: XOR reconstruction.
- `g1_05_vc_solution_encoding.py`: 8-bit color-level encoding/decoding.
- `g1_06_vc_baseline_fitness.py`: reference PSNR + |CC| secret/share fitness.
- `g1_07_bda_reference.py`: BDA reference optimizer using the V3 transfer function.
- `run_group1_smoke_test.py`: fast synthetic validation.

## Reproducibility choices
1. Native image dimensions are retained.
2. Grayscale USC-SIPI images are not artificially converted into color test cases.
3. Each optimizer run uses fixed per-channel random fields during candidate evaluation. This common-random-number design prevents candidate rankings from changing merely because new random share draws were used.
4. The BDA paper represents each channel level with 8 bits. Since share generation uses P=k/(N_X-1), executable group counts must be >=2; decoded 0/1 values are therefore clamped to 2 and this is logged explicitly.
5. The reference fitness follows the paper's PSNR + correlation formulation. We use the mean across the two shares and |CC| so either strong positive or negative secret-share dependence is penalized.

## First run
```bat
pip install -r requirements_group1.txt
python run_group1_smoke_test.py
python g1_01_prepare_dataset_manifest.py
```

Do not begin HHO comparisons until the BDA baseline has been reproduced and sanity-checked on real benchmark images.
