#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Analyze final 12-image MO validation with all four objectives frozen."""

from pathlib import Path
import json
import numpy as np
import pandas as pd

BASE = Path(r"D:\48\481\New Papers\BDA_To_HHO_paper")
OUT = BASE/"Outputs"/"Group3_Final_Objective_Validation"


def main():
    df = pd.read_csv(OUT/"final_validation_raw.csv")
    expected = 24

    completion = bool(len(df)==expected)
    budget = bool(df["budget_compliant"].astype(bool).all())
    nondom = bool(df["archive_all_nondominated"].astype(bool).all())
    nonempty = bool((df["archive_size"]>0).all())

    # Correct diversity-health logic.
    diversity_health = (
        (df["final_diversity"]>=0.70)
        | (df["injection_count"]>0)
    )
    diversity_pass = bool(diversity_health.all())

    bda = float(df["bda_fraction"].mean())
    hybrid_pass = bool(0.35<=bda<=0.65)

    objective_nonconstant = {
        "f1": bool((df["f1_max"]-df["f1_min"]>1e-12).all()),
        "f2": bool((df["f2_max"]-df["f2_min"]>1e-12).all()),
        "f3": bool((df["f3_max"]-df["f3_min"]>1e-12).all()),
        "f4": bool((df["f4_max"]-df["f4_min"]>1e-12).all()),
    }

    all_objectives_active = bool(all(objective_nonconstant.values()))

    summary = pd.DataFrame([{
        "runs":len(df),
        "mean_archive_size":df["archive_size"].mean(),
        "median_archive_size":df["archive_size"].median(),
        "median_runtime_s":df["runtime_s"].median(),
        "mean_runtime_s":df["runtime_s"].mean(),
        "mean_bda_fraction":bda,
        "mean_ehho_fraction":1-bda,
        "diversity_healthy_runs_pct":100*diversity_health.mean(),
        "f1_mean_span":(df["f1_max"]-df["f1_min"]).mean(),
        "f2_mean_span":(df["f2_max"]-df["f2_min"]).mean(),
        "f3_mean_span":(df["f3_max"]-df["f3_min"]).mean(),
        "f4_mean_span":(df["f4_max"]-df["f4_min"]).mean(),
    }])

    overall = bool(
        completion and budget and nondom and nonempty
        and diversity_pass and hybrid_pass and all_objectives_active
    )

    decision = {
        "completion_pass":completion,
        "budget_compliance_pass":budget,
        "archive_nonempty_pass":nonempty,
        "archive_nondominance_pass":nondom,
        "diversity_health_pass":diversity_pass,
        "hybrid_balance_pass":hybrid_pass,
        "all_four_objectives_active_pass":all_objectives_active,
        "objective_nonconstant_by_run":objective_nonconstant,
        "frozen_objectives":{
            "f1":"normalized reconstruction MSE",
            "f2":"mean absolute secret-share Pearson correlation (S2)",
            "f3":"mean normalized clean-vs-damaged reconstruction MSE under 5/10/20% central Share-1 block erasure (B1)",
            "f4":"mean RGB group count / 255",
        },
        "status":"GROUP3_OBJECTIVES_FROZEN_PASS" if overall else "REVIEW_REQUIRED",
        "next_stage":"E4 multi-objective comparative experiment" if overall else "Review final 12-image validation before E4"
    }

    (OUT/"final_validation_decision.json").write_text(
        json.dumps(decision,indent=2),encoding="utf-8"
    )

    summary.to_csv(
        OUT/"final_validation_summary.csv",
        index=False,encoding="utf-8-sig"
    )

    report = [
        "# Group 3 — Final Objective Validation","",
        f"- Runs: **{len(df)}/{expected}**",
        f"- Completion: **{'PASS' if completion else 'REVIEW'}**",
        f"- Budget compliance: **{'PASS' if budget else 'REVIEW'}**",
        f"- Nonempty archives: **{'PASS' if nonempty else 'REVIEW'}**",
        f"- Nondominated archives: **{'PASS' if nondom else 'REVIEW'}**",
        f"- Diversity health: **{'PASS' if diversity_pass else 'REVIEW'}**",
        f"- BDA/EHHO balance: **{'PASS' if hybrid_pass else 'REVIEW'}**",
        f"- All four objectives active within every run: **{'PASS' if all_objectives_active else 'REVIEW'}**","",
        "## Summary","",summary.to_markdown(index=False),"",
        "## Frozen objectives","",
        "1. f1: normalized reconstruction MSE.",
        "2. f2: mean absolute secret-share Pearson correlation (S2).",
        "3. f3: mean normalized clean-vs-damaged reconstruction MSE under 5%, 10%, and 20% central Share-1 block erasure (B1).",
        "4. f4: mean RGB group count / 255.","",
        f"## Decision\n\n**{decision['status']}**"
    ]

    (OUT/"final_validation_report.md").write_text(
        "\n".join(report),encoding="utf-8"
    )

    try:
        with pd.ExcelWriter(OUT/"final_validation.xlsx",engine="openpyxl") as w:
            df.to_excel(w,sheet_name="Runs",index=False)
            summary.to_excel(w,sheet_name="Summary",index=False)
    except Exception as e:
        print("Excel export skipped:",e)

    print("Status:",decision["status"])
    print("Report:",OUT/"final_validation_report.md")


if __name__=="__main__":
    main()
