#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Final 12-image MO validation after freezing all four objectives.

Uses:
- f1 reconstruction MSE
- f2 S2 absolute correlation security
- f3 B1 central block-erasure robustness
- f4 normalized complexity

Optimizer settings remain frozen:
- N = 30
- B = 600
- rho 0.70 -> 0.30
- diversity trigger = 0.70
- injection fraction = 0.30
- archive size = 100
"""

from __future__ import annotations
import csv, hashlib, time
from pathlib import Path
import numpy as np
import pandas as pd

from g1_02_rgb_decomposition import load_rgb
from g3_02_pareto_archive import nondominated_mask
from g3_03_mo_bda_ehho_vc import optimize_mo_bda_ehho_vc
from g3_17_multiobjective_vc_final import MultiObjectiveVCProblemFinal

BASE = Path(r"D:\48\481\New Papers\BDA_To_HHO_paper")
DATA = BASE/"Data"
SEL = BASE/"Outputs"/"Group2_Validation_Tuning"/"pilot"/"selected_validation_images.csv"
OUT = BASE/"Outputs"/"Group3_Final_Objective_Validation"

POP = 30
BUDGET = 600
RUNS = 2
ARCHIVE = 100
BASE_SEED = 20260913

FIELDS = [
    "run_key","experiment_id","filename","run_index","seed",
    "runtime_s","evaluations","budget_compliant","archive_size",
    "archive_all_nondominated","f1_min","f1_max","f2_min","f2_max",
    "f3_min","f3_max","f4_min","f4_max","mean_diversity",
    "final_diversity","injection_count","bda_proposals","ehho_proposals",
    "bda_fraction","cache_hit_rate"
]


def stable_seed(*parts):
    d = hashlib.sha256("|".join(map(str,parts)).encode()).digest()
    return int.from_bytes(d[:4],"little") & 0x7fffffff


def append(path,row):
    new = not path.exists()
    with path.open("a",newline="",encoding="utf-8-sig") as f:
        w = csv.DictWriter(f,fieldnames=FIELDS)
        if new:
            w.writeheader()
        w.writerow(row)
        f.flush()


def existing(path):
    if not path.exists():
        return set()
    return set(pd.read_csv(path,usecols=["run_key"])["run_key"].astype(str))


def main():
    OUT.mkdir(parents=True,exist_ok=True)
    ad = OUT/"archives"
    ad.mkdir(exist_ok=True)

    sel = pd.read_csv(SEL)
    raw = OUT/"final_validation_raw.csv"
    done = existing(raw)
    total = len(sel)*RUNS

    for _,row in sel.iterrows():
        image = load_rgb(DATA/row["relative_to_data"],True)

        for run_idx in range(1,RUNS+1):
            seed = stable_seed(
                BASE_SEED,row["experiment_id"],run_idx,"MO_FINAL"
            )
            key = f"{row['experiment_id']}|r{run_idx}"
            if key in done:
                continue

            problem = MultiObjectiveVCProblemFinal.from_seed(image,seed)

            t0 = time.perf_counter()
            result = optimize_mo_bda_ehho_vc(
                problem,
                population_size=POP,
                max_iterations=100,
                max_evaluations=BUDGET,
                seed=seed,
                archive_size=ARCHIVE,
                rho_max=.70,
                rho_min=.30,
                diversity_threshold=.70,
                injection_fraction=.30,
            )
            dt = time.perf_counter()-t0

            F = np.asarray(result.archive_objectives,float)
            B = np.asarray(result.archive_bits,np.uint8)

            pd.DataFrame(
                F,
                columns=[
                    "f1_reconstruction",
                    "f2_security_s2",
                    "f3_robustness_b1",
                    "f4_complexity",
                ],
            ).assign(
                bits=["".join(map(str,x.tolist())) for x in B]
            ).to_csv(
                ad/f"{row['experiment_id']}_r{run_idx}_archive.csv",
                index=False,
                encoding="utf-8-sig",
            )

            div = result.diversity_history
            total_prop = result.bda_proposals + result.ehho_proposals

            rec = {
                "run_key":key,
                "experiment_id":row["experiment_id"],
                "filename":row["filename"],
                "run_index":run_idx,
                "seed":seed,
                "runtime_s":dt,
                "evaluations":result.evaluations,
                "budget_compliant":result.evaluations<=BUDGET,
                "archive_size":len(F),
                "archive_all_nondominated":bool(np.all(nondominated_mask(F))),
                "f1_min":F[:,0].min(),"f1_max":F[:,0].max(),
                "f2_min":F[:,1].min(),"f2_max":F[:,1].max(),
                "f3_min":F[:,2].min(),"f3_max":F[:,2].max(),
                "f4_min":F[:,3].min(),"f4_max":F[:,3].max(),
                "mean_diversity":float(np.mean(div)) if div else np.nan,
                "final_diversity":float(div[-1]) if div else np.nan,
                "injection_count":len(result.injection_iterations),
                "bda_proposals":result.bda_proposals,
                "ehho_proposals":result.ehho_proposals,
                "bda_fraction":result.bda_proposals/total_prop if total_prop else np.nan,
                "cache_hit_rate":problem.cache_stats()["tuple_cache_hit_rate"],
            }

            append(raw,rec)
            done.add(key)

            print(
                f"[{len(done)}/{total}] {row['experiment_id']} r{run_idx}: "
                f"archive={len(F)}, f3range={F[:,2].ptp():.6g}, "
                f"BDA={rec['bda_fraction']:.3f}, {dt:.2f}s"
            )

    print("Final validation complete:",raw)


if __name__=="__main__":
    main()
