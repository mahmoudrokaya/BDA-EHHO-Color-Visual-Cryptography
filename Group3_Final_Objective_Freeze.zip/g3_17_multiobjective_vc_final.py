#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Final frozen Group-3 multi-objective VC problem.

Objectives (all minimized)
--------------------------
f1 Reconstruction:
    MSE(secret, clean reconstruction) / 255^2

f2 Security (S2, frozen):
    mean absolute Pearson correlation between the secret and each individual
    share, averaged over both shares and RGB channels.

f3 Robustness (B1, frozen):
    mean over 5%, 10%, 20% CENTRAL BLOCK ERASURE on Share 1 of
        MSE(clean reconstruction, damaged reconstruction) / 255^2

f4 Complexity:
    mean(N_R, N_G, N_B) / 255

Notes
-----
- Robustness damage masks are deterministic for a given image/run.
- Central block erasure is localized and reproducible.
- This file does not change any optimizer parameter.
- Wall-clock runtime remains an external evaluation metric.
"""

from __future__ import annotations
from collections import OrderedDict
from dataclasses import dataclass, field
import math
import numpy as np

from g1_03_vc_share_generation import generate_channel_shares
from g1_04_vc_reconstruction import xor_reconstruct
from g1_05_vc_solution_encoding import decode_channel_bits

MAX_MSE = 255.0 ** 2
ROBUSTNESS_RATES = (0.05, 0.10, 0.20)


def mse(a, b):
    x = np.asarray(a, dtype=np.float64)
    y = np.asarray(b, dtype=np.float64)
    return float(np.mean((x-y)**2))


def pearson(a, b):
    x = np.asarray(a, dtype=np.float64).ravel()
    y = np.asarray(b, dtype=np.float64).ravel()
    sx, sy = x.std(), y.std()
    if sx <= 1e-15 or sy <= 1e-15:
        return 0.0
    return float(np.corrcoef(x, y)[0, 1])


def block_hw(h, w, frac):
    area = max(1, int(round(h*w*float(frac))))
    aspect = w/max(h, 1)
    bh = max(1, int(round(math.sqrt(area/max(aspect, 1e-12)))))
    bw = max(1, int(round(area/bh)))
    return min(bh, h), min(bw, w)


def central_block_mask(shape, frac):
    h, w, _ = shape
    bh, bw = block_hw(h, w, frac)
    y0 = max(0, (h-bh)//2)
    x0 = max(0, (w-bw)//2)
    m = np.zeros((h, w), dtype=bool)
    m[y0:y0+bh, x0:x0+bw] = True
    return np.repeat(m[..., None], 3, axis=2)


@dataclass
class MultiObjectiveVCProblemFinal:
    image: np.ndarray
    random_fields: tuple
    robustness_masks: dict
    tuple_cache: dict = field(default_factory=dict, init=False, repr=False)
    channel_share_cache: OrderedDict = field(default_factory=OrderedDict, init=False, repr=False)
    max_channel_cache_entries: int = 48
    cache_hits: int = 0
    cache_misses: int = 0

    @classmethod
    def from_seed(cls, image, seed, max_channel_cache_entries=48):
        if image.ndim != 3 or image.shape[2] != 3:
            raise ValueError("Expected HxWx3 RGB image.")

        ss = np.random.SeedSequence(seed)
        children = ss.spawn(3)

        random_fields = tuple(
            np.random.default_rng(children[i]).random(image.shape[:2])
            for i in range(3)
        )

        robustness_masks = {
            rate: central_block_mask(image.shape, rate)
            for rate in ROBUSTNESS_RATES
        }

        return cls(
            image=image,
            random_fields=random_fields,
            robustness_masks=robustness_masks,
            max_channel_cache_entries=max_channel_cache_entries,
        )

    @staticmethod
    def clip_level(x):
        return int(np.clip(np.rint(x), 2, 255))

    def decode_bits24(self, bits24):
        x = np.asarray(bits24, dtype=np.uint8).ravel()
        if len(x) != 24:
            raise ValueError("Expected 24 bits.")
        return (
            decode_channel_bits(x[:8]),
            decode_channel_bits(x[8:16]),
            decode_channel_bits(x[16:24]),
        )

    def _channel_shares(self, ch, level):
        level = self.clip_level(level)
        key = (int(ch), int(level))
        if key in self.channel_share_cache:
            val = self.channel_share_cache.pop(key)
            self.channel_share_cache[key] = val
            return val

        s1, s2, meta = generate_channel_shares(
            self.image[..., ch],
            level,
            random_field=self.random_fields[ch],
        )
        val = (s1, s2, meta)
        self.channel_share_cache[key] = val

        while len(self.channel_share_cache) > self.max_channel_cache_entries:
            self.channel_share_cache.popitem(last=False)

        return val

    def _build_shares(self, levels):
        a, b, meta = [], [], {}
        for ch, name in enumerate(("R", "G", "B")):
            s1, s2, m = self._channel_shares(ch, levels[ch])
            a.append(s1)
            b.append(s2)
            meta[name] = m
        return np.stack(a, -1), np.stack(b, -1), meta

    def _security_s2(self, share1, share2):
        vals = []
        for share in (share1, share2):
            for ch in range(3):
                vals.append(
                    abs(
                        pearson(
                            self.image[..., ch],
                            share[..., ch],
                        )
                    )
                )
        return float(np.mean(vals))

    def _robustness_b1(self, share1, share2, clean_rec):
        vals = []
        for rate in ROBUSTNESS_RATES:
            damaged1 = share1.copy()
            damaged1[self.robustness_masks[rate]] = 0
            damaged_rec = xor_reconstruct(damaged1, share2)
            vals.append(mse(clean_rec, damaged_rec)/MAX_MSE)
        return float(np.mean(vals))

    def evaluate_levels(self, levels_rgb):
        levels = tuple(self.clip_level(v) for v in levels_rgb)

        if levels in self.tuple_cache:
            self.cache_hits += 1
            obj, details = self.tuple_cache[levels]
            return obj.copy(), dict(details)

        self.cache_misses += 1
        share1, share2, meta = self._build_shares(levels)
        clean = xor_reconstruct(share1, share2)

        f1 = mse(self.image, clean)/MAX_MSE
        f2 = self._security_s2(share1, share2)
        f3 = self._robustness_b1(share1, share2, clean)
        f4 = float(np.mean(levels)/255.0)

        obj = np.asarray([f1, f2, f3, f4], dtype=float)

        details = {
            "levels_rgb": levels,
            "objectives": obj.tolist(),
            "f1_reconstruction": float(f1),
            "f2_security_s2": float(f2),
            "f3_robustness_b1": float(f3),
            "f4_complexity": float(f4),
            "share_metadata": meta,
        }

        self.tuple_cache[levels] = (obj.copy(), dict(details))
        return obj, details

    def evaluate_bits24(self, bits24):
        return self.evaluate_levels(self.decode_bits24(bits24))

    def cache_stats(self):
        total = self.cache_hits + self.cache_misses
        return {
            "tuple_cache_entries": len(self.tuple_cache),
            "tuple_cache_hits": self.cache_hits,
            "tuple_cache_misses": self.cache_misses,
            "tuple_cache_hit_rate": self.cache_hits/total if total else 0.0,
        }
