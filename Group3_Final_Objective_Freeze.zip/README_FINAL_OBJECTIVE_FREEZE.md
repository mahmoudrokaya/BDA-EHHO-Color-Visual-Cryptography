# Group 3 — Final Objective Freeze and 12-Image Revalidation

Based on the completed objective audits, freeze:

- **f1 Reconstruction:** normalized clean reconstruction MSE.
- **f2 Security:** S2 = mean absolute Pearson correlation between secret and each individual share.
- **f3 Robustness:** B1 = mean clean-vs-damaged reconstruction MSE under 5%, 10%, 20% central block erasure of Share 1.
- **f4 Complexity:** mean RGB group count / 255.

## Why B1?
B1 was nonconstant in 100% of archives, monotonic with damage level in 100% of candidates, and had very low correlations with reconstruction, security, and complexity.

## Run order

Copy these files into the Group 3 folder:

```powershell
python g3_18_run_final_12image_validation.py
python g3_19_analyze_final_12image_validation.py
```

Outputs:
`D:\48\481\New Papers\BDA_To_HHO_paper\Outputs\Group3_Final_Objective_Validation`

Do not change optimizer parameters. If this passes, the four objectives are frozen and the next stage is E4.
