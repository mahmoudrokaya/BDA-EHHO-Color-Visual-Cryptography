#!/usr/bin/env python3
from pathlib import Path
import numpy as np, pandas as pd

BASE=Path(r"D:\48\481\New Papers\BDA_To_HHO_paper")
OUT=BASE/"Outputs"/"Group2_Calibrated_Pilot_Rerun"

def main():
    df=pd.read_csv(OUT/"calibrated_pilot_raw.csv")
    expected=96
    df["paired_rank"]=df.groupby(["experiment_id","run_index"])["best_score"].rank(method="average",ascending=True)
    summary=(df.groupby("algorithm").agg(
        runs=("best_score","size"),mean_best_score=("best_score","mean"),
        median_best_score=("best_score","median"),sd_best_score=("best_score","std"),
        mean_paired_rank=("paired_rank","mean"),median_runtime_s=("runtime_s","median"),
        mean_runtime_s=("runtime_s","mean")).reset_index().sort_values("mean_paired_rank"))
    summary.to_csv(OUT/"calibrated_pilot_summary.csv",index=False,encoding="utf-8-sig")
    df.to_csv(OUT/"paired_ranked_results.csv",index=False,encoding="utf-8-sig")

    b=df[df["algorithm"]=="BEHHO-VC-Calibrated"]; h=df[df["algorithm"]=="BDA-EHHO-VC-Calibrated"]
    inj_rate=100*np.mean(b["injection_count"]>0); bda_frac=h["bda_fraction"].mean()
    mech=pd.DataFrame([
        {"algorithm":"BEHHO-VC-Calibrated","runs":len(b),"mean_injections":b["injection_count"].mean(),
         "pct_runs_with_injection":inj_rate,"mean_diversity":b["diversity_mean"].mean(),
         "mean_final_diversity":b["diversity_final"].mean(),"mean_bda_fraction":np.nan,"mean_ehho_fraction":np.nan},
        {"algorithm":"BDA-EHHO-VC-Calibrated","runs":len(h),"mean_injections":np.nan,
         "pct_runs_with_injection":np.nan,"mean_diversity":np.nan,"mean_final_diversity":np.nan,
         "mean_bda_fraction":bda_frac,"mean_ehho_fraction":1-bda_frac}
    ])
    mech.to_csv(OUT/"mechanism_diagnostics.csv",index=False,encoding="utf-8-sig")
    spreads=df.groupby(["experiment_id","run_index"])["best_score"].agg(lambda x:float(np.max(x)-np.min(x)))
    completion_ok=len(df)==expected; budget_ok=bool(df["budget_compliant"].astype(bool).all())
    mechanism_ok=(10<=inj_rate<=75 and 0.35<=bda_frac<=0.65)
    report=[
        "# Group 2 Calibrated Pilot Rerun","",
        "## Completion and fairness","",
        f"- Completed runs: **{len(df)}/{expected}**",
        f"- Completion check: **{'PASS' if completion_ok else 'REVIEW'}**",
        f"- Common evaluation-budget compliance: **{'PASS' if budget_ok else 'REVIEW'}**","",
        "## Algorithm summary","",summary.to_markdown(index=False),"",
        "## Mechanism diagnostics","",mech.to_markdown(index=False),"",
        "## Paired score spread","",
        f"- Median within-block score spread: **{spreads.median():.8f}**",
        f"- Maximum within-block score spread: **{spreads.max():.8f}**","",
        "## Mechanism health","",
        f"- Calibrated BEHHO injection-active runs: **{inj_rate:.2f}%**",
        f"- Calibrated hybrid mean BDA fraction: **{bda_frac:.3f}**",
        f"- Calibrated hybrid mean EHHO fraction: **{1-bda_frac:.3f}**",
        f"- Mechanism health check: **{'PASS' if mechanism_ok else 'REVIEW'}**","",
        "## Decision rule","",
        "Proceed to the 24-image screen only if completion, budget compliance, and mechanism health pass. Algorithm ranking here is descriptive only."
    ]
    (OUT/"calibrated_pilot_report.md").write_text("\n".join(report),encoding="utf-8")
    try:
        with pd.ExcelWriter(OUT/"calibrated_pilot.xlsx",engine="openpyxl") as w:
            df.to_excel(w,sheet_name="Runs",index=False); summary.to_excel(w,sheet_name="Summary",index=False); mech.to_excel(w,sheet_name="Mechanisms",index=False)
    except Exception as e: print("Excel export skipped:",e)
    print("Report:",OUT/"calibrated_pilot_report.md")

if __name__=="__main__": main()
