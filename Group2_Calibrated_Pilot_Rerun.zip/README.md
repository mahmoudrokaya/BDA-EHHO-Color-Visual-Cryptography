# Group 2 Calibrated Pilot Rerun

Reruns the original 12-image pilot after mechanism calibration.

Fixed:
- 12 BSDS500 validation images
- 2 runs/image
- population = 20
- budget = 400

Algorithms:
- HHO-VC unchanged
- EHHO-VC unchanged
- BEHHO: threshold 0.70, injection 0.30
- BDA-EHHO: budget-based rho 0.70 -> 0.30

Copy files into:
`D:\48\481\New Papers\BDA_To_HHO_paper\Codes\Group2_HHO_Progression`

Run:
```powershell
python g2_18_rerun_calibrated_pilot.py
python g2_19_analyze_calibrated_pilot.py
```

Outputs:
`D:\48\481\New Papers\BDA_To_HHO_paper\Outputs\Group2_Calibrated_Pilot_Rerun`
