#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Analyze robustness candidate definitions.

Selection criteria:
1. nonconstant within most/all archives;
2. useful within-archive spread;
3. not highly redundant with reconstruction, security, or complexity;
4. monotonic response to stronger damage;
5. conceptually direct measure of resilience to share loss.

Automatic score is diagnostic only.
"""

from __future__ import annotations
import json
from pathlib import Path
import numpy as np
import pandas as pd

BASE = Path(r"D:\48\481\New Papers\BDA_To_HHO_paper")
OUT = BASE / "Outputs" / "Group3_Robustness_Validation"
INPUT = OUT / "robustness_candidate_values.csv"

CANDIDATES = [
    "B1_central_mean",
    "B2_random_block_mean",
    "B3_dropout_mean",
    "B4_crop_mean",
]

REFERENCE = [
    "old_f1_reconstruction",
    "old_f2_security",
    "old_f4_complexity",
]


def normalized_iqr(x):
    x = np.asarray(x, float)
    q1, q3 = np.percentile(x, [25, 75])
    span = np.max(x) - np.min(x)
    return float((q3-q1) / max(span, 1e-12))


def archive_stats(df, col):
    spans = []
    cvs = []
    nonconstant = 0

    for _, g in df.groupby(
        ["experiment_id", "run_index"]
    ):
        x = g[col].to_numpy(float)
        span = float(np.max(x)-np.min(x))
        spans.append(span)
        if span > 1e-12:
            nonconstant += 1
        cvs.append(
            float(
                np.std(x)
                / max(abs(np.mean(x)), 1e-12)
            )
        )

    return {
        "candidate": col,
        "global_min": float(df[col].min()),
        "global_max": float(df[col].max()),
        "global_span": float(
            df[col].max()-df[col].min()
        ),
        "global_std": float(df[col].std()),
        "normalized_iqr": normalized_iqr(
            df[col].to_numpy(float)
        ),
        "pct_archives_nonconstant": float(
            100*nonconstant/len(spans)
        ),
        "median_within_archive_span": float(
            np.median(spans)
        ),
        "median_within_archive_cv": float(
            np.median(cvs)
        ),
    }


def monotonic_rate_check(df, family):
    c5 = f"{family}_5pct"
    c10 = f"{family}_10pct"
    c20 = f"{family}_20pct"

    ok = (
        (df[c5] <= df[c10] + 1e-15)
        & (df[c10] <= df[c20] + 1e-15)
    )
    return float(100*ok.mean())


def main():
    df = pd.read_csv(INPUT)

    rows = []
    family_map = {
        "B1_central_mean": "B1_central",
        "B2_random_block_mean": "B2_random_block",
        "B3_dropout_mean": "B3_dropout",
        "B4_crop_mean": "B4_crop",
    }

    corr_cols = REFERENCE + CANDIDATES
    corr = df[corr_cols].corr(method="spearman")

    for col in CANDIDATES:
        s = archive_stats(df, col)
        family = family_map[col]
        s["pct_monotonic_with_damage_rate"] = (
            monotonic_rate_check(
                df, family
            )
        )

        s["abs_rho_reconstruction"] = abs(
            float(
                corr.loc[
                    col,
                    "old_f1_reconstruction",
                ]
            )
        )
        s["abs_rho_security"] = abs(
            float(
                corr.loc[
                    col,
                    "old_f2_security",
                ]
            )
        )
        s["abs_rho_complexity"] = abs(
            float(
                corr.loc[
                    col,
                    "old_f4_complexity",
                ]
            )
        )

        max_red = max(
            s["abs_rho_reconstruction"],
            s["abs_rho_security"],
            s["abs_rho_complexity"],
        )

        # Diagnostic score, not a scientific metric.
        s["diagnostic_score"] = (
            0.35 * (
                s["pct_archives_nonconstant"]
                / 100.0
            )
            + 0.20 * min(
                s["median_within_archive_cv"]
                / 0.05,
                1.0,
            )
            + 0.20 * (
                s[
                    "pct_monotonic_with_damage_rate"
                ] / 100.0
            )
            + 0.25 * (1.0 - min(max_red, 1.0))
        )

        rows.append(s)

    stats = pd.DataFrame(rows).sort_values(
        "diagnostic_score",
        ascending=False,
    )

    stats.to_csv(
        OUT / "robustness_candidate_statistics.csv",
        index=False,
        encoding="utf-8-sig",
    )

    corr.to_csv(
        OUT / "robustness_spearman_correlations.csv",
        encoding="utf-8-sig",
    )

    best = stats.iloc[0]

    # Flag high redundancy.
    warnings = []
    for col in CANDIDATES:
        for ref in REFERENCE:
            rho = float(corr.loc[col, ref])
            if abs(rho) >= 0.90:
                warnings.append(
                    f"{col} highly redundant with "
                    f"{ref}: rho={rho:.3f}"
                )

    decision = {
        "diagnostic_top_candidate": str(
            best["candidate"]
        ),
        "top_candidate_score": float(
            best["diagnostic_score"]
        ),
        "human_conceptual_review_required": True,
        "redundancy_warnings": warnings,
        "recommended_freeze_rule": (
            "Freeze only a candidate that is nonconstant "
            "within archives, monotonic with damage level, "
            "and not strongly redundant with reconstruction."
        ),
    }

    (OUT / "robustness_validation_decision.json").write_text(
        json.dumps(decision, indent=2),
        encoding="utf-8",
    )

    report = [
        "# Group 3 — Robustness Validation",
        "",
        "## Candidate statistics",
        "",
        stats.to_markdown(index=False),
        "",
        "## Spearman correlations",
        "",
        corr.to_markdown(),
        "",
        "## Diagnostic top candidate",
        "",
        f"**{best['candidate']}**",
        "",
        "The automatic ranking is diagnostic only. "
        "The final robustness objective must also be "
        "conceptually appropriate for visual cryptography.",
        "",
        "## Redundancy warnings",
        "",
    ]

    if warnings:
        report.extend(
            [f"- {x}" for x in warnings]
        )
    else:
        report.append(
            "- No |rho| >= 0.90 redundancy warning."
        )

    report += [
        "",
        "## Next step",
        "",
        "If the top candidate is conceptually acceptable "
        "and satisfies the discrimination/redundancy checks, "
        "freeze it as f3 and update the multi-objective "
        "problem together with the already selected S2 "
        "security objective. Then rerun the same 12-image "
        "MO validation once before E4.",
    ]

    (OUT / "robustness_validation_report.md").write_text(
        "\n".join(report),
        encoding="utf-8",
    )

    try:
        with pd.ExcelWriter(
            OUT / "robustness_validation.xlsx",
            engine="openpyxl",
        ) as w:
            stats.to_excel(
                w,
                sheet_name="Candidate Statistics",
                index=False,
            )
            corr.to_excel(
                w,
                sheet_name="Correlations",
            )
            df.to_excel(
                w,
                sheet_name="Candidates",
                index=False,
            )
    except Exception as exc:
        print("Excel export skipped:", exc)

    print("Robustness validation complete.")
    print(
        "Diagnostic top candidate:",
        best["candidate"],
    )
    print(
        "Report:",
        OUT / "robustness_validation_report.md",
    )


if __name__ == "__main__":
    main()
