#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Group 3 Robustness Validation / Code 13

Candidate robustness perturbations for VC shares.

All robustness candidates are minimized and compare the CLEAN reconstruction
against a reconstruction obtained after damaging ONE share. This avoids the
redundancy problem observed when robustness was defined primarily through
secret-vs-reconstruction MSE.

Families
--------
B1 — Central block erasure on Share 1
     A contiguous central block covering approximately 5%, 10%, or 20% of
     image area is set to 0 in Share 1.

B2 — Random-location block erasure on Share 1
     Same area fractions, but the block location is deterministic for a given
     image/run/rate.

B3 — One-share pixel dropout
     5%, 10%, or 20% of Share-1 pixels are deterministically selected and set
     to 0 (erasure, not bit flipping).

B4 — One-share crop-loss with zero padding
     A strip is removed from the right/bottom of Share 1 and the missing region
     is padded with 0 so output dimensions are preserved.

For each family we report:
  normalized MSE(clean reconstruction, damaged reconstruction)
and the mean across damage rates.

The perturbation masks/locations are fixed within an image/run so every
candidate is evaluated under the same damage realization.
"""

from __future__ import annotations
import math
import numpy as np

MAX_MSE = 255.0 ** 2


def mse(a, b):
    x = np.asarray(a, dtype=np.float64)
    y = np.asarray(b, dtype=np.float64)
    return float(np.mean((x - y) ** 2))


def block_hw_for_fraction(h, w, frac):
    area = max(1, int(round(h * w * float(frac))))
    aspect = w / max(h, 1)
    bh = max(1, int(round(math.sqrt(area / max(aspect, 1e-12)))))
    bw = max(1, int(round(area / bh)))
    bh = min(bh, h)
    bw = min(bw, w)
    return bh, bw


def central_block_mask(shape_hw3, frac):
    h, w, _ = shape_hw3
    bh, bw = block_hw_for_fraction(h, w, frac)
    y0 = max(0, (h - bh) // 2)
    x0 = max(0, (w - bw) // 2)
    mask2 = np.zeros((h, w), dtype=bool)
    mask2[y0:y0+bh, x0:x0+bw] = True
    return np.repeat(mask2[..., None], 3, axis=2)


def random_block_mask(shape_hw3, frac, rng):
    h, w, _ = shape_hw3
    bh, bw = block_hw_for_fraction(h, w, frac)
    y0 = int(rng.integers(0, max(1, h - bh + 1)))
    x0 = int(rng.integers(0, max(1, w - bw + 1)))
    mask2 = np.zeros((h, w), dtype=bool)
    mask2[y0:y0+bh, x0:x0+bw] = True
    return np.repeat(mask2[..., None], 3, axis=2)


def pixel_dropout_mask(shape_hw3, frac, rng):
    h, w, _ = shape_hw3
    # Same spatial dropout position across RGB channels; this is closer to
    # losing share pixels than independently corrupting color channels.
    spatial = rng.random((h, w)) < float(frac)
    return np.repeat(spatial[..., None], 3, axis=2)


def crop_loss_mask(shape_hw3, frac):
    """
    Deterministic missing bottom/right strips totaling about `frac` area.
    Missing pixels are later set to zero while canvas size is preserved.
    """
    h, w, _ = shape_hw3
    # Allocate roughly half of the lost area to a bottom strip and half to right.
    side_frac = 1.0 - math.sqrt(max(0.0, 1.0 - float(frac)))
    cut_h = max(1, int(round(h * side_frac)))
    cut_w = max(1, int(round(w * side_frac)))
    mask2 = np.zeros((h, w), dtype=bool)
    mask2[h-cut_h:h, :] = True
    mask2[:, w-cut_w:w] = True
    return np.repeat(mask2[..., None], 3, axis=2)


def damage_share1(share1, mask):
    out = share1.copy()
    out[mask] = 0
    return out


def robustness_score(clean_rec, damaged_rec):
    return float(mse(clean_rec, damaged_rec) / MAX_MSE)
