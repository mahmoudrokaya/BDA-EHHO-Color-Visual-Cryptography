#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Run the complete compact Group-3 robustness validation suite."""

import subprocess
import sys

SCRIPTS = [
    "g3_14_recompute_robustness_candidates.py",
    "g3_15_analyze_robustness_discrimination.py",
]

for script in SCRIPTS:
    print("="*78)
    print("RUNNING", script)
    print("="*78)

    r = subprocess.run(
        [sys.executable, script]
    )

    if r.returncode != 0:
        raise SystemExit(
            f"{script} failed with return code "
            f"{r.returncode}"
        )

print("="*78)
print("GROUP 3 ROBUSTNESS VALIDATION: COMPLETE")
print("="*78)
