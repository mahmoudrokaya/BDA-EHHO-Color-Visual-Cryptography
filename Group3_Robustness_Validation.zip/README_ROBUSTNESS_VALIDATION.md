# Group3_Robustness_Validation

This compact suite resolves the last open objective-definition issue before E4.

## What is already frozen

- f1 Reconstruction: normalized clean reconstruction MSE.
- f2 Security: mean absolute secret-share Pearson correlation (S2).
- f4 Complexity: mean RGB group count / 255.
- Group-2 optimizer settings remain frozen.

## What is being tested

Four candidate robustness families, each applied only to **Share 1** so that
the damage represents partial loss/corruption of one transmitted share.

### B1 — Central block erasure
A contiguous central block covering 5%, 10%, or 20% of the image is erased.

### B2 — Random-location block erasure
Same block sizes, but with deterministic image/run-specific positions.

### B3 — Pixel dropout
5%, 10%, or 20% of one-share pixel locations are erased to zero.

### B4 — Crop-loss with zero padding
Right/bottom image regions are treated as missing and padded with zero.

## Robustness score

For each damage rate:

`MSE(clean reconstruction, damaged reconstruction) / 255²`

The mean across 5%, 10%, 20% is the candidate robustness objective.

This directly asks how much the reconstructed visual secret changes when one
share is partially unavailable.

## Scientific constraints

- The optimizer is NOT rerun.
- The same 823 previously selected archive candidates are reused.
- Damage patterns are deterministic within image/run.
- Every candidate in a paired image/run receives the same damage pattern.
- Automatic rankings are diagnostic only.
- High redundancy with reconstruction is grounds for rejection.

## Files

- g3_13_robustness_candidates.py
- g3_14_recompute_robustness_candidates.py
- g3_15_analyze_robustness_discrimination.py
- g3_16_run_robustness_validation_all.py

## Run

Copy these files into:

`D:\48\481\New Papers\BDA_To_HHO_paper\Codes\Group3_MO_BDA_EHHO`

Then:

```powershell
python g3_16_run_robustness_validation_all.py
```

Outputs:

`D:\48\481\New Papers\BDA_To_HHO_paper\Outputs\Group3_Robustness_Validation`

Important outputs:

- robustness_validation_report.md
- robustness_validation_decision.json
- robustness_candidate_statistics.csv
- robustness_spearman_correlations.csv
- robustness_validation.xlsx
- robustness_candidate_values.csv

Once the robustness objective is accepted, all four MO objectives can be
frozen and the 12-image MO validation rerun one final time before E4.
