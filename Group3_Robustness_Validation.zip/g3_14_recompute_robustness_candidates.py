#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Recompute structurally meaningful robustness candidates for the 823 archive
solutions already selected by Group3_Objective_Validation.

No optimizer rerun. No parameter tuning.

Damage rates:
    5%, 10%, 20%

Output:
    robustness_candidate_values.csv
"""

from __future__ import annotations

import hashlib
from pathlib import Path
import numpy as np
import pandas as pd

from g1_02_rgb_decomposition import load_rgb
from g1_03_vc_share_generation import generate_rgb_shares
from g1_04_vc_reconstruction import xor_reconstruct
from g3_13_robustness_candidates import (
    central_block_mask,
    random_block_mask,
    pixel_dropout_mask,
    crop_loss_mask,
    damage_share1,
    robustness_score,
)

BASE = Path(r"D:\48\481\New Papers\BDA_To_HHO_paper")
DATA = BASE / "Data"
MANIFEST = BASE / "Outputs" / "Manifests" / "dataset_manifest.csv"
INPUT = BASE / "Outputs" / "Group3_Objective_Validation" / "candidate_index.csv"
OUT = BASE / "Outputs" / "Group3_Robustness_Validation"

RATES = (0.05, 0.10, 0.20)
BASE_SEED = 20260913


def stable_seed(*parts):
    d = hashlib.sha256("|".join(map(str, parts)).encode()).digest()
    return int.from_bytes(d[:4], "little") & 0x7fffffff


def main():
    OUT.mkdir(parents=True, exist_ok=True)

    candidates = pd.read_csv(INPUT, dtype={"bits": "string"})
    manifest = pd.read_csv(MANIFEST)
    path_map = dict(
        zip(manifest["experiment_id"], manifest["relative_to_data"])
    )

    rows = []

    grouped = candidates.groupby(
        ["experiment_id", "run_index"], sort=False
    )

    for (experiment_id, run_index), group in grouped:
        image = load_rgb(
            DATA / path_map[experiment_id],
            True,
        )

        seed = stable_seed(
            BASE_SEED,
            experiment_id,
            run_index,
            "ROBUSTNESS_AUDIT",
        )

        ss = np.random.SeedSequence(seed)
        children = ss.spawn(3 + 2 * len(RATES))

        random_fields = tuple(
            np.random.default_rng(children[i]).random(
                image.shape[:2]
            )
            for i in range(3)
        )

        masks = {}
        for rate in RATES:
            masks[("B1_central", rate)] = central_block_mask(
                image.shape, rate
            )
            masks[("B4_crop", rate)] = crop_loss_mask(
                image.shape, rate
            )

        base = 3
        for ridx, rate in enumerate(RATES):
            rng_block = np.random.default_rng(
                children[base + 2*ridx]
            )
            rng_drop = np.random.default_rng(
                children[base + 2*ridx + 1]
            )
            masks[("B2_random_block", rate)] = (
                random_block_mask(
                    image.shape, rate, rng_block
                )
            )
            masks[("B3_dropout", rate)] = (
                pixel_dropout_mask(
                    image.shape, rate, rng_drop
                )
            )

        for _, r in group.iterrows():
            levels = (
                int(r["level_R"]),
                int(r["level_G"]),
                int(r["level_B"]),
            )

            share1, share2, _ = generate_rgb_shares(
                image,
                levels,
                random_fields=random_fields,
            )
            clean_rec = xor_reconstruct(
                share1, share2
            )

            out = dict(r)

            family_values = {
                "B1_central": [],
                "B2_random_block": [],
                "B3_dropout": [],
                "B4_crop": [],
            }

            for family in family_values:
                for rate in RATES:
                    damaged1 = damage_share1(
                        share1,
                        masks[(family, rate)],
                    )
                    damaged_rec = xor_reconstruct(
                        damaged1,
                        share2,
                    )

                    val = robustness_score(
                        clean_rec,
                        damaged_rec,
                    )
                    family_values[family].append(val)

                    out[
                        f"{family}_{int(rate*100)}pct"
                    ] = val

            for family, vals in family_values.items():
                out[f"{family}_mean"] = float(
                    np.mean(vals)
                )
                out[f"{family}_max"] = float(
                    np.max(vals)
                )

            rows.append(out)

        print(
            experiment_id,
            "run",
            run_index,
            "candidates",
            len(group),
        )

    result = pd.DataFrame(rows)

    result.to_csv(
        OUT / "robustness_candidate_values.csv",
        index=False,
        encoding="utf-8-sig",
    )

    print(
        "Output:",
        OUT / "robustness_candidate_values.csv",
    )


if __name__ == "__main__":
    main()
